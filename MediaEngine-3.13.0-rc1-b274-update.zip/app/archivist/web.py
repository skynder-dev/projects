from __future__ import annotations
from .connectors import connector_catalog as m12_connector_catalog, connector_summary as m12_connector_summary, create_manual_handoff_for_composition
from .experiments import experiment_metric_summaries as get_experiment_metric_summaries, validate_results_csv as validate_experiment_results_csv, import_results_csv as import_experiment_results_csv
from .experiments import ensure_schema as ensure_experiment_schema, create_experiment as create_social_experiment, add_variant as add_social_variant, record_result as record_social_result, list_experiments as list_social_experiments, experiment_detail as get_social_experiment, experiment_stats
from .social_lab import enqueue_composition as enqueue_social_composition, list_queue as list_social_queue, set_queue_state as set_social_queue_state
from .social_lab import ensure_schema as ensure_social_schema, publication_stats, list_publications, recent_rendered_compositions, candidate_from_composition, evaluate_composition as evaluate_social_composition, record_composition as record_social_composition

import html, json, os, re, subprocess, threading, time, urllib.parse
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, Response, jsonify, redirect, render_template, request, send_file

from . import android
from .config import APP_PORT, BUILD, HOME, INSTALL, SIDE_BY_SIDE, PRIVATE, REJECTED, STAGING, STORYBOARDS, THUMBS, VERSION, load_config, save_config, update_config
from .db import db, init_db, inventory_visible
from .media_brain import (best_clips, build_tracked_trajectory, clip_by_id, clips_for_inventory,
                          ensure_schema as ensure_media_brain_schema, save_crop_trajectory,
                          trajectories_for_clip, trajectory_for_clip)
from .service import (STATE, cached_storyboard, cached_thumbnail, cancel_job, job_detail, latest_jobs, queue_job,
                      queue_storyboard, queue_thumbnail, remove_from_library, retry_failed, set_excluded, set_rights, set_rights_custom, start_discovery, storyboard_info, windows_drives)
from .converter import PRESETS as CONVERT_PRESETS, convert_job_snapshot, start_convert_job, probe_local_media_meta
from .semantic_search import search_library as semantic_search, capabilities as semantic_capabilities
from .visual_similarity import find_similar
from .clip_export import EXPORTS, export_by_id, export_clip
from .composer import EXPORTS as COMPOSER_EXPORTS, composition_detail, create_composition, ensure_schema as ensure_composer_schema, move_item as move_composer_item, start_render as start_composer_render, remove_item as remove_composer_item, delete_composition, drop_hidden as drop_composer_hidden
from .product_foundation import platform_snapshot, setup_catalog
from .beta_readiness import welcome_body, help_body, guide_body, connection_disclosure_html
from .platform_adapter import spawn_app_launcher
from .auto_edit_web import register as register_auto_edit
from . import i18n


def e(v): return html.escape(str(v if v is not None else ""), quote=True)

def human_bytes(n):
    try: n=float(n)
    except Exception: return "—"
    for u in ("B","KB","MB","GB","TB"):
        if n<1024 or u=="TB": return f"{n:.0f} {u}" if u in ("B","KB") else f"{n:.1f} {u}"
        n/=1024

def human_duration(ms):
    try: sec=int(ms)//1000
    except Exception: return "—"
    h,r=divmod(sec,3600); m,s=divmod(r,60); return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

def _job_elapsed(j):
    try:
        start = j.get('started_at') or j.get('created_at')
        if not start:
            return ''
        # times are stored as local wall-clock time (now_iso): a naive time is local, not UTC - read as UTC, a
        # running job showed hours too much west of Greenwich and 0 s east of it
        a = datetime.fromisoformat(str(start).replace('Z','+00:00'))
        if a.tzinfo is None:
            a = a.astimezone()
        end = j.get('finished_at')
        b = datetime.fromisoformat(str(end).replace('Z','+00:00')) if end else datetime.now(timezone.utc)
        if b.tzinfo is None:
            b = b.astimezone()
        sec = max(0, int((b-a).total_seconds()))
        if sec < 60:
            return f"{sec}s"
        m,s = divmod(sec,60)
        if m < 60:
            return f"{m}m {s}s"
        h,m = divmod(m,60)
        return f"{h}h {m}m"
    except Exception:
        return ''



CSS=r'''
:root{color-scheme:dark;--bg:#090d12;--bg2:#0f151d;--card:#151b24;--card2:#1b232e;--line:#293442;--line2:#3a4758;--text:#f5f7fb;--muted:#94a1b2;--blue:#6d96ff;--blue2:#5177df;--green:#53c983;--orange:#d7a34a;--red:#d46b74;--violet:#a78bfa;--cyan:#67d7e8;--rose:#e78caf;--shadow:0 14px 40px #00000026}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(920px 520px at 8% -100px,#6d96ff20,transparent 62%),radial-gradient(760px 430px at 84% -80px,#a78bfa16,transparent 62%),radial-gradient(780px 520px at 55% 115%,#53c9830c,transparent 65%),linear-gradient(180deg,var(--bg2),var(--bg) 340px);color:var(--text);font:15px/1.45 system-ui,-apple-system,Segoe UI,sans-serif}a{color:inherit;text-decoration:none}nav{position:sticky;top:0;z-index:30;background:#0d1219df;border-bottom:1px solid #364253aa;backdrop-filter:blur(18px) saturate(120%)}.navin{max-width:1540px;margin:auto;padding:11px 20px;display:flex;align-items:center;gap:7px}.brand{font-weight:900;font-size:20px;letter-spacing:-.35px;margin-right:8px}.brand:before{content:'';display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:8px;background:linear-gradient(135deg,var(--blue),var(--violet));box-shadow:0 0 18px #6d96ff88}.version{font-size:10px;white-space:nowrap;background:#7b8aa81a;border:1px solid #8ea2c02d;padding:2px 6px;border-radius:999px;vertical-align:2px;color:#cbd6e7}.navlink{color:#bdc7d4!important;padding:8px 10px;border-radius:10px;white-space:nowrap;transition:.12s}.navlink:hover{background:#8aa1c314;color:#fff!important}.navlink.active{background:linear-gradient(135deg,#6d96ff20,#a78bfa18);border:1px solid #849cff28;color:#fff!important}.navextra{display:none}.navin.showmore .navextra{display:inline-block}.navin.showmore .navmorebtn{color:#fff!important}.navmorebtn:after{content:' ▾';font-size:11px}.navin.showmore .navmorebtn:after{content:' ▴'}.spacer{flex:1}.taskgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}.task{display:flex;flex-direction:column;gap:6px;min-height:112px;position:relative;overflow:hidden;--tone:#6d96ff;background:linear-gradient(160deg,color-mix(in srgb,var(--tone) 13%,transparent),transparent 62%),linear-gradient(180deg,#1a202aee,#141a22ef)}.task:before{content:'';position:absolute;left:0;top:0;right:0;height:3px;background:var(--tone)}.task b{font-size:18px}.task span{color:var(--muted)}.task:hover{border-color:var(--tone)}.task[data-tone=create]{--tone:#f0705a}.task[data-tone=videos]{--tone:#22ad9e}.task[data-tone=tools]{--tone:#dd9530}.worklist{display:flex;flex-direction:column;margin-top:8px}.workrow{display:flex;gap:10px;align-items:center;padding:8px 4px;border-bottom:1px solid #2a3441}.workrow:last-child{border-bottom:0}.workrow:hover{background:#8aa1c30d}.workrow .badge{margin:0;flex:0 0 auto}.worktitle{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.worktime{font-size:13px;white-space:nowrap}@media(max-width:600px){.workrow{flex-wrap:wrap}.worktitle{flex-basis:100%;order:3}}:root{--z:1}@media(min-width:1600px){:root{--z:1.1}}@media(min-width:2200px){:root{--z:1.2}}@media(min-width:2900px){:root{--z:1.3}}@media(min-width:3400px){:root{--z:1.45}}body[data-scale='100']{--z:1}body[data-scale='115']{--z:1.15}body[data-scale='130']{--z:1.3}body[data-scale='150']{--z:1.5}body{zoom:var(--z)}.app{display:grid;grid-template-columns:256px minmax(0,1fr);min-height:100vh}.side{position:sticky;top:0;height:calc(100vh / var(--z));overflow-y:auto;background:#0d1219ef;border-right:1px solid #364253aa;display:flex;flex-direction:column;padding:14px 10px 12px;z-index:30;scrollbar-width:thin}.sidetop{padding:2px 10px 12px}.side .brand{font-size:21px;margin:0}.sidenav,.sidebottom{display:flex;flex-direction:column;gap:1px}.sidehead{font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#7f8ea3;padding:14px 12px 5px}.side .navlink{display:block;padding:7px 12px;white-space:normal;line-height:1.25;border:1px solid transparent;font-size:16px}.side .navsub{padding:5px 12px 5px 26px;font-size:14.5px}.side .navsub.active{background:#6d96ff18}.sidebottom{margin-top:auto;padding-top:10px;margin-top:14px;border-top:1px solid #2c3744}.sidebtns{display:flex;flex-wrap:wrap;gap:6px;padding:10px 4px 0}.sidebtns button{padding:6px 9px;font-size:13px}.side .navextra{display:block}.navbadge{display:inline-block;min-width:20px;padding:0 6px;border-radius:999px;background:var(--acc,#6d96ff);color:#fff;font-size:12px;font-weight:800;text-align:center;margin-left:4px}.main{min-width:0}.mobilebar{display:none}.sideshade{display:none}.jobbar{top:0!important}@media(max-width:900px){.app{grid-template-columns:minmax(0,1fr)}.side{position:fixed;left:0;top:0;bottom:0;width:270px;max-width:86vw;transform:translateX(-105%);transition:transform .15s;box-shadow:0 0 40px #000a}.app.menu-open .side{transform:none}.app.menu-open .sideshade{display:block;position:fixed;inset:0;background:#0008;z-index:29}.mobilebar{display:flex;gap:10px;align-items:center;position:sticky;top:0;z-index:28;background:#0d1219ef;border-bottom:1px solid #364253aa;padding:8px 12px}.mobilebar .brand{font-size:17px}.jobbar{top:51px!important}}.wrap{max-width:1540px;margin:auto;padding:24px 20px 42px}.card{background:linear-gradient(180deg,#1a202aee,#141a22ef);border:1px solid #344151c9;border-radius:15px;padding:15px;box-shadow:var(--shadow);backdrop-filter:blur(10px)}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.space{justify-content:space-between}.muted{color:var(--muted)}.eyebrow{color:#a9c1ff;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.lead{font-size:16px;color:#b8c2cf;max-width:780px;margin-top:5px}.pagehead{margin-bottom:16px}.pagehead h1{font-size:31px;letter-spacing:-.6px;margin:2px 0 0}.device{display:flex;gap:10px;align-items:center}.device-dot{width:10px;height:10px;border-radius:50%;background:#687383;box-shadow:0 0 0 4px #6873831c;flex:0 0 auto}.device-dot.online{background:#3dcc72;box-shadow:0 0 0 4px #3dcc7221,0 0 14px #3dcc7255}.device-status{font-weight:750}.source-card{display:flex;align-items:center;justify-content:space-between;gap:18px}.section-title{font-size:18px;margin:24px 0 10px}.callout{border:1px solid #6d96ff38;background:linear-gradient(135deg,#6d96ff15,#a78bfa0e 55%,#53c9830a)}button,.btn{border:1px solid #96adff22;border-radius:10px;padding:9px 13px;background:linear-gradient(180deg,#7099ff,#5278df);color:#fff;font-weight:780;cursor:pointer;box-shadow:0 6px 18px #264b9930}button:hover,.btn:hover{filter:brightness(1.07)}.btn2{background:#91a2bd14;border-color:#91a2bd25}.ok{background:linear-gradient(180deg,#58c987,#3aa86a);border-color:#8ee1aa28}.warn{background:linear-gradient(180deg,#d5a54e,#ae7b27);border-color:#f1c16e25}.danger{background:linear-gradient(180deg,#d66d77,#b44f5a);border-color:#ef9aa225}button:disabled{opacity:.5;cursor:not-allowed}input,select{background:#0e131a;color:#fff;border:1px solid #364150;border-radius:9px;padding:8px 9px;outline:none}input:focus,select:focus{border-color:#5b86d8;box-shadow:0 0 0 3px #4a82f420}.hero{display:grid;grid-template-columns:repeat(6,minmax(140px,1fr));gap:11px;margin:16px 0}.metric{min-height:96px;position:relative;overflow:hidden}.metric:after{content:'';position:absolute;width:100px;height:100px;border-radius:50%;right:-36px;top:-42px;filter:blur(1px);opacity:.42}.tone-blue{border-color:#6d96ff30;background:linear-gradient(145deg,#6d96ff12,#151b24 60%)}.tone-blue:after{background:#6d96ff28}.tone-mint{border-color:#53c9832d;background:linear-gradient(145deg,#53c98310,#151b24 60%)}.tone-mint:after{background:#53c98325}.tone-violet{border-color:#a78bfa2f;background:linear-gradient(145deg,#a78bfa12,#151b24 60%)}.tone-violet:after{background:#a78bfa26}.tone-amber{border-color:#d7a34a2f;background:linear-gradient(145deg,#d7a34a10,#151b24 60%)}.tone-amber:after{background:#d7a34a25}.tone-rose{border-color:#e78caf2f;background:linear-gradient(145deg,#e78caf10,#151b24 60%)}.tone-rose:after{background:#e78caf24}.tone-cyan{border-color:#67d7e82f;background:linear-gradient(145deg,#67d7e810,#151b24 60%)}.tone-cyan:after{background:#67d7e824}.metric b{font-size:27px;display:block;margin-top:4px;letter-spacing:-.5px}.metric span:first-child{font-size:12px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px}.media-card{position:relative;background:linear-gradient(180deg,#171e27,#131920);border:1px solid #334050;border-radius:14px;overflow:hidden;cursor:pointer;box-shadow:0 8px 22px #0002;transition:transform .12s,border-color .12s,box-shadow .12s}.media-card:hover{transform:translateY(-2px);border-color:#61718a;box-shadow:0 14px 30px #0005,0 0 0 1px #6d96ff10}.media-card.selected{outline:2px solid var(--blue);outline-offset:1px}.thumb{height:145px;background:#080b0f;display:flex;align-items:center;justify-content:center}.thumb img{width:100%;height:100%;object-fit:cover;transition:opacity .12s}.storybadge{position:absolute;left:7px;top:7px;z-index:3;background:#10151ddd;border:1px solid #536071;border-radius:999px;padding:2px 6px;font-size:10px;display:none}.storystrip{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:12px}.storyframe{position:relative;border:1px solid #303842;border-radius:8px;overflow:hidden;background:#090c10;cursor:pointer}.storyframe:hover{border-color:#58709a}.storyframe img{display:block;width:100%;aspect-ratio:16/10;object-fit:cover}.storytime{position:absolute;right:3px;bottom:3px;background:#000c;padding:1px 4px;border-radius:4px;font-size:10px}.meta{padding:9px}.name{font-weight:780;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.small{font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.check{position:absolute;z-index:4;right:8px;top:8px;width:20px;height:20px;accent-color:var(--blue)}.badge{display:inline-block;font-size:11px;border-radius:999px;padding:3px 8px;background:#a9b7cd15;border:1px solid #a9b7cd1b;margin:5px 4px 0 0;box-shadow:inset 0 1px #ffffff08}.safe,.imported,.archived,.local,.quality-ok,.rights-cleared{background:#53c98316;border-color:#53c98329;color:#9be7b8}.review,.quality-review,.rights-review{background:#d7a34a16;border-color:#d7a34a2b;color:#edc979}.rights-permission{background:#e49b5517;border-color:#e49b552c;color:#efbd86}.private,.error,.cancelled,.rejected,.rights-blocked{background:#d66d7717;border-color:#d66d772d;color:#f1a2aa}.duplicate,.skipped_duplicate{background:#a78bfa17;border-color:#a78bfa2d;color:#c9b9ff}.ready,.audioflag{background:#67d7e815;border-color:#67d7e829;color:#9be9f2}.unreviewed,.rights-unknown{background:#9aabba12;border-color:#9aabba1e;color:#b8c3d0}.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0}.toolpanel{background:#111821c9;border:1px solid #354253;border-radius:13px;padding:10px 11px;margin:12px 0;backdrop-filter:blur(12px)}.pagination{display:flex;gap:8px;align-items:center;margin:18px 0}.jobbar{position:sticky;top:59px;z-index:25;background:#151a20ee;border-bottom:1px solid var(--line);display:none;backdrop-filter:blur(8px)}.jobinner{max-width:1540px;margin:auto;padding:9px 20px}.progress{height:7px;background:#303741;border-radius:10px;overflow:hidden;margin-top:6px}.progress i{height:100%;display:block;background:linear-gradient(90deg,#6d96ff,#a78bfa,#67d7e8);width:0}.toast{position:fixed;right:18px;bottom:18px;z-index:100;background:#20262e;border:1px solid #3a4350;border-radius:10px;padding:11px 14px;display:none;max-width:440px;box-shadow:0 18px 50px #0008}.details{display:grid;grid-template-columns:minmax(340px,680px) minmax(300px,1fr);gap:18px}.preview{min-height:340px;background:#080a0d;border:1px solid #202833;border-radius:14px;display:flex;align-items:center;justify-content:center;overflow:hidden}.preview img,.preview video{max-width:100%;max-height:calc(70vh / var(--z,1))}.kv{display:grid;grid-template-columns:150px 1fr;gap:8px 12px}.kv div:nth-child(odd){color:var(--muted)}.kv>div{min-width:0;overflow-wrap:anywhere}.details>*{min-width:0}.jobs{display:grid;gap:10px}.jobrow{display:grid;grid-template-columns:70px 130px 120px 1fr 180px;gap:10px;align-items:center}.errbox{white-space:pre-wrap;background:#27191a;border:1px solid #653537;padding:8px;border-radius:8px;color:#efb7b7}.about-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:14px}.about-hero{position:relative;overflow:hidden;padding:24px}.about-hero:after{content:'';position:absolute;width:340px;height:340px;border-radius:50%;right:-120px;top:-170px;background:radial-gradient(circle,#a78bfa35,transparent 68%);pointer-events:none}.principles{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.principle{padding:13px;border:1px solid #3b4757;border-radius:13px;background:#111821aa}.principle b{display:block;margin-bottom:3px}.roadmap{display:grid;gap:8px}.roadmap-step{display:flex;gap:10px;align-items:flex-start;padding:10px 0;border-bottom:1px solid #2c3744}.roadmap-step:last-child{border-bottom:0}.step-dot{width:9px;height:9px;border-radius:50%;margin-top:6px;flex:0 0 auto;background:linear-gradient(135deg,#6d96ff,#a78bfa);box-shadow:0 0 12px #6d96ff66}.about-list{display:grid;gap:9px}.about-list div{padding:10px 0;border-bottom:1px solid #29313d}.about-list div:last-child{border-bottom:0}.empty{padding:34px;text-align:center;border:1px dashed #394454;border-radius:14px;color:var(--muted);background:#11161d}.mode-note{font-size:13px;color:#aeb8c5}.softline{height:1px;background:var(--line);border:0;margin:18px 0}.hubgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.hubcard{display:flex;flex-direction:column;gap:7px;min-height:120px}.hubcard>b{font-size:18px}.hubcard>span,.hubcard>small{color:var(--muted)}.setupgrid{display:grid;gap:12px;margin-top:14px}.setupcard{display:grid;gap:12px}.setupmeta{display:grid;grid-template-columns:1fr 2fr;gap:12px}.setupmeta span{display:grid;gap:3px}.setupmeta small{color:var(--muted)}.navin{flex-wrap:wrap;row-gap:4px}.pagination{flex-wrap:wrap}@media (max-width:760px){.about-grid,.principles,.details,.setupmeta{grid-template-columns:1fr}}@media (max-width:1240px){.navin{flex-wrap:wrap;row-gap:4px;padding:8px 12px;gap:4px}.navlink{padding:6px 7px}.brand{font-size:17px;margin-right:4px}.navin .btn2,.navin button{padding:7px 9px}}
@media(max-width:1000px){.hero{grid-template-columns:repeat(3,1fr)}.navin{overflow-x:auto}.navin::-webkit-scrollbar{display:none}}@media(max-width:850px){.hero{grid-template-columns:1fr 1fr}.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.details,.about-grid{grid-template-columns:1fr}.wrap{padding:14px}.jobrow{grid-template-columns:55px 1fr}.jobrow>*:nth-child(n+3){grid-column:2}.navin{gap:4px;padding:9px 10px}.navlink{padding:7px 8px}.thumb{height:120px}.pagehead h1{font-size:26px}}
'''

GLOBAL_JS=r'''
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let lastJobSample=null;
function toast(t){const x=document.getElementById('toast');if(x){x.style.display='block';x.textContent=t;setTimeout(()=>x.style.display='none',5000)}}
function fmtBytes(n){n=Number(n||0);const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return (i<2?Math.round(n):n.toFixed(1))+' '+u[i]}
function fmtEta(sec){if(!isFinite(sec)||sec<0)return'';sec=Math.round(sec);if(sec<60)return sec+'s';const m=Math.floor(sec/60),s=sec%60;if(m<60)return m+'m '+s+'s';return Math.floor(m/60)+'h '+(m%60)+'m'}
async function appControl(mode,force=false){
  const t=document.getElementById('toast');if(t){t.style.display='block';t.textContent=(mode==='update'?'Updating':'Restarting')+' MediaEngine… current tab will reconnect.'}
  try{
    const r=await fetch('/api/app-control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode,force})});
    if(r.status===409){const x=await r.json();if(confirm((x.error||'A job is running.')+'\n\nRestart/update anyway? The current file may need to restart.'))return appControl(mode,true);if(t)t.style.display='none';return}
    if(!r.ok){const x=await r.json();toast('ERROR: '+(x.error||r.statusText));return}
  }catch(e){}
  await sleep(900);
  for(let i=0;i<100;i++){try{const r=await fetch('/api/ping?x='+Date.now(),{cache:'no-store'});if(r.ok){location.reload();return}}catch(e){}await sleep(500)}
  if(t)t.textContent='MediaEngine is taking longer than expected. Start it again from the desktop shortcut; startup health-check will roll back a bad release.';
}
async function pollJob(){
  try{
    const r=await fetch('/api/status',{cache:'no-store'}),s=await r.json(),b=document.getElementById('jobbar'),txt=document.getElementById('jobtext'),sub=document.getElementById('jobsub'),bar=document.getElementById('jobpct');
    const j=s.active_job;
    if(j){
      b.style.display='block';let pct=j.total?Math.round(100*j.done/j.total):0;let progress=j.done+'/'+j.total;if(j.stage==='import'&&j.bytes_total)pct=Math.max(pct,Math.min(100,Math.round(100*j.bytes_done/j.bytes_total)));if(j.stage==='media_brain'){const mm=(j.message||'').match(/clip\s+(\d+)\/(\d+)/i);if(mm){pct=Math.min(99,Math.round(100*Number(mm[1])/Math.max(1,Number(mm[2]))));progress=mm[1]+'/'+mm[2]+' clips'}else if((j.message||'').includes('scene scan')){pct=2;progress='scene scan'}}
      let extra='';const now=Date.now()/1000;
      if(j.stage==='import'&&j.bytes_total){if(lastJobSample&&lastJobSample.id===j.id&&j.bytes_done>lastJobSample.bytes){const dt=now-lastJobSample.t,db=j.bytes_done-lastJobSample.bytes;if(dt>0){const sp=db/dt,eta=(j.bytes_total-j.bytes_done)/sp;extra=' · '+fmtBytes(sp)+'/s'+(eta>1?' · ETA '+fmtEta(eta):'')}lastJobSample={id:j.id,t:now,bytes:j.bytes_done}}else if(!lastJobSample||lastJobSample.id!==j.id){lastJobSample={id:j.id,t:now,bytes:j.bytes_done}}}
      else lastJobSample=null;
      txt.textContent='Job #'+j.id+' · '+(window.ME_L?ME_L(j.stage):j.stage)+' · '+progress+' · '+pct+'%'+extra;
      {const l=b.querySelector('a');if(l&&l.getAttribute('href')!=='/activity'){l.href='/activity';l.textContent=(window.ME_L?ME_L('Open activity'):'Open activity')}}
      const releasable=j.source_releasable&&j.status==='running';sub.textContent=(releasable?'SOURCE SAFE TO DISCONNECT · ':'')+(j.current_filename||j.message||'')+(j.failed?' · '+j.failed+' error(s)':'');bar.style.width=pct+'%';
    }else if(s.discovery&&s.discovery.running){b.style.display='block';txt.textContent='Discovering · '+(s.discovery.current_source||'');sub.textContent=s.discovery.found+' found';bar.style.width='0%';lastJobSample=null}
    else if(s.active_reel&&location.pathname!=='/auto/p/'+s.active_reel.project_id){   // a reel being made, seen from any page
      const a=s.active_reel;b.style.display='block';txt.textContent=(window.ME_L?ME_L('Making a reel'):'Making a reel')+': '+a.title+' · '+a.percent+'%';
      const L_=x=>window.ME_L?ME_L(x):x;
      sub.textContent=L_(a.stage)+(a.eta_min==null?'':' · '+(a.eta_min<1?L_('less than a minute left'):L_('about')+' '+a.eta_min+' '+L_('min left')));
      bar.style.width=a.percent+'%';lastJobSample=null;
      const l=b.querySelector('a');if(l){l.href='/auto/p/'+a.project_id;l.textContent=(window.ME_L?ME_L('Open the reel'):'Open the reel')}}
    else{b.style.display='none';lastJobSample=null}
  }catch(e){}
  setTimeout(pollJob,800)
}
async function pollSourceStatus(){
  const dots=[...document.querySelectorAll('[data-phone-dot]')],texts=[...document.querySelectorAll('[data-phone-text]')];if(!dots.length&&!texts.length)return;
  try{const r=await fetch('/api/source-status',{cache:'no-store'}),x=await r.json();for(const d of dots)d.classList.toggle('online',!!x.connected);for(const t of texts)t.textContent=x.connected?((x.model||x.serial||'Android')+' connected'):(String(x.error||'').includes('ADB not installed')?'Optional, not set up: copy the phone videos to this PC and choose that folder.':(x.error||'not connected'))}catch(e){for(const d of dots)d.classList.remove('online');for(const t of texts)t.textContent='status unavailable'}
  setTimeout(pollSourceStatus,3000)
}
async function quitApp(force=false){
  if(!force&&!confirm('Quit MediaEngine? Running work stops; you can start it again from the desktop shortcut.'))return;
  try{const r=await fetch('/api/app-control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'stop',force,close:true})});
    if(r.status===409){const x=await r.json();if(confirm((x.error||'Work is running.')+'\n\nQuit anyway? A reel being made is marked interrupted (Retry reuses its analysis); Library tasks, conversions and orders go on at the next start.'))return quitApp(true);return}}catch(e){}
  document.body.innerHTML="<div style='font:16px system-ui;padding:40px'>MediaEngine is closed. You can close this window.</div>";
}
window.addEventListener('DOMContentLoaded',()=>{const r=document.getElementById('restartBtn'),u=document.getElementById('updateBtn'),q=document.getElementById('quitBtn');if(r)r.onclick=()=>appControl('restart');if(u)u.onclick=()=>appControl('update');if(q)q.onclick=()=>quitApp();pollJob();pollSourceStatus()});
'''


# The colours: one dark base, and an accent per kind of work (Settings → Look): "sections" - Create warm, Videos teal,
# Tools amber, the rest blue-violet; "neon" - the same on true black, brighter, with a glow; "night" - one calm blue
# everywhere (as before). Set on <body data-theme=... data-tone=...> by layout(); everything else keeps its colours.
# The look (Settings → Look): ten modern colour schemes and the calm one of before. Each sets a dark base and four
# colours - Create, Videos, Tools and the rest (c1/c2/c3/c0): the page takes the colour of its menu group
# (<body data-tone=...>), so every kind of work has its own range. "night" keeps the original look (no overrides).
THEMES=('aurora','glass','tonal','banners','bento','neon','synthwave','sunset','ocean','acid','night')
THEME_INFO=(
    ('aurora','Aurora','Glowing colour clouds behind frosted cards.',('#ff4f9a','#ff9a3c','#22d3ee','#6366f1','#facc15','#a78bfa')),
    ('glass','Glass','Frosted glass over a bright wallpaper in each part’s colour.',('#ff6b6b','#c026d3','#06b6d4','#2563eb','#f59e0b','#6366f1')),
    ('tonal','Tonal','The whole page tinted in its part’s colour, round shapes.',('#ff8a65','#4dd0e1','#ffca28','#b39ddb')),
    ('banners','Banners','A big colour banner on top of every page, black below.',('#ff5a36','#1ed760','#ffc864','#509bf5')),
    ('bento','Bento','Bright pastel tiles and headers, large rounded blocks.',('#ff9fb2','#8ee3ef','#ffd670','#b9b4ff')),
    ('neon','Neon','Black with a grid and glowing neon outlines.',('#ff2bd6','#00f0ff','#faff00','#9d4dff')),
    ('synthwave','Synthwave','Purple night, pink and cyan, a sunset at the bottom.',('#ff2e97','#ff8a00','#00e5ff','#7c4dff','#b14dff')),
    ('sunset','Sunset','Warm: orange, coral and pink on deep plum.',('#ff7a3d','#e8455f','#ff5e9c','#b84ce0','#ffc23d')),
    ('ocean','Ocean','Deep sea blue with aqua and sky blue.',('#38bdf8','#818cf8','#2dd4bf','#22d3ee','#fbbf24')),
    ('acid','Acid','Black and white with acid orange, lime and yellow; sharp corners.',('#ff4d00','#c6ff00','#ffe600','#ffffff')),
    ('night','Calm night','One calm blue everywhere, as before.',('#7099ff','#5278df','#a78bfa','#6d96ff')),
)
THEME_CSS=r"""
body:not([data-theme=night]){--bg:#0b0d12;--bgimg:none;--side-bg:#0d1016;--side-line:#ffffff14;--blur:none;--card-bg:#151922;--card-line:#ffffff17;--card-shadow:0 10px 30px #0004;--radius:16px;--text:#f3f5f9;--muted:#9aa5b5;--input-bg:#0c0f15;--btn-bg:linear-gradient(135deg,var(--acc),var(--acc2));--on-acc:#fff;--btn-shadow:0 6px 20px color-mix(in srgb,var(--acc) 35%,transparent);--btn-r:10px;--side-text:#d4dae3;--nav-r:10px;--nav-active:color-mix(in srgb,var(--acc) 24%,transparent);--nav-active-text:#fff;--hero:none;--hero-pad:0;--hero-r:0;--hero-m:0 0 16px;--hero-shadow:none;--hero-text:var(--text);--hero-sub:var(--muted);--hero-eyebrow:var(--acc)}
body:not([data-theme=night])[data-tone=create]{--acc:var(--c1);--acc2:var(--c1b)}body:not([data-theme=night])[data-tone=videos]{--acc:var(--c2);--acc2:var(--c2b)}body:not([data-theme=night])[data-tone=tools]{--acc:var(--c3);--acc2:var(--c3b)}body:not([data-theme=night])[data-tone=base]{--acc:var(--c0);--acc2:var(--c0b)}
body:not([data-theme=night]){background-color:var(--bg);background-image:var(--bgimg);background-attachment:fixed;color:var(--text)}
body:not([data-theme=night]) .side{background:var(--side-bg);border-right:1px solid var(--side-line);backdrop-filter:var(--blur)}body:not([data-theme=night]) .mobilebar{background:var(--side-bg);border-bottom:1px solid var(--side-line);backdrop-filter:var(--blur)}
body:not([data-theme=night]) .card,body:not([data-theme=night]) .toolpanel,body:not([data-theme=night]) .media-card{background:var(--card-bg);border-color:var(--card-line);backdrop-filter:var(--blur);box-shadow:var(--card-shadow);border-radius:var(--radius)}
body:not([data-theme=night]) .callout{background:linear-gradient(color-mix(in srgb,var(--acc) 13%,transparent),color-mix(in srgb,var(--acc) 13%,transparent)),var(--card-bg);border-color:color-mix(in srgb,var(--acc) 45%,transparent)}
body:not([data-theme=night]) .muted,body:not([data-theme=night]) .lead{color:var(--muted)}body:not([data-theme=night]) h2,body:not([data-theme=night]) .section-title{color:var(--text)}
body:not([data-theme=night]) input,body:not([data-theme=night]) select,body:not([data-theme=night]) textarea{background:var(--input-bg);border-color:var(--card-line);color:var(--text)}body:not([data-theme=night]) input:focus,body:not([data-theme=night]) select:focus{border-color:var(--acc);box-shadow:0 0 0 3px color-mix(in srgb,var(--acc) 25%,transparent)}
body:not([data-theme=night]) button,body:not([data-theme=night]) .btn{background:var(--btn-bg);color:var(--on-acc);border-color:transparent;box-shadow:var(--btn-shadow);border-radius:var(--btn-r)}
body:not([data-theme=night]) .btn2,body:not([data-theme=night]) button.btn2{background:color-mix(in srgb,var(--acc) 14%,transparent);color:var(--text);border-color:color-mix(in srgb,var(--acc) 34%,transparent);box-shadow:none}
body:not([data-theme=night]) .ok{background:linear-gradient(180deg,#58c987,#3aa86a);color:#fff}body:not([data-theme=night]) .warn{background:linear-gradient(180deg,#d5a54e,#ae7b27);color:#fff}body:not([data-theme=night]) .danger{background:linear-gradient(180deg,#d66d77,#b44f5a);color:#fff}
body:not([data-theme=night]) .side .navlink{color:var(--side-text)!important;border-radius:var(--nav-r)}body:not([data-theme=night]) .side .navlink:hover{background:color-mix(in srgb,var(--acc) 14%,transparent)}
body:not([data-theme=night]) .side .navlink.active{background:var(--nav-active);border-color:color-mix(in srgb,var(--acc) 55%,transparent);color:var(--nav-active-text)!important}body:not([data-theme=night]) .side .navsub.active{background:color-mix(in srgb,var(--acc) 20%,transparent)}
body:not([data-theme=night]) .sidehead{color:var(--muted)}body:not([data-theme=night]) .sidehead[data-tone]:before{content:'';display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:8px;vertical-align:1px}
body:not([data-theme=night]) .sidehead[data-tone=create]:before{background:var(--c1);box-shadow:0 0 10px var(--c1)}body:not([data-theme=night]) .sidehead[data-tone=videos]:before{background:var(--c2);box-shadow:0 0 10px var(--c2)}body:not([data-theme=night]) .sidehead[data-tone=tools]:before{background:var(--c3);box-shadow:0 0 10px var(--c3)}
body:not([data-theme=night]) .eyebrow{color:var(--acc)}body:not([data-theme=night]) .brand:before{background:linear-gradient(135deg,var(--acc),var(--acc2));box-shadow:0 0 16px var(--acc)}body:not([data-theme=night]) .version{color:var(--muted);border-color:var(--card-line);background:transparent}
body:not([data-theme=night]) .pagehead{background:var(--hero);padding:var(--hero-pad);border-radius:var(--hero-r);margin:var(--hero-m);box-shadow:var(--hero-shadow)}body:not([data-theme=night]) .pagehead h1{color:var(--hero-text)}body:not([data-theme=night]) .pagehead .lead{color:var(--hero-sub)}body:not([data-theme=night]) .pagehead .eyebrow{color:var(--hero-eyebrow)}
body:not([data-theme=night]) .task{--task-bg:linear-gradient(150deg,color-mix(in srgb,var(--tone) 34%,transparent),color-mix(in srgb,var(--tone2) 10%,transparent) 72%),var(--card-bg);--task-text:var(--text);--task-sub:var(--muted);--task-line:color-mix(in srgb,var(--tone) 45%,transparent);--task-bar:4px;background:var(--task-bg);color:var(--task-text);border-color:var(--task-line)}
body:not([data-theme=night]) .task span{color:var(--task-sub)}body:not([data-theme=night]) .task:before{height:var(--task-bar);background:linear-gradient(90deg,var(--tone),var(--tone2))}body:not([data-theme=night]) .task:hover{border-color:var(--tone);box-shadow:0 0 26px color-mix(in srgb,var(--tone) 35%,transparent)}
body:not([data-theme=night]) .task[data-tone=create]{--tone:var(--c1);--tone2:var(--c1b)}body:not([data-theme=night]) .task[data-tone=videos]{--tone:var(--c2);--tone2:var(--c2b)}body:not([data-theme=night]) .task[data-tone=tools]{--tone:var(--c3);--tone2:var(--c3b)}
body:not([data-theme=night]) .workrow{border-color:var(--card-line)}body:not([data-theme=night]) .progress i{background:linear-gradient(90deg,var(--acc),var(--acc2))}

body[data-theme=aurora]{--bg:#070716;--c1:#ff4f9a;--c1b:#ff9a3c;--c2:#22d3ee;--c2b:#6366f1;--c3:#facc15;--c3b:#fb7185;--c0:#a78bfa;--c0b:#22d3ee;--bgimg:radial-gradient(900px 620px at 0% 0%,color-mix(in srgb,var(--acc) 55%,transparent),transparent 65%),radial-gradient(800px 620px at 100% 12%,color-mix(in srgb,var(--acc2) 45%,transparent),transparent 65%),radial-gradient(1100px 800px at 50% 115%,#7c3aed66,transparent 65%);--side-bg:#0a0a1e99;--side-line:#ffffff1a;--blur:blur(22px) saturate(140%);--card-bg:#ffffff0e;--card-line:#ffffff22;--muted:#c0c4de;--input-bg:#0a0a1e99;--radius:18px}
body[data-theme=glass]{--bg:#101018;--c1:#ff6b6b;--c1b:#c026d3;--c2:#06b6d4;--c2b:#2563eb;--c3:#f59e0b;--c3b:#ef4444;--c0:#6366f1;--c0b:#a855f7;--bgimg:radial-gradient(1100px 820px at 12% 8%,color-mix(in srgb,var(--acc) 88%,transparent),transparent 60%),radial-gradient(1100px 900px at 92% 92%,color-mix(in srgb,var(--acc2) 85%,transparent),transparent 62%),radial-gradient(700px 600px at 85% 5%,color-mix(in srgb,var(--acc) 45%,#ffffff 15%),transparent 60%),linear-gradient(135deg,#1c1b33,#0e0e1a);--card-bg:#ffffff1c;--card-line:#ffffff3a;--blur:blur(28px) saturate(170%);--side-bg:#ffffff14;--side-line:#ffffff30;--muted:#eef0f8d0;--text:#fff;--side-text:#fff;--input-bg:#00000038;--radius:22px;--btn-r:999px;--nav-r:14px;--card-shadow:0 18px 50px #0003}
body[data-theme=tonal]{--c1:#ff8a65;--c1b:#ff7043;--c2:#4dd0e1;--c2b:#26a69a;--c3:#ffca28;--c3b:#ffa000;--c0:#b39ddb;--c0b:#9575cd;--bg:color-mix(in srgb,var(--acc) 14%,#0d0d10);--side-bg:color-mix(in srgb,var(--acc) 24%,#0d0d10);--side-line:transparent;--card-bg:color-mix(in srgb,var(--acc) 18%,#18181c);--card-line:color-mix(in srgb,var(--acc) 28%,transparent);--card-shadow:none;--radius:24px;--muted:color-mix(in srgb,var(--acc) 35%,#b8b8c0);--input-bg:color-mix(in srgb,var(--acc) 10%,#0d0d10);--btn-bg:var(--acc);--on-acc:#1b1110;--btn-r:999px;--btn-shadow:none;--nav-r:999px;--nav-active:var(--acc);--nav-active-text:#1b1110;--hero:color-mix(in srgb,var(--acc) 30%,#151518);--hero-pad:26px;--hero-r:28px;--hero-m:0 0 18px}
body[data-theme=banners]{--bg:#121212;--c1:#ff5a36;--c1b:#e91e63;--c2:#1ed760;--c2b:#0d9488;--c3:#ffc864;--c3b:#ff8c00;--c0:#509bf5;--c0b:#8d67ab;--bgimg:linear-gradient(180deg,color-mix(in srgb,var(--acc) 50%,#121212) 0,#121212 520px);--side-bg:#000;--side-line:#000;--card-bg:#181818;--card-line:#282828;--card-shadow:none;--radius:10px;--muted:#b3b3b3;--btn-bg:var(--acc);--on-acc:#000;--btn-r:999px;--btn-shadow:none;--nav-active:#282828;--hero:linear-gradient(180deg,color-mix(in srgb,var(--acc) 85%,#000),color-mix(in srgb,var(--acc) 30%,transparent));--hero-pad:64px 28px 26px;--hero-r:0 0 16px 16px;--hero-m:-24px -20px 22px;--hero-text:#fff;--hero-sub:#ffffffd9;--hero-eyebrow:#ffffffe6}
body[data-theme=banners] .pagehead h1{font-size:46px;font-weight:900;letter-spacing:-1.2px}body[data-theme=banners] .pagehead .btn2{background:#00000040;color:#fff;border-color:#ffffff40}
body[data-theme=bento]{--bg:#0b0b0c;--c1:#ff9fb2;--c1b:#ffc2cf;--c2:#8ee3ef;--c2b:#bdf4f8;--c3:#ffd670;--c3b:#ffe7a8;--c0:#b9b4ff;--c0b:#d8d5ff;--card-bg:#161618;--card-line:#232326;--radius:26px;--card-shadow:none;--btn-bg:var(--acc);--on-acc:#141414;--btn-r:14px;--btn-shadow:none;--nav-active:var(--acc);--nav-active-text:#141414;--nav-r:14px;--hero:var(--acc);--hero-pad:30px;--hero-r:28px;--hero-text:#141414;--hero-sub:#141414cc;--hero-eyebrow:#14141499;--hero-m:0 0 18px}
body[data-theme=bento] .task{--task-bg:var(--tone);--task-text:#141414;--task-sub:#141414b3;--task-line:transparent;--task-bar:0px}body[data-theme=bento] .pagehead button,body[data-theme=bento] .pagehead .btn{background:#141414;color:#fff}body[data-theme=bento] .pagehead .ae-path,body[data-theme=bento] .pagehead .muted{color:#141414b3}
body[data-theme=neon]{--bg:#000;--c1:#ff2bd6;--c1b:#ff6ec7;--c2:#00f0ff;--c2b:#00a2ff;--c3:#faff00;--c3b:#ffb800;--c0:#9d4dff;--c0b:#5b8cff;--bgimg:radial-gradient(1100px 520px at 50% -140px,color-mix(in srgb,var(--acc) 42%,transparent),transparent 70%),repeating-linear-gradient(0deg,#ffffff08 0 1px,transparent 1px 44px),repeating-linear-gradient(90deg,#ffffff08 0 1px,transparent 1px 44px);--side-bg:#000;--side-line:color-mix(in srgb,var(--acc) 45%,transparent);--card-bg:#05060acc;--card-line:color-mix(in srgb,var(--acc) 60%,transparent);--card-shadow:0 0 22px color-mix(in srgb,var(--acc) 24%,transparent),inset 0 0 14px color-mix(in srgb,var(--acc) 10%,transparent);--radius:12px;--btn-shadow:0 0 20px color-mix(in srgb,var(--acc) 65%,transparent);--muted:#a9b6c8}
body[data-theme=neon][data-tone=tools]{--on-acc:#111}body[data-theme=neon] .pagehead h1{text-shadow:0 0 20px color-mix(in srgb,var(--acc) 75%,transparent)}
body[data-theme=synthwave]{--bg:#12002b;--c1:#ff2e97;--c1b:#ff8a00;--c2:#00e5ff;--c2b:#7c4dff;--c3:#ffb000;--c3b:#ff4d6d;--c0:#b14dff;--c0b:#ff2e97;--bgimg:radial-gradient(700px 360px at 50% 100%,#ff6a3d70,transparent 70%),linear-gradient(180deg,#12002b 0%,#240046 45%,#3c096c 78%,#7b1e7a 100%);--side-bg:#0e0024e8;--side-line:#ff2e9740;--card-bg:#1a0638cc;--card-line:color-mix(in srgb,var(--acc) 45%,transparent);--card-shadow:0 0 26px #ff2e9722;--muted:#cdb7ec;--input-bg:#0e0024;--radius:14px}
body[data-theme=synthwave] .pagehead h1{background:linear-gradient(90deg,var(--acc),var(--acc2));-webkit-background-clip:text;background-clip:text;color:transparent}
body[data-theme=sunset]{--bg:#170a12;--c1:#ff7a3d;--c1b:#e8455f;--c2:#ff5e9c;--c2b:#b84ce0;--c3:#ffc23d;--c3b:#ff8a3d;--c0:#f06292;--c0b:#ff8a65;--bgimg:radial-gradient(1100px 720px at 100% 0%,color-mix(in srgb,var(--acc) 45%,transparent),transparent 65%),radial-gradient(900px 620px at 0% 0%,color-mix(in srgb,var(--acc2) 38%,transparent),transparent 60%),linear-gradient(180deg,#1f0c18,#120810);--side-bg:#1a0b14ee;--side-line:#ff7a3d26;--card-bg:#2a1320cc;--card-line:color-mix(in srgb,var(--acc) 30%,transparent);--muted:#e0bcc2;--input-bg:#140810}
body[data-theme=sunset][data-tone=tools]{--on-acc:#2a1000}
body[data-theme=ocean]{--bg:#03121c;--c1:#38bdf8;--c1b:#818cf8;--c2:#2dd4bf;--c2b:#22d3ee;--c3:#fbbf24;--c3b:#f59e0b;--c0:#60a5fa;--c0b:#3b82f6;--bgimg:radial-gradient(1100px 720px at 0% 0%,color-mix(in srgb,var(--acc) 40%,transparent),transparent 62%),radial-gradient(900px 720px at 100% 100%,color-mix(in srgb,var(--acc2) 32%,transparent),transparent 60%),linear-gradient(180deg,#04182a,#020d16);--side-bg:#03111bdd;--side-line:#38bdf826;--card-bg:#0a2638b8;--card-line:color-mix(in srgb,var(--acc) 30%,transparent);--blur:blur(10px);--muted:#a7cfe0;--input-bg:#021019}
body[data-theme=ocean][data-tone=tools]{--on-acc:#1f1300}
body[data-theme=acid]{--bg:#0a0a0a;--c1:#ff4d00;--c1b:#ff4d00;--c2:#c6ff00;--c2b:#c6ff00;--c3:#ffe600;--c3b:#ffe600;--c0:#ffffff;--c0b:#e5e5e5;--card-bg:#111;--card-line:#2e2e2e;--radius:4px;--card-shadow:none;--btn-bg:var(--acc);--on-acc:#000;--btn-r:2px;--btn-shadow:4px 4px 0 #000;--nav-r:2px;--nav-active:var(--acc);--nav-active-text:#000;--side-bg:#000;--side-line:#2e2e2e;--muted:#a3a3a3}
body[data-theme=acid] .card{border-width:2px}body[data-theme=acid] .pagehead h1{text-transform:uppercase;font-weight:900;letter-spacing:-1px;font-size:42px}body[data-theme=acid] .task{--task-bg:#111;--task-bar:6px}body[data-theme=acid] .task b{color:var(--tone);text-transform:uppercase}
@media(max-width:850px){body[data-theme=banners] .pagehead{margin:-14px -14px 16px;padding:40px 16px 18px}}
.look-pick{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}.look-pick label{display:block;border:1px solid var(--card-line,#3a4758);border-radius:12px;padding:10px;cursor:pointer}
.look-pick input{margin-right:6px}.look-sw{display:flex;gap:5px;margin-top:8px}.look-sw i{display:block;height:22px;flex:1;border-radius:6px}
"""


SCALES=('auto','100','115','130','150')


def ui_scale() -> str:
    """The size of the whole interface (Settings → Look): 'auto' grows it with a wide screen, else a fixed percent."""
    try:
        v=str((load_config().get('ui') or {}).get('scale') or '')
    except Exception:
        v=''
    return v if v in SCALES else 'auto'


def ui_theme() -> str:
    try:
        t=str((load_config().get('ui') or {}).get('theme') or '')
    except Exception:
        t=''
    return t if t in THEMES else 'night'      # (the owner: the old look by default; the others in Settings → Look)


def _tone(path) -> str:
    """The kind of work a page belongs to (its menu group): create, videos, tools - or base."""
    for (head,items),tone in zip(MENU,('create','videos','tools')):
        if any(hit(path) for _l,_h,hit,_p in items):
            return tone
    return 'base'


_WORK_STATE={'done':('Ready','safe'),'failed':('Failed','error'),'working':('Working','review'),'waiting':('Waiting','review'),
             'stopped':('Stopped',''),'interrupted':('Stopped',''),'draft':('Draft','')}


def _recent_work(limit=8):
    """What was made lately in every part of the program, newest first: [{when, kind, title, state, href}]."""
    out=[]
    try:
        from . import voice as vo
        from .voice_web import _kind_label
        kinds={'cartoon_make':('Cartoon','/auto/cartoon/{}'),'cartoon_write':('Story','/auto/cartoon/{}'),
               'cartoon_study':('Studied video','/auto/cartoon/{}'),'clips_find':('Clips','/auto/clips/{}'),
               'handedit_render':('Edit by hand',None)}
        for j in vo.list_jobs(80):
            k=str(j.get('kind') or '')
            if k in kinds:
                label,href=kinds[k][0],(kinds[k][1].format(j['id']) if kinds[k][1] else f"/edit/{j.get('edit') or ''}")
            elif k in ('voiceover','captions','dub','render'):
                label,href=(_kind_label(j) or 'Voice-over'),'/auto/voice'
            else:
                continue
            title=(str(j.get('title') or '') or Path(str(j.get('video') or j.get('source') or '')).name
                   or str(j.get('text') or '')[:60] or label)
            out.append({'when':str(j.get('created_at') or ''),'kind':label,'title':title,'state':j.get('state') or '','href':href})
    except Exception:
        pass
    try:
        from . import auto_edit as ae
        st={'READY':'done','REVIEW':'done','PROCESSING':'working','ATTENTION':'failed'}
        for pr in ae.list_projects()[:20]:
            out.append({'when':str(pr.get('updated_at') or ''),'kind':'Reel','title':str(pr.get('title') or ''),
                        'state':st.get(pr.get('state'),'draft'),'href':f"/auto/p/{pr['id']}"})
    except Exception:
        pass
    try:
        from . import downloader as D
        for j in D.list_jobs(20):
            n=len(j.get('items') or [])
            out.append({'when':str(j.get('created_at') or ''),'kind':'Downloaded',
                        'title':(str(j.get('author') or (j.get('items') or [{}])[0].get('title') or j.get('title') or '')
                                 + (f" (+{n-1})" if n>1 else '')),
                        'state':j.get('state') or '','href':'/media/download'})
    except Exception:
        pass
    try:
        with db() as con:
            rows=con.execute("SELECT id,status,created_at,current_filename,total FROM jobs WHERE kind='convert' ORDER BY id DESC LIMIT 20").fetchall()
        st={'finished':'done','partial':'done','failed':'failed','running':'working','queued':'waiting','cancelled':'stopped'}
        for r in rows:
            out.append({'when':str(r['created_at'] or ''),'kind':'Conversion',
                        'title':(Path(str(r['current_filename'] or '')).name or f"#{r['id']}"),
                        'state':st.get(r['status'],''),'href':'/convert'})
    except Exception:
        pass
    out.sort(key=lambda x:x['when'],reverse=True)
    return out[:limit]


def _work_row(x):
    label,cls=_WORK_STATE.get(x['state'],('',''))
    return (f"<a class='workrow' href='{e(x['href'])}'><span class='badge'>{e(x['kind'])}</span>"
            f"<span class='worktitle' translate='no'>{e(x['title'])}</span>"
            f"<span class='muted worktime' translate='no'>{e(x['when'][:16].replace('T',' '))}</span>"
            + (f"<span class='badge {cls}'>{e(label)}</span>" if label else "") + "</a>")


def _nav_link(href,label,active=False,extra=''):
    cls=('navlink active' if active else 'navlink')+(' '+extra if extra else '')
    return f"<a class='{cls}' href='{href}'>{e(label)}</a>"


def _lang_button(path):
    back=request.full_path if request.query_string else path
    if request.method!='GET':          # a page made by a form (e.g. an error after Create): its address only accepts POST
        back='/auto' if path.startswith('/auto') else '/'
    ru=i18n.ui_language()=='ru'
    return (f"<form method='post' action='/lang' style='display:inline;margin:0'><input type='hidden' name='back' value='{e(back)}'>"
            f"<button class='btn2' translate='no' title='{'Переключить интерфейс на английский' if ru else 'Switch the interface to Russian'}'>{'English' if ru else 'Русский'}</button></form>")


def _data_note():
    """The remembered data folder (projects, exports) is not there right now (a disk not connected, a folder renamed):
    said on every page instead of silently showing an empty program."""
    from .config import DATA_ROOT_NOTE
    note=""
    if DATA_ROOT_NOTE:
        note+=("<div class='errbox' style='margin-bottom:12px'><b>Your projects are not shown.</b> "
               "<span>The data folder was not found:</span> <span class='ae-path' translate='no'>"+e(DATA_ROOT_NOTE.get('missing',''))+"</span>. "
               "<span>Connect that disk (or put the folder back) and restart MediaEngine. Until then an empty folder is used:</span> "
               "<span class='ae-path' translate='no'>"+e(DATA_ROOT_NOTE.get('using',''))+"</span></div>")
    try:
        from .backup import DB_PROBLEM
        if DB_PROBLEM:
            note+=("<div class='errbox' style='margin-bottom:12px'><b>The database may be damaged.</b> "
                   "<span>Copies of it are kept in the backups folder:</span> <span class='ae-path' translate='no'>"+e(DB_PROBLEM.get('backups',''))+"</span></div>")
    except Exception:
        pass
    return note


def _starts(path, *prefixes):
    return any(path==x or path.startswith(x.rstrip('/')+'/') for x in prefixes)


def _is_reel(p):
    return _starts(p,'/auto') and not _starts(p,'/auto/clips','/auto/voice','/auto/cartoon','/auto/check','/auto/orders','/auto/update')


# The menu: a column on the left (as video tools usually have), grouped by what one does - make something, work with
# the videos one has, small tools. The page open is lit; a place with parts of its own shows them under it while it is
# open. (label, address, is-this-page, parts: (label, address, is-this-part)). The pages' addresses never change.
MENU=[
    ('Create',[
        ('Auto Edit','/auto',_is_reel,[]),
        ('Clips from a long video','/auto/clips',lambda p:_starts(p,'/auto/clips'),[]),
        ('Voice-over and text','/auto/voice',lambda p:_starts(p,'/auto/voice'),[]),
        ('Cartoon Studio','/auto/cartoon',lambda p:_starts(p,'/auto/cartoon'),[
            ('My cartoons and stories','/auto/cartoon#films',
             lambda p:p.startswith('/auto/cartoon/') and not _starts(p,'/auto/cartoon/characters','/auto/cartoon/style')),
            ('Write a story','/auto/cartoon#writer',lambda p:False),
            ('Study a video','/auto/cartoon#study',lambda p:_starts(p,'/auto/cartoon/style')),
            ('New cartoon','/auto/cartoon#new',lambda p:False),
            ('Characters','/auto/cartoon/characters',lambda p:_starts(p,'/auto/cartoon/characters'))]),
        ('Edit by hand','/edit',lambda p:_starts(p,'/edit','/composer','/composition-file'),[])]),
    ('Videos',[
        ('Library','/library',lambda p:_starts(p,'/library','/item','/similar','/storyboard','/media')
                                       and not _starts(p,'/media/download'),[]),
        ('Import','/import',lambda p:_starts(p,'/import'),[]),
        ('Search','/search',lambda p:_starts(p,'/search'),[]),
        ('Best Moments','/best',lambda p:_starts(p,'/best','/clip','/clip-preview','/export-file'),[]),
        ('Download by a link','/media/download',lambda p:_starts(p,'/media/download'),[])]),
    ('Tools',[
        ('Convert','/convert',lambda p:_starts(p,'/convert'),[]),
        ('Check this PC','/auto/check',lambda p:_starts(p,'/auto/check'),[]),
        ('Orders from other programs','/auto/orders',lambda p:_starts(p,'/auto/orders'),[])]),
]
MENU_BOTTOM=[
    ('Activity','/activity',lambda p:_starts(p,'/activity','/jobs'),[]),
    ('Settings','/settings',lambda p:_starts(p,'/settings','/about','/help','/auto/update','/welcome'),[
        ('Setup & Connections','/settings/connections',lambda p:_starts(p,'/settings/connections')),
        ('Updates','/auto/update',lambda p:_starts(p,'/auto/update')),
        ('Help & Recovery','/help',lambda p:_starts(p,'/help','/welcome')),
        ('About','/about',lambda p:_starts(p,'/about'))]),
]


def _menu_item(path,label,href,hit,parts):
    on=hit(path)
    out=_nav_link(href,label,on)
    if on and parts:                        # the open place's own parts, under it
        out+=''.join(f"<a class='navlink navsub{' active' if h(path) else ''}' href='{href_}'>{e(l)}</a>" for l,href_,h in parts)
    return out


def _inbox_link(path):
    try:
        from . import inbox
        n=inbox.count_new()
    except Exception:
        n=0
    on=_starts(path,'/inbox')
    return (f"<a class='navlink{' active' if on else ''}' href='/inbox'><span>Inbox</span>"
            + (f" <span class='navbadge' translate='no'>{n}</span>" if n else "") + "</a>")


def _menu(path):
    groups=''.join(f"<div class='sidehead' data-tone='{tone}'>{e(head)}</div>"+''.join(_menu_item(path,*it) for it in items)
                   for (head,items),tone in zip(MENU,('create','videos','tools')))
    bottom=''.join(_menu_item(path,*it) for it in MENU_BOTTOM)
    # the rarely used places too - nothing folded away while there is room (the owner: "why fold it?")
    more=("<div class='sidehead'>Other</div>"
          + _nav_link('/social','Social Lab',path.startswith('/social'),'navextra')
          + _nav_link('/devices','Devices',path.startswith('/devices'),'navextra')
          + _nav_link('/cloud','Cloud',path.startswith('/cloud'),'navextra'))
    btns=(f"<div class='sidebtns'>{_lang_button(path)}{_update_button()}<button id='restartBtn' class='btn2'>Restart</button>"
          + ("<button id='updateBtn' class='ok'>Update</button>" if (INSTALL/'updater_config.json').exists()
             else "<button id='quitBtn' class='btn2' title='Stop MediaEngine on this PC'>Quit</button>") + "</div>")
    return (f"<aside class='side' id='side'><div class='sidetop'><a class='brand' href='/'>MediaEngine</a> "
            f"<span class='version' title='{e(str(INSTALL))}'>v{VERSION}{(' ' + BUILD) if BUILD else ''}</span></div>"
            f"<div class='sidenav'>{_nav_link('/','Home',path=='/')}{_inbox_link(path)}{groups}</div>"
            f"<div class='sidebottom'>{bottom}{more}{btns}</div></aside>")


def layout(title,body,script="",script_srcs=()):
    path=request.path
    external_scripts=''.join(f"<script src='{e(src)}'></script>" for src in script_srcs)
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{e(title)} · MediaEngine</title><link rel='icon' href='/favicon.ico'><style>{CSS}{THEME_CSS}</style></head><body data-theme='{ui_theme()}' data-tone='{_tone(path)}' data-scale='{ui_scale()}'>
<div class='app' id='app'>{_menu(path)}<div class='sideshade' onclick="document.getElementById('app').classList.remove('menu-open')"></div><div class='main'>
<div class='mobilebar'><button type='button' class='btn2' onclick="document.getElementById('app').classList.toggle('menu-open')">☰ Menu</button><a class='brand' href='/'>MediaEngine</a></div>
<div id='jobbar' class='jobbar'><div class='jobinner'><div class='row space'><b id='jobtext'>Working…</b><a href='/activity' class='muted'>Open activity</a></div><div id='jobsub' class='muted'></div><div class='progress'><i id='jobpct'></i></div></div></div>
<div class='wrap'>{_data_note()}{body}</div></div></div><div id='toast' class='toast'></div><script>{GLOBAL_JS}\n{script}</script>{external_scripts}</body></html>"""


def page_nav(page,pages,params=None):
    pages=max(1,int(pages or 1)); page=max(1,min(int(page or 1),pages))
    base={str(k):str(v) for k,v in (params or {}).items() if str(k)!='page' and v not in (None,'')}
    def href(p):
        return '?'+urllib.parse.urlencode({**base,'page':int(p)})
    nums={1,pages}
    for p in range(max(1,page-2),min(pages,page+2)+1):
        nums.add(p)
    nums=sorted(nums); links=[]; last=None
    for p in nums:
        if last is not None and p>last+1:
            links.append("<span class='muted'>…</span>")
        cls='btn' if p==page else 'btn btn2'
        links.append(f"<a class='{cls}' href='{href(p)}'>{p}</a>")
        last=p
    hidden=''.join(f"<input type='hidden' name='{e(k)}' value='{e(v)}'>" for k,v in base.items())
    return (f"<div class='pagination'><a class='btn btn2' href='{href(1)}'>First</a>"
            f"<a class='btn btn2' href='{href(max(1,page-1))}'>Previous</a>{''.join(links)}"
            f"<form method='get' class='row' style='margin:0'>{hidden}<span class='muted'>Page</span>"
            f"<input type='number' name='page' min='1' max='{pages}' value='{page}' style='width:78px'>"
            f"<span class='muted'>of {pages}</span><button class='btn2'>Go</button></form>"
            f"<a class='btn btn2' href='{href(min(pages,page+1))}'>Next</a>"
            f"<a class='btn btn2' href='{href(pages)}'>Last</a></div>")

def placeholder_svg(kind='video'):
    glyph='▶' if kind=='video' else '▧'; return f"<svg xmlns='http://www.w3.org/2000/svg' width='480' height='360'><rect width='100%' height='100%' fill='#0b0d10'/><text x='50%' y='50%' fill='#667180' font-size='54' text-anchor='middle' dominant-baseline='middle'>{glyph}</text></svg>"


def _spawn_launcher(mode):
    spawn_app_launcher(INSTALL, mode)


def _id_list(raw, limit=200):
    """Ids from "1,2,3" (a URL): plain digits that SQLite can look up only ("²" is a digit to Python, int() refuses it;
    a 30-digit number overflows SQLite) - a typed or damaged URL never gives a server error."""
    out=[]
    for x in str(raw or '').split(','):
        x=x.strip()
        if x.isascii() and x.isdigit() and 0<int(x)<2**63:
            out.append(int(x))
            if len(out)>=limit:break
    return out


def _remove_source(form) -> None:
    """Remove-source buttons: the row's position AND its path (a page left open since another source was removed must
    not remove the wrong one; a request without a position removes nothing)."""
    raw=str(form.get('index') or '').strip()
    if not (raw.isascii() and raw.isdigit()):
        return
    i=int(raw); want=form.get('path')
    def change(cfg):
        src=cfg.get('sources') or []
        if i<len(src) and (want is None or str(src[i].get('path') or '')==want):
            src.pop(i)
    update_config(change)


def _add_source(form) -> str:
    """Add a folder of videos as a source (Import and Settings): it must exist; stored as the full path, once.
    Returns an error text, or '' when added (or already there)."""
    # (a path copied with Windows' "Copy as path" comes in quotes, as in Auto Edit)
    p=str(form.get('path') or '').strip().strip('"').strip(); label=str(form.get('label') or '').strip()
    if not p:
        return 'Type the full path of the folder first.'
    try:
        pp=Path(os.path.expandvars(p)).expanduser()
        if not pp.is_absolute() or not pp.is_dir():
            return 'Folder not found: '+p
        norm=str(pp.resolve())
    except (OSError,ValueError):
        return 'Folder not found: '+p
    def change(cfg):
        if not any(str(Path(os.path.expandvars(str(s.get('path') or ''))).expanduser()).lower()==norm.lower()
                   for s in cfg.get('sources',[]) if s.get('path')):
            cfg.setdefault('sources',[]).append({'path':norm,'label':label or norm,'kind':'fixed','enabled':True})
    update_config(change)
    return ''


def _json_obj():
    """The request's JSON body when it is an object, else {} (a list or a number never reaches .get())."""
    d=request.get_json(silent=True)
    return d if isinstance(d,dict) else {}


def _autostart_box() -> str:
    """Start at sign-in (installed builds on Windows): a choice of the owner, off unless he turns it on."""
    if not (SIDE_BY_SIDE and os.name=='nt'):
        return ''
    from .platform_adapter import autostart_on
    return ("<input type='hidden' name='autostart_shown' value='1'><label><input type='checkbox' name='autostart' "
            + ("checked" if autostart_on() else "") + "> Start MediaEngine in the background when I sign in to Windows "
            "(icon in the tray; reels waiting from before a restart go on)</label><br>")


def _update_button() -> str:
    """The Update button of an installed MediaEngine: it asks GitHub for a newer build (only when pressed)."""
    if not SIDE_BY_SIDE:
        return ''
    return ("<form method='post' action='/auto/update/check' style='display:contents'>"
            "<button class='btn2' title='Look for a newer MediaEngine on GitHub'>Update</button></form>")


def busy_reason() -> str:
    """What a Quit (or a switch to another build) would stop right now, '' when nothing (Quit button, tray, launcher)."""
    with db() as con:
        busy=con.execute("SELECT id,kind,current_filename FROM jobs WHERE status='running' ORDER BY id LIMIT 1").fetchone()
        try:
            reel=con.execute("SELECT id FROM ae_jobs WHERE status IN ('running','queued') ORDER BY id LIMIT 1").fetchone()
        except Exception:
            reel=None
    if busy:
        return f"Job #{busy['id']} ({busy['kind']}) is running"
    if reel:
        return f"Auto Edit job #{reel['id']} is building a reel"
    try:
        from . import auto_edit as _ae
        if _ae.aiplus_downloading(): return "The AI+ model is being downloaded"
    except Exception:
        pass
    try:
        from . import aiplus_library as _al
        if _al.running(): return "AI+ is being prepared for the Library (it continues next time)"
    except Exception:
        pass
    try:
        from . import orders as _or
        if _or.busy(): return "An order from another program is being done (Auto Edit → Orders)"
    except Exception:
        pass
    try:
        from . import voice as _vo
        if _vo.installing(): return "The voice add-on is being installed (Auto Edit → Voice-over)"
        if _vo._writer_installing() and not _vo.busy_kind(): return "The story writer is being installed (Auto Edit → Cartoon Studio)"
        if _vo.busy(): return ("Clips are being made (Auto Edit → Clips from a long video)" if _vo.busy_kind() == "clips"
                               else "A cartoon is being made (Auto Edit → Cartoon Studio)" if _vo.busy_kind() == "cartoon"
                               else "A voice-over is being made (Auto Edit → Voice-over)")
    except Exception:
        pass
    try:
        from . import composer as _cp
        with _cp._ACTIVE_LOCK:
            if _cp._ACTIVE: return "A composition is being rendered (Composer)"
    except Exception:
        pass
    try:                                  # downloading / unpacking an update (not its last step, the switch itself)
        from . import updater as _up
        if _up.installing(): return "An update is being installed. Wait a minute."
    except Exception:
        pass
    return ''


def activity_line(ru: bool=False) -> str:
    """One short line on what runs right now, for the tray icon ('' = nothing a Quit would stop)."""
    try:
        with db() as con:
            rj=con.execute("SELECT j.*,p.title FROM ae_jobs j JOIN ae_projects p ON p.id=j.project_id "
                           "WHERE j.status IN ('running','queued') ORDER BY (j.status='running') DESC,j.id LIMIT 1").fetchone()
        if rj:
            d=dict(rj); t=str(d.get('title') or '')
            t=t if len(t)<=40 else t[:39]+'…'
            if d.get('status')=='running':
                from . import auto_edit as _ae
                pct=_ae.job_percent(d)
                return f"Собирается ролик «{t}»: {pct}%" if ru else f"Making a reel “{t}”: {pct}%"
            return f"Ролик «{t}» ждёт сборки" if ru else f"Reel “{t}” is waiting to be made"
    except Exception:
        pass
    try:
        r=busy_reason()
    except Exception:
        return ''
    if not r: return ''
    if r.startswith('Job #'):
        return 'Идёт задача Библиотеки (импорт или анализ)' if ru else 'A Library task is running (import or analysis)'
    if ru:
        try:
            from .i18n import translate_text
            return translate_text(r)
        except Exception:
            return r
    return r


def quit_soon(close_windows: bool=False) -> None:
    """Stop the program a moment from now (the answer to the page that asked gets out first)."""
    threading.Thread(target=_exit_soon,kwargs={'close_windows':bool(close_windows)},daemon=True,name='quit').start()


def _exit_soon(close_windows=False):
    time.sleep(.8)
    try:                                  # quitting on purpose: a build stopped now is not made again by itself
        from . import auto_edit as _ae
        _ae.mark_clean_exit()
    except Exception:
        pass
    try:                                  # the tray icon goes first (a dead one would stay until hovered); the
        from . import tray as _tr         # program's windows close with it when Quit was asked from a page or the tray
        if close_windows: _tr.close_app_windows()
        _tr.remove()
    except Exception:
        pass
    try:                                  # the AI+ preparation's engine step ends with the app
        from . import aiplus_library as _al
        _al.shutdown()
    except Exception:
        pass
    try:                                  # an order's FFmpeg too (the order is done again at the next start)
        from . import orders as _or
        _or.shutdown()
    except Exception:
        pass
    try:                                  # the phone's bot stops asking Telegram
        from . import telegram_bot as _tg
        _tg.stop(0.5)
    except Exception:
        pass
    try:                                  # a conversion's FFmpeg too (the conversion resumes at the next start)
        from . import converter as _cv
        _cv.shutdown()
    except Exception:
        pass
    try:                                  # a voice-over's worker or a video's FFmpeg too (made again at the next start)
        from . import voice as _vo
        _vo.shutdown()
    except Exception:
        pass
    os._exit(0)


_ALLOWED_LOOPBACK_HOSTS = frozenset((f'127.0.0.1:{APP_PORT}',f'localhost:{APP_PORT}'))
_MUTATING_METHODS = frozenset(('POST','PUT','PATCH','DELETE'))

def _exact_loopback_origin(value):
    text=str(value or '').strip()
    if not text:
        return None
    try:
        parsed=urllib.parse.urlsplit(text)
        port=parsed.port
    except (TypeError, ValueError):
        return None
    host=(parsed.hostname or '').lower()
    if parsed.scheme.lower()!='http' or host not in ('127.0.0.1','localhost') or port!=APP_PORT:
        return None
    if parsed.username or parsed.password:
        return None
    return (parsed.scheme.lower(),host,port)


def create_app():
    init_db(); ensure_media_brain_schema(); app=Flask(__name__)
    # a results CSV within its 128 KiB limit is up to ~650 KB once a browser has encoded the form (Cyrillic notes):
    # above Werkzeug's 500 KB default it got a bare "413 Request Entity Too Large" page
    app.config["MAX_FORM_MEMORY_SIZE"]=2*1024*1024
    i18n.install(app)   # Russian interface (optional): every page and API message translated after it is made

    @app.before_request
    def local_origin_guard():
        # Reject DNS-rebinding Host values before route dispatch. Browser mutations
        # must also come from the exact loopback origin; local service clients that
        # send no browser Origin/Referer remain compatible when Host is exact.
        host=(request.headers.get('Host') or '').strip().lower()
        if host not in _ALLOWED_LOOPBACK_HOSTS:
            return jsonify({'error':'Invalid Host'}),403
        # another web site may not embed the owner's videos or pictures, nor make this app work (thumbnails, adb, AI+
        # search for an <img> loop): a request another site's page makes is refused - only a link that opens the
        # app's start pages in the browser (a top-level navigation) is let through
        sfs=request.headers.get('Sec-Fetch-Site','')
        if sfs=='cross-site' and not (request.method=='GET' and request.headers.get('Sec-Fetch-Mode','')=='navigate'
                                      and request.path in ('/','/auto')):
            return jsonify({'error':'Cross-site request blocked'}),403
        if request.method not in _MUTATING_METHODS:
            return None
        if sfs and sfs not in ('same-origin','none'):    # (the browser sets it; an old browser without Origin is covered)
            return jsonify({'error':'Cross-origin request blocked'}),403
        origin=request.headers.get('Origin','')
        referer=request.headers.get('Referer','')
        # "Origin: null" from this app's own page (a stricter browser setting): Sec-Fetch-Site is set by the browser
        # itself and cannot be faked by another site
        if origin=='null' and request.headers.get('Sec-Fetch-Site','')=='same-origin':
            origin=''
        if origin and _exact_loopback_origin(origin) is None:
            return jsonify({'error':'Cross-origin request blocked'}),403
        if not origin and referer and _exact_loopback_origin(referer) is None:
            return jsonify({'error':'Cross-origin request blocked'}),403
        return None

    @app.after_request
    def no_framing(resp):
        # no other page can show MediaEngine in a frame (and trick a click), nothing is shared with other sites
        resp.headers.setdefault('X-Frame-Options','DENY')
        resp.headers.setdefault('Content-Security-Policy',"frame-ancestors 'none'")
        resp.headers.setdefault('Cross-Origin-Resource-Policy','same-origin')
        # same-origin, not no-referrer: with no-referrer a browser sends "Origin: null" with every form, and the
        # guard above refused every button that posts a form (found by a browser check, before any release)
        resp.headers.setdefault('Referrer-Policy','same-origin')
        resp.headers.setdefault('X-Content-Type-Options','nosniff')
        return resp

    @app.get('/api/ping')
    def ping():   # loopback only
        from . import tray as _tr
        return jsonify({'ok':True,'version':VERSION,'build':BUILD,'install':str(INSTALL),'tray':_tr.STATE.get('state')})

    @app.get('/diagnostics/fixture.mp4')
    def diagnostics_fixture():
        p=Path(__file__).resolve().parent/'assets'/'browser_fixture_h264.mp4'
        return send_file(p,mimetype='video/mp4',conditional=True)

    @app.get('/diagnostics/browser')
    def diagnostics_browser():
        # Self-contained real-browser fixture. It never touches user media.
        return """<!doctype html><html><head><meta charset="utf-8"><style>
        body{margin:0;background:#090d12;color:#fff;font:15px system-ui}.stage{width:720px;margin:30px auto}.viewport{background:#000;width:640px;aspect-ratio:16/9;overflow:hidden}.viewport canvas{width:100%;height:100%}.seek{position:relative;width:520px;height:26px;margin-top:20px}.track{position:absolute;left:0;right:0;top:11px;height:4px;background:#263244}.thumb{position:absolute;left:0;top:5px;width:16px;height:16px;border-radius:50%;background:#eaf7ff}.seek input{position:absolute;inset:0;width:100%;height:26px;opacity:0;margin:0;padding:0}video{position:fixed;width:2px;height:2px;opacity:.01;left:-10px}</style></head><body>
        <div class="stage"><div class="viewport" id="vp"><canvas id="cv"></canvas></div><div class="seek" id="seek"><div class="track"></div><div class="thumb" id="thumb"></div><input id="range" type="range" min="0" max="1000" value="0"></div></div>
        <video id="video" muted playsinline preload="auto" src="/diagnostics/fixture.mp4"></video><pre id="diag-result">running</pre>
        <script>
        (async()=>{const checks=[],video=document.getElementById('video'),canvas=document.getElementById('cv'),ctx=canvas.getContext('2d'),out=document.getElementById('diag-result');
        const add=(name,pass,detail)=>checks.push({name,pass:Boolean(pass),detail});const wait=(test,ms=8000)=>new Promise((resolve,reject)=>{const end=Date.now()+ms;(function tick(){if(test())return resolve();if(Date.now()>end)return reject(new Error('timeout'));setTimeout(tick,40)})()});
        try{await wait(()=>video.readyState>=1);add('metadata',video.videoWidth===640&&video.videoHeight===360,{w:video.videoWidth,h:video.videoHeight,duration:video.duration});
        await video.play();await wait(()=>video.currentTime>.35);canvas.width=640;canvas.height=360;ctx.drawImage(video,0,0);const px=ctx.getImageData(0,0,640,360).data;let bright=0,diff=0,prev=px[0];for(let i=0;i<px.length;i+=64){bright+=px[i]+px[i+1]+px[i+2];diff+=Math.abs(px[i]-prev);prev=px[i]}add('canvas_non_black',bright>250000&&diff>2000,{brightness:bright,difference:diff,time:video.currentTime});video.pause();
        video.currentTime=1.25;await wait(()=>Math.abs(video.currentTime-1.25)<.15);add('seek',true,{time:video.currentTime});video.currentTime=0;await video.play();await wait(()=>video.currentTime>.12);add('replay_from_zero',video.currentTime<.85,{time:video.currentTime});video.pause();
        const s=document.getElementById('seek').getBoundingClientRect(),t=document.getElementById('thumb').getBoundingClientRect();add('scrubber_physical_zero',Math.abs(t.left-s.left)<=.5,{delta:t.left-s.left});
        for(const pair of [[16,9],[4,5],[1,1],[9,16]]){canvas.width=pair[0]*40;canvas.height=pair[1]*40;add('aspect_'+pair.join(':'),Math.abs(canvas.width/canvas.height-pair[0]/pair[1])<.001,{w:canvas.width,h:canvas.height})}
        }catch(e){add('browser_exception',false,String(e))}const pass=checks.every(x=>x.pass);out.dataset.status=pass?'passed':'failed';out.textContent=JSON.stringify({status:pass?'passed':'failed',edge_version:navigator.userAgent,checks});})();
        </script></body></html>"""

    @app.get('/favicon.ico')
    def favicon():
        # the tab icon (an asked-for icon that is not there was an error in the browser console)
        svg=("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>"
             "<stop offset='0' stop-color='#6d96ff'/><stop offset='1' stop-color='#a78bfa'/></linearGradient></defs>"
             "<rect width='64' height='64' rx='14' fill='#0f151d'/><circle cx='32' cy='32' r='15' fill='url(#g)'/>"
             "<path d='M27 24l13 8-13 8z' fill='#fff'/></svg>")
        return Response(svg,mimetype='image/svg+xml',headers={'Cache-Control':'max-age=86400'})

    @app.get('/api/status')
    def status():
        snap=STATE.snapshot()
        with db() as con:
            j=con.execute("SELECT * FROM jobs WHERE status='running' ORDER BY id LIMIT 1").fetchone()
            if not j: j=con.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY id LIMIT 1").fetchone()
            queued=con.execute("SELECT COUNT(*) n FROM jobs WHERE status='queued'").fetchone()['n']
        snap['active_job']={k:j[k] for k in j.keys()} if j else None
        if snap['active_job'] and snap['active_job'].get('source_releasable'):
            from .service import transfers_pending   # another import still copies from that card: not safe yet
            if transfers_pending(): snap['active_job']['source_releasable']=0
        snap['queued_jobs']=queued
        try:     # a reel being made (Auto Edit), so the bar at the top shows it on every page
            from . import auto_edit as _ae
            with db() as con:
                rj=con.execute("SELECT j.*,p.title FROM ae_jobs j JOIN ae_projects p ON p.id=j.project_id WHERE j.status='running' ORDER BY j.id LIMIT 1").fetchone()
            if rj:
                d=dict(rj)
                from .auto_edit_web import stage_eta_s as _eta
                left=_eta(d)
                snap['active_reel']={'project_id':int(d['project_id']),'title':d['title'],'percent':_ae.job_percent(d),
                                     'stage':_ae.STAGE_LABEL.get(d.get('stage') or '',''),
                                     'eta_min':(None if left is None else int(round(left/60)))}
        except Exception:
            pass
        return jsonify(snap)

    @app.post('/api/app-control')
    def app_control():
        payload=_json_obj();mode=payload.get('mode','restart');force=bool(payload.get('force'))
        if mode not in ('restart','update','stop'): return jsonify({'ok':False,'error':'bad mode'}),400
        reason='' if force else busy_reason()
        if reason: return jsonify({'ok':False,'error':reason}),409
        if mode!='stop': _spawn_launcher(mode)
        # Quit from a page closes its window too (as any program does); a switch to another build leaves it open
        quit_soon(close_windows=(mode=='stop' and payload.get('close') is True)); return jsonify({'ok':True})

    def phone_snapshot():
        adb=android.find_adb()
        devs,err=android.adb_devices_now(adb)      # never waits for adb (a hung adb froze every page)
        phone=next((d for d in devs if d.get('state')=='device'),None)
        return {
            'connected':bool(phone),
            'serial':phone.get('serial','') if phone else '',
            'model':phone.get('model','') if phone else '',
            'error':None if phone else (err or 'not connected'),
        }

    @app.get('/api/source-status')
    def source_status():
        return jsonify(phone_snapshot())

    def _library_figures():
        """The Library's figures and the Android source (the Media overview)."""
        local_sql="excluded=0 AND work_selected=1 AND private_path IS NULL AND rejected_path IS NULL AND analysis_status<>'private' AND COALESCE(sha256,'') NOT IN (SELECT sha256 FROM ignored_hashes) AND (source_kind='fixed' OR staging_path IS NOT NULL OR archive_path IS NOT NULL)"
        with db() as con:
            metrics=con.execute(f"""SELECT
                SUM(CASE WHEN excluded=0 AND private_path IS NULL AND analysis_status<>'private' THEN 1 ELSE 0 END) total,
                SUM(CASE WHEN {local_sql} THEN 1 ELSE 0 END) imported,
                SUM(CASE WHEN {local_sql} AND media_type='video' THEN 1 ELSE 0 END) videos,
                SUM(CASE WHEN excluded=0 AND work_selected=0 AND source_kind IN ('android','removable','fixed') AND private_path IS NULL AND rejected_path IS NULL AND analysis_status<>'private' THEN 1 ELSE 0 END) waiting,
                SUM(CASE WHEN {local_sql} AND analysis_status='review' THEN 1 ELSE 0 END) review,
                SUM(CASE WHEN {local_sql} AND rights_status IN ('review','permission','blocked') THEN 1 ELSE 0 END) rights_review,
                SUM(CASE WHEN excluded=0 AND (import_status='error' OR analysis_status='error') THEN 1 ELSE 0 END) errs
                FROM inventory""").fetchone()
            try:     # reels made with Auto Edit (the rights review count meant nothing for home videos)
                reels=int(con.execute("SELECT COUNT(*) FROM ae_projects WHERE archived=0").fetchone()[0])
            except Exception:
                reels=0
            total=int(metrics['total'] or 0);imported=int(metrics['imported'] or 0);videos=int(metrics['videos'] or 0)
            waiting=int(metrics['waiting'] or 0);review=int(metrics['review'] or 0);rights=int(metrics['rights_review'] or 0);errs=int(metrics['errs'] or 0)
        phone=phone_snapshot(); phone_text=(phone.get('model') or phone.get('serial') or 'Android')+' connected' if phone['connected'] else (phone.get('error') or 'not connected')
        if not phone['connected'] and 'ADB not installed' in str(phone.get('error') or ''):
            phone_text='Optional, not set up: copy the phone videos to this PC and choose that folder.'   # not an error
        return dict(total=total,imported=imported,videos=videos,waiting=waiting,review=review,errs=errs,reels=reels,phone=phone,phone_text=phone_text)

    def _inbox_note():
        try:
            from . import inbox
            n=inbox.count_new()
        except Exception:
            n=0
        return (f"<a class='card callout' href='/inbox' style='display:block;margin-bottom:14px'><b>Inbox:</b> "
                f"<span translate='no'>{n}</span> <span>new</span> <span class='muted'>— links and topics sent to MediaEngine. Open</span></a>") if n else ''

    @app.get('/')
    def dashboard():
        from .auto_edit_web import whats_new_card, first_time_card
        tiles=(('create','/auto','Auto Edit','A folder of your videos → a finished reel of the best moments.'),
               ('create','/auto/clips','Clips from a long video','A podcast, a stream or an interview → short vertical clips with captions.'),
               ('create','/auto/voice','Voice-over and text','A voice reads your text; captions word by word; titles on a video.'),
               ('create','/auto/cartoon','Cartoon Studio','A short 2D cartoon: the story written for you, drawn, voiced, with captions.'),
               ('videos','/media/download','Download by a link','A video, or a profile’s videos, from YouTube, TikTok and other sites.'),
               ('tools','/convert','Convert','Smaller copies to share: for a messenger, or to a size in MB.'))
        grid=''.join(f"<a class='card task' data-tone='{t}' href='{h}'><b>{e(n)}</b><span>{e(d)}</span></a>" for t,h,n,d in tiles)
        work=_recent_work(8)
        recent=(''.join(_work_row(x) for x in work) if work else
                "<div class='muted'>Nothing made yet: choose what to make above.</div>")
        try:
            with db() as con:
                n_lib=int(con.execute("SELECT COUNT(*) FROM inventory WHERE excluded=0 AND work_selected=1 AND private_path IS NULL "
                                      "AND rejected_path IS NULL AND media_type='video'").fetchone()[0])
        except Exception:
            n_lib=0
        body=(f"<div class='pagehead'><div class='eyebrow'>MediaEngine</div><h1>What shall we make?</h1>"
              f"<div class='lead'>Everything is made on this PC: your videos are only read and never changed, nothing is sent anywhere.</div></div>"
              f"{first_time_card()}{whats_new_card(e)}{_inbox_note()}<div class='taskgrid'>{grid}</div>"
              f"<div class='card' style='margin-top:16px'><div class='row space'><h2 style='margin:0'>Recent work</h2>"
              f"<a class='muted' href='/activity'>All work</a></div><div class='worklist'>{recent}</div></div>"
              f"<div class='row muted' style='margin-top:14px;font-size:14px;gap:14px'>"
              f"<a href='/media'><span>Library:</span> <span translate='no'>{n_lib}</span> <span>videos</span></a>"
              f"<a href='/import'>Import from a phone, a card or a folder</a><a href='/auto/check'>Check this PC</a></div>")
        return layout('Home',body)

    @app.get('/media')
    def media_hub():
        f=_library_figures(); phone=f['phone']
        body=f"""<div class='pagehead'><div class='eyebrow'>Videos</div><h1>Media</h1><div class='lead'>Your videos for work: what is on the sources, what is in the Library, where to find the best moments.</div></div>
<div class='hero'><div class='card metric tone-blue'><span class='muted'>On sources</span><b>{f['total']}</b></div><div class='card metric tone-amber'><span class='muted'>Waiting to import</span><b>{f['waiting']}</b></div><div class='card metric tone-mint'><span class='muted'>In Library</span><b>{f['imported']}</b></div><div class='card metric tone-cyan'><span class='muted'>Library videos</span><b>{f['videos']}</b></div><div class='card metric tone-rose'><span class='muted'>Privacy review</span><b>{f['review']}</b></div><a class='card metric tone-violet' href='/auto'><span class='muted'>Reel projects</span><b>{f['reels']}</b></a></div>
<div class='card source-card'><div class='device'><span class='device-dot {'online' if phone['connected'] else ''}' data-phone-dot></span><div><div class='device-status'>Android source</div><div class='muted' data-phone-text>{e(f['phone_text'])}</div></div></div><div class='row'><span class='badge {'error' if f['errs'] else 'safe'}'>{f['errs']} errors</span><a class='btn btn2' href='/jobs'>Jobs</a></div></div>
<div class='hubgrid' style='margin-top:14px'>
<a class='card hubcard' href='/library'><b>Library</b><span>The media you explicitly selected for work.</span></a>
<a class='card hubcard' href='/import'><b>Import</b><span>Browse folders, Android and removable sources.</span></a>
<a class='card hubcard' href='/search'><b>Search</b><span>Local semantic signals and Find Similar.</span></a>
<a class='card hubcard' href='/best'><b>Best Moments</b><span>Review Media Brain virtual clips.</span></a>
<a class='card hubcard' href='/media/download'><b>Download by a link</b><span>A video or a profile's videos from YouTube, TikTok and other sites.</span></a>
</div>
<div class='section-title'>How it works</div><div class='card callout'>Browse every source in <b>Import</b> → select what you want → <b>Add to Library</b> or <b>Add + Analyze</b>. Files in folders on this PC stay in place; files from a phone, SD card or USB stick (also a folder added there) copy to Staging. Private and Rejected media never appear in Library.</div>"""
        return layout('Media',body)

    @app.get('/social')
    def social_hub():
        ensure_social_schema();stats=publication_stats();pubs=list_publications(10);comps=recent_rendered_compositions(10)
        body=f"<div class='pagehead'><div class='eyebrow'>Local-first</div><h1>Social Lab</h1><div class='lead'>Publication history and structural Novelty Guard are local. No social account is connected and nothing is published automatically.</div></div><div class='about-grid'><div class='card'><div class='kpi'>{int(stats['publications'])}</div><div class='muted'>history records</div></div><div class='card'><div class='kpi'>{int(stats['novelty_checks'])}</div><div class='muted'>novelty checks</div></div><div class='card'><b>Novelty Guard v1</b><div class='muted'>Exact hash + structural overlap + visual_dhash_v1 + local audio_spectrum_v1. Audio alone can request review but cannot block unless another strong similarity signal agrees.</div></div></div><div class='card' style='margin-top:14px'><h2>Rendered compositions</h2>"
        if not comps:body+="<div class='muted'>No finished local compositions yet.</div>"
        for c in comps:body+=f"<div class='row space' style='padding:8px 0;border-bottom:1px solid #223'><div><b>{e(c['title'])}</b><div class='muted'>{e(c['aspect'])}</div></div><form method='post' action='/social/check/{int(c['id'])}'><button class='btn btn2'>Check novelty</button></form><form method='post' action='/social/queue/{int(c['id'])}'><button class='btn btn2'>Queue</button></form></div>"
        body+="</div><div class='card' style='margin-top:14px'><h2>Publication history</h2>"
        if not pubs:body+="<div class='muted'>History is empty. A novelty check does not publish anything.</div>"
        for p in pubs:body+=f"<div class='row space' style='padding:8px 0;border-bottom:1px solid #223'><div><b>{e(p.get('title') or 'Untitled')}</b><div class='muted'>{e(p.get('status') or '')} - {e(p.get('platform') or 'local/manual')}</div></div><span class='badge'>{e(p.get('novelty_state') or 'recorded')}</span></div>"
        body+="</div><div class='card callout' style='margin-top:14px'><b>Privacy boundary:</b><div class='muted'>Publication history and detailed novelty signals stay in the local MediaEngine database. Nothing is sent anywhere.</div></div>"
        queue=list_social_queue(30)
        body+="<div class='card' style='margin-top:14px'><h2>Content queue</h2>"
        if not queue:body+="<div class='muted'>Queue is empty.</div>"
        for q in queue:
            body+=f"<div class='row space' style='padding:8px 0;border-bottom:1px solid #223'><div><b>{e(q.get('title') or 'Untitled')}</b><div class='muted'>{e(q['queue_state'])} · novelty {e(q['novelty_state'])}</div></div>"
            if q['queue_state']=='review':body+=f"<form method='post' action='/social/queue-item/{int(q['id'])}/ready'><button class='btn btn2'>Mark ready</button></form>"
            elif q['queue_state']=='ready':body+=f"<form method='post' action='/social/queue-item/{int(q['id'])}/review'><button class='btn btn2'>Review</button></form>"
            elif q['queue_state']=='hold':body+="<span class='badge'>hold</span>"
            if q['queue_state'] in ('ready','review','hold'):     # (a held item could not be taken out of the queue)
                body+=(f"<form method='post' action='/social/queue-item/{int(q['id'])}/canceled'><button class='btn2'>Remove from queue</button></form>"
                       + (f"<form method='post' action='/social/queue-item/{int(q['id'])}/done'><button class='btn2'>Done</button></form>" if q['queue_state']=='ready' else ""))
            body+="</div>"
        body+="</div>"
        body+="<div class='card callout' style='margin-top:14px'><div class='row space'><div><b>Experiments</b><div class='muted'>Plan hook/caption/cover/duration/order variants and record manual/import performance metrics locally.</div></div><a class='btn btn2' href='/social/experiments'>Open Experiments</a></div></div>"
        body+="<div class='card callout' style='margin-top:14px'><div class='row space'><div><b>Manual handoff</b><div class='muted'>Create a local manifest for manual upload. No provider API, token or automatic publishing is used.</div></div><a class='btn btn2' href='/social/manual-handoff'>Open Manual Handoff</a></div></div>"
        return layout('Social Lab',body)

    @app.post('/social/check/<int:composition_id>')
    def social_check(composition_id):
        try:
            x=candidate_from_composition(composition_id);r=evaluate_social_composition(composition_id);state=r['state']
            body=f"<div class='pagehead'><div class='eyebrow'>Novelty Guard</div><h1>{e(state)}</h1><div class='lead'>Compared locally with {int(r['compared_count'])} history records.</div></div><div class='card'><b>{e(x['title'])}</b><div class='muted'>Source overlap {float(r['source_overlap']):.0%} - sequence similarity {float(r['sequence_similarity']):.0%} - visual {float(r.get('max_visual_similarity') or 0):.0%} - audio {float(r.get('max_audio_similarity') or 0):.0%}</div><div style='margin-top:12px'><form method='post' action='/social/record/{int(composition_id)}'><button>Record in local history</button></form><a class='btn btn2' href='/social'>Back</a></div></div>"
            return layout('Novelty check',body)
        except Exception as exc:return layout('Novelty check failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/social'>Back</a></div>"),400

    @app.post('/social/record/<int:composition_id>')
    def social_record(composition_id):
        try:
            r=record_social_composition(composition_id,status='exported')
            return layout('Recorded',f"<div class='pagehead'><div class='eyebrow'>Local history</div><h1>Recorded</h1><div class='lead'>Added to local history only. Nothing was sent to a social platform.</div></div><div class='card'><b>Novelty state: {e(r['novelty']['state'])}</b><div style='margin-top:12px'><a class='btn btn2' href='/social'>Back to Social Lab</a></div></div>")
        except Exception as exc:return layout('Record failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/social'>Back</a></div>"),400

    @app.post('/social/queue/<int:composition_id>')
    def social_queue_add(composition_id):
        try:
            r=enqueue_social_composition(composition_id)
            return layout('Queued',f"<div class='pagehead'><div class='eyebrow'>Content Queue</div><h1>{e(r['queue_state'])}</h1><div class='lead'>Queued locally. Nothing was sent to any platform.</div></div><div class='card'><b>Novelty: {e(r['novelty']['state'])}</b><div style='margin-top:12px'><a class='btn btn2' href='/social'>Back to Social Lab</a></div></div>")
        except Exception as exc:return layout('Queue failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/social'>Back</a></div>"),400

    @app.post('/social/queue-item/<int:queue_id>/<state>')
    def social_queue_state(queue_id,state):
        try:
            set_social_queue_state(queue_id,state)
            return redirect('/social')
        except Exception as exc:return layout('Queue update failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/social'>Back</a></div>"),400


    @app.get('/social/manual-handoff')
    def social_manual_handoff():
        comps=recent_rendered_compositions(50);connectors=m12_connector_catalog()
        body="<div class='pagehead'><div class='eyebrow'>Safe fallback</div><h1>Manual social handoff</h1><div class='lead'>Generate a local JSON manifest beside your workflow. MediaEngine does not upload media, call a provider API or use credentials.</div></div><form class='card' method='post' action='/social/manual-handoff'><select name='composition_id' required><option value=''>Choose rendered composition</option>"
        for c in comps:body+=f"<option value='{int(c['id'])}'>{e(c['title'])} · {e(c['aspect'])}</option>"
        body+="</select><select name='platform_target'><option value='other'>Other / manual</option>"
        for c in connectors:body+=f"<option value='{e(c['id'])}'>{e(c['name'])}</option>"
        body+="</select><textarea name='caption_text' rows='4' style='width:100%;margin-top:8px' placeholder='Caption / notes'></textarea><div style='margin-top:8px'><button>Create local handoff manifest</button></div></form><div class='card callout' style='margin-top:12px'><b>No automatic publishing.</b><div class='muted'>Blocked Novelty Guard items cannot generate a handoff. Similar-review items require this explicit manual action.</div></div><a class='btn btn2' href='/social'>Back to Social Lab</a>"
        return layout('Manual social handoff',body)

    @app.post('/social/manual-handoff')
    def social_manual_handoff_create():
        try:
            result=create_manual_handoff_for_composition(int(request.form.get('composition_id') or 0),request.form.get('platform_target','other'),request.form.get('caption_text',''))
            body=f"<div class='pagehead'><div class='eyebrow'>Local manifest</div><h1>Handoff ready</h1><div class='lead'>Nothing was uploaded. Use the local rendered media plus this manifest for manual publishing.</div></div><div class='card'><b>Target: {e(result['platform_target'])}</b><div class='muted'>Manifest: {e(result['manifest_path'])}</div><div class='muted'>Media: {e(result['media_path'])}</div><div class='muted'>Novelty: {e(result['novelty_state'])}</div><div style='margin-top:10px'><a class='btn btn2' href='/social/manual-handoff'>Back</a></div></div>"
            return layout('Handoff ready',body)
        except Exception as exc:
            return layout('Handoff blocked',f"<div class='card'><div class='errbox'>{e(str(exc)[:1000])}</div><a class='btn btn2' href='/social/manual-handoff'>Back</a></div>"),400


    @app.get('/social/experiments')
    def social_experiments():
        ensure_experiment_schema();rows=list_social_experiments(50);comps=recent_rendered_compositions(30);stats=experiment_stats()
        body=f"<div class='pagehead'><div class='eyebrow'>Local experiments</div><h1>Experiments</h1><div class='lead'>Plan metadata variants and record manual/import performance results locally. No social account or publishing connector is used.</div></div><div class='about-grid'><div class='card'><b>{int(stats['experiments'])}</b><div class='muted'>experiments</div></div><div class='card'><b>{int(stats['variants'])}</b><div class='muted'>variants · {int(stats['results'])} result rows</div></div></div>"
        body+="<form class='card toolbar' method='post' action='/social/experiments/create'><input name='title' placeholder='Experiment title' maxlength='160'><input name='objective' placeholder='Objective / hypothesis' maxlength='500'><select name='composition_id'><option value=''>No base composition</option>"
        for c in comps:body+=f"<option value='{int(c['id'])}'>{e(c['title'])} · {e(c['aspect'])}</option>"
        body+="</select><button>Create</button></form><div class='jobs'>"
        if not rows:body+="<div class='empty'>No experiments yet.</div>"
        for x in rows:body+=f"<a class='card row space' href='/social/experiments/{int(x['id'])}'><div><b>{e(x['title'])}</b><div class='muted'>{e(x['status'])} · {int(x['variant_count'])} variants · {int(x['result_count'])} result rows</div></div><span class='btn btn2'>Open</span></a>"
        body+="</div><div style='margin-top:14px'><a class='btn btn2' href='/social'>Back to Social Lab</a></div>"
        return layout('Experiments',body)

    @app.post('/social/experiments/create')
    def social_experiment_create():
        try:
            eid=create_social_experiment(request.form.get('title',''),request.form.get('composition_id') or None,request.form.get('objective',''))
            return redirect(f'/social/experiments/{eid}')
        except Exception as exc:return layout('Experiment failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/social/experiments'>Back</a></div>"),400

    @app.get('/social/experiments/<int:experiment_id>')
    def social_experiment_detail(experiment_id):
        d=get_social_experiment(experiment_id)
        summaries=get_experiment_metric_summaries(experiment_id)
        if not d:return 'Not found',404
        x=d['experiment'];body=f"<div class='pagehead'><div class='eyebrow'>Experiment</div><h1>{e(x['title'])}</h1><div class='lead'>{e(x.get('objective') or 'No objective recorded')}</div></div>"
        body+="<form class='card' method='post' action='/social/experiments/%d/variant'><h2>Add variant</h2><div class='toolbar'><input name='label' placeholder='Variant label'><input name='hook_text' placeholder='Hook'><input name='caption_text' placeholder='Caption'><input name='cover_ref' placeholder='Cover ref'><input name='target_duration_s' type='number' min='0' max='180' step='0.1' placeholder='Duration s'><input name='clip_order' placeholder='Clip order: 3,2,1'><button>Add variant</button></div></form>"%int(experiment_id)
        for v in d['variants']:
            body+=f"<div class='card' style='margin-top:12px'><div class='row space'><div><b>{e(v['label'])}</b><div class='muted'>{e(v['status'])} · duration {e(v.get('target_duration_s') or '—')} · order {e(','.join(str(i) for i in v.get('clip_order',[])) or '—')}</div></div><span class='badge'>{len(v.get('results') or [])} results</span></div><div class='muted' style='margin-top:6px'>Hook: {e(v.get('hook_text') or '—')} · Caption: {e(v.get('caption_text') or '—')} · Cover: {e(v.get('cover_ref') or '—')}</div><form class='toolbar' method='post' action='/social/experiments/variant/{int(v['id'])}/result'><input name='views' type='number' min='0' placeholder='Views'><input name='likes' type='number' min='0' placeholder='Likes'><input name='comments' type='number' min='0' placeholder='Comments'><input name='shares' type='number' min='0' placeholder='Shares'><input name='saves' type='number' min='0' placeholder='Saves'><input name='avg_view_duration_s' type='number' min='0' step='0.1' placeholder='Avg view s'><input name='retention_3s_pct' type='number' min='0' max='100' step='0.1' placeholder='3s retention %'><input name='completion_pct' type='number' min='0' max='100' step='0.1' placeholder='Completion %'><button>Record manual result</button></form></div>"
        body+="<div class='card' style='margin-top:12px'><h2>Derived metric summaries</h2><div class='muted'>Descriptive totals and rates only. MediaEngine does not rank variants or choose a winner.</div>"
        if not summaries:body+="<div class='muted' style='margin-top:8px'>No result rows yet.</div>"
        for s in summaries:
            er="—" if s.get('engagement_rate_pct') is None else f"{float(s['engagement_rate_pct']):.2f}%"
            av="—" if s.get('avg_view_duration_s') is None else f"{float(s['avg_view_duration_s']):.2f}s"
            rt="—" if s.get('retention_3s_pct') is None else f"{float(s['retention_3s_pct']):.1f}%"
            cp="—" if s.get('completion_pct') is None else f"{float(s['completion_pct']):.1f}%"
            body+=f"<div class='row space' style='padding:8px 0;border-bottom:1px solid #223'><div><b>{e(s['label'])}</b><div class='muted'>{int(s['result_rows'])} rows · {int(s['views'])} views · {int(s['engagements'])} engagements</div></div><div class='muted'>ER {e(er)} · avg {e(av)} · 3s {e(rt)} · completion {e(cp)}</div></div>"
        body+="</div>"
        body+=f"<form class='card' style='margin-top:12px' method='post' action='/social/experiments/{int(experiment_id)}/csv-preview'><h2>CSV import preview</h2><div class='muted'>Required: variant_id plus at least one metric column. Preview never writes data; confirm import is a separate step. Max 200 rows / 128 KiB.</div><textarea name='csv_text' rows='8' style='width:100%;margin-top:8px' placeholder='variant_id,observed_at,views,likes,...'></textarea><div style='margin-top:8px'><button>Validate & preview</button></div></form>"
        body+="<div style='margin-top:14px'><a class='btn btn2' href='/social/experiments'>Back to Experiments</a></div>"
        return layout('Experiment',body)

    @app.post('/social/experiments/<int:experiment_id>/variant')
    def social_experiment_variant_add(experiment_id):
        try:
            add_social_variant(experiment_id,request.form.get('label',''),request.form.get('hook_text',''),request.form.get('caption_text',''),request.form.get('cover_ref',''),request.form.get('target_duration_s') or None,request.form.get('clip_order',''),request.form.get('notes',''))
            return redirect(f'/social/experiments/{experiment_id}')
        except Exception as exc:return layout('Variant failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div></div>"),400

    @app.post('/social/experiments/variant/<int:variant_id>/result')
    def social_experiment_result_add(variant_id):
        try:
            record_social_result(variant_id,'manual',views=request.form.get('views',0),likes=request.form.get('likes',0),comments=request.form.get('comments',0),shares=request.form.get('shares',0),saves=request.form.get('saves',0),avg_view_duration_s=request.form.get('avg_view_duration_s',0),retention_3s_pct=request.form.get('retention_3s_pct') or None,completion_pct=request.form.get('completion_pct') or None)
            with db() as con:r=con.execute('SELECT experiment_id FROM social_experiment_variants WHERE id=?',(int(variant_id),)).fetchone()
            return redirect(f"/social/experiments/{int(r['experiment_id'])}") if r else redirect('/social/experiments')
        except Exception as exc:return layout('Result failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:500])}</div></div>"),400


    @app.post('/social/experiments/<int:experiment_id>/csv-preview')
    def social_experiment_csv_preview(experiment_id):
        csv_text=request.form.get('csv_text','')
        p=validate_experiment_results_csv(experiment_id,csv_text)
        body=f"<div class='pagehead'><div class='eyebrow'>CSV preview</div><h1>{'Ready to import' if p['ok'] else 'Validation failed'}</h1><div class='lead'>Preview is read-only. No result rows were inserted.</div></div><div class='card'>"
        if p['errors']:
            body+="<div class='errbox'>"+e(' | '.join(p['errors'][:20]))+"</div>"
        else:
            body+=f"<b>{int(p['row_count'])} validated rows</b><div class='muted'>Source will be stored as import. No ranking or winner selection is performed.</div>"
            for row in p['rows'][:20]:
                body+=f"<div class='muted' style='padding:4px 0'>variant {int(row['variant_id'])} · views {int(row['views'])} · completion {e(row.get('completion_pct') if row.get('completion_pct') is not None else '—')}</div>"
            body+=f"<form method='post' action='/social/experiments/{int(experiment_id)}/csv-import'><textarea name='csv_text' hidden>{e(csv_text)}</textarea><button style='margin-top:10px'>Confirm import</button></form>"
        body+=f"<div style='margin-top:10px'><a class='btn btn2' href='/social/experiments/{int(experiment_id)}'>Back</a></div></div>"
        return layout('CSV preview',body), (200 if p['ok'] else 400)

    @app.post('/social/experiments/<int:experiment_id>/csv-import')
    def social_experiment_csv_import(experiment_id):
        try:
            result=import_experiment_results_csv(experiment_id,request.form.get('csv_text',''))
            body=f"<div class='pagehead'><div class='eyebrow'>CSV import</div><h1>Imported</h1><div class='lead'>{int(result['imported'])} new rows · {int(result['skipped_duplicates'])} exact duplicates skipped.</div></div><div class='card'><div class='muted'>No automatic ranking or winner selection was performed.</div><a class='btn btn2' href='/social/experiments/{int(experiment_id)}'>Back to experiment</a></div>"
            return layout('CSV imported',body)
        except Exception as exc:
            return layout('CSV import failed',f"<div class='card'><div class='errbox'>{e(str(exc)[:1000])}</div><a class='btn btn2' href='/social/experiments/{int(experiment_id)}'>Back</a></div>"),400


    @app.get('/welcome')
    def beta_welcome():
        cat=setup_catalog(load_config())
        try:      # "Ready" only when the AI model of Auto Edit is on this PC (it is downloaded with a button)
            from . import auto_edit as _ae
            if not _ae.model_status()['ready']:
                for it in cat:
                    if it.get('id')=='core': it['status']='Works; the AI model is not downloaded yet (Check this PC)'
        except Exception:
            pass
        return layout('First run',welcome_body(cat))

    @app.get('/help')
    def beta_help():
        body=help_body()+"""<div class='card'><h3>Create a local support bundle</h3><p>Creates a bounded, sanitized ZIP on this PC only. It is never uploaded automatically and excludes raw media, credentials, database contents and full personal paths.</p><form method='post' action='/support/bundle'><button class='btn' type='submit'>Create support bundle</button></form></div>"""
        return layout('Help & recovery',body)

    @app.post('/support/bundle')
    def support_bundle_create():
        from .support_bundle import create_support_bundle
        try:
            path=create_support_bundle()
        except Exception:
            body="""<div class='pagehead'><div class='eyebrow'>Local diagnostics</div><h1>Support bundle could not be created</h1>
<div class='lead'>MediaEngine did not upload anything. The failure stayed on this PC.</div></div>
<div class='card'><div class='errbox'><b>Local bundle creation failed.</b><div class='muted' style='margin-top:5px'>Try again. If it still fails, restart MediaEngine and open Help &amp; Recovery. Raw error details, credentials and personal paths are not shown here.</div></div>
<form method='post' action='/support/bundle' style='margin-top:10px'><button class='btn' type='submit'>Try again</button></form>
<div style='margin-top:10px'><a class='btn btn2' href='/help'>Help &amp; Recovery</a></div></div>"""
            return layout('Support bundle failed',body),500
        return layout('Support bundle ready',f"<div class='card'><h3>Support bundle created locally</h3><p><b>{e(path.name)}</b></p><p>Location: MediaEngine local data/support folder. Nothing was uploaded.</p><a class='btn btn2' href='/help'>Back to Help</a></div>")

    @app.get('/help/guide')
    def beta_help_guide():
        return layout('Beta guide',guide_body())

    @app.get('/devices')
    def devices_hub():
        phone=phone_snapshot()
        phone_text=(phone.get('model') or phone.get('serial') or 'Android')+' connected' if phone['connected'] else (phone.get('error') or 'not connected')
        body=f"""<div class='pagehead'><div class='eyebrow'>Per-install device registry</div><h1>Devices</h1><div class='lead'>Media-source devices and the future Social Device Lab are separate capabilities. Nothing here hard-codes a personal phone model or account.</div></div>
<div class='hubgrid'>
<div class='card hubcard tone-mint'><b>Android · Media Source</b><span class='device'><i class='device-dot {'online' if phone['connected'] else ''}' data-phone-dot></i><span data-phone-text>{e(phone_text)}</span></span><small>Existing ADB/MediaStore ingest foundation.</small></div>
<div class='card hubcard'><b>Android · Social Device Lab</b><span>Planned for native QA, draft handoff and manual fallback.</span><small>Not implemented in this release.</small></div>
<div class='card hubcard'><b>iPhone / iOS</b><span>Separate future media-source and Social Device Lab adapters.</span><small>Not represented as implemented until real-device validation passes.</small></div>
</div>
<div class='card callout' style='margin-top:14px'><div class='row space'><div><b>Media-source recovery</b><div class='muted'>If Android or another local source is missing, recheck discovery. This only rescans source availability; it does not change device settings or delete media.</div></div><div class='row'><button id='deviceRecheck' class='btn2'>Recheck media sources</button><a class='btn btn2' href='/help'>Help &amp; Recovery</a></div></div></div>"""
        script="""const recheck=document.getElementById('deviceRecheck');
if(recheck)recheck.onclick=async()=>{
  if(recheck.disabled)return;
  const label=recheck.textContent;recheck.disabled=true;recheck.textContent='Rechecking…';
  try{
    const r=await fetch('/api/discover',{method:'POST'});
    let x={};try{x=await r.json()}catch(_){}
    if(!r.ok)throw new Error(x.error||('HTTP '+r.status));
    toast(x.message||'Source recheck started');
    setTimeout(()=>location.reload(),1200);
  }catch(err){
    toast('Could not start source recheck — '+((err&&err.message)||'open Help & Recovery'));
    recheck.disabled=false;recheck.textContent=label;
  }
};"""
        return layout('Devices',body,script)

    @app.get('/cloud')
    def cloud_hub():
        body="""<div class='pagehead'><div class='eyebrow'>Optional services</div><h1>Cloud</h1><div class='lead'>Cloud features remain opt-in. Local processing and local media are the default.</div></div>
<div class='about-grid'>
<div class='card'><h2 style='margin-top:0'>Cloud Vault</h2><span class='badge unreviewed'>Disabled</span><p class='muted'>Future modes: exports only, selected media, or full archive mirror. Enabling upload must never delete local/source originals.</p><a class='btn btn2' href='/settings/connections'>Setup & Connections</a></div>
<div class='card'><h2 style='margin-top:0'>Cloud Compute</h2><div class='row'><span class='badge safe'>Local · current</span><span class='badge unreviewed'>Cloud · planned</span><span class='badge unreviewed'>Auto · planned</span></div><p class='muted'>Supabase may coordinate identity/jobs/metadata later; heavy AI/FFmpeg belongs on dedicated workers, not the control plane.</p></div>
</div>"""
        return layout('Cloud',body)

    @app.get('/activity')
    def activity_hub():
        work=_recent_work(60)
        rows=''.join(_work_row(x) for x in work) or "<div class='muted'>Nothing made yet.</div>"
        body="""<div class='pagehead'><div class='eyebrow'>Operations</div><h1>Activity</h1><div class='lead'>Everything made in MediaEngine, newest first; the import and analysis jobs and recovery below.</div></div>
<div class='card' style='margin-bottom:14px'><h2 style='margin-top:0'>All work</h2><div class='worklist'>"""+rows+"""</div></div>
<div class='hubgrid'>
<a class='card hubcard tone-blue' href='/jobs'><b>Jobs & errors</b><span>Open the existing durable job history.</span></a>
<a class='card hubcard' href='/help'><b>Recovery & support</b><span>Inspect failed jobs, retry safely, and review local diagnostic/support boundaries.</span></a>
<div class='card hubcard'><b>Publishing activity</b><span>Will appear here only after Social Lab publishing is implemented.</span></div>
</div>"""
        return layout('Activity',body)

    @app.get("/settings/connections")
    def setup_connections():
        from .connectors import list_provider_connections
        connectors = m12_connector_catalog()
        registry_unavailable = False
        try:
            rows = [dict(r) for r in list_provider_connections()]
        except Exception:
            rows = []
            registry_unavailable = True
        by_provider = {}
        for row in rows:
            provider_key = str(row.get("provider") or "").strip().lower()
            by_provider.setdefault(provider_key, []).append(row)
        cards = []
        for c in connectors:
            provider_id = str(c.get("id") or c.get("name") or "").strip().lower()
            provider_name = str(c.get("name") or provider_id.title() or "Provider")
            provider_rows = by_provider.get(provider_id, [])
            active_rows = [r for r in provider_rows if str(r.get("status") or "").lower() == "connected"]
            connect_available = bool(c.get("connect_available"))
            prereq_ready = bool(c.get("connection_prerequisites_ready", connect_available))
            official_ready = bool(c.get("official_connection_enabled"))
            credential_ready = bool(c.get("credential_storage_ready"))
            credential_raw = c.get("credential_status")
            credential_status = str(credential_raw or ("Ready" if credential_ready else "Unavailable"))
            blocker = str(c.get("connection_blocker") or c.get("blocker") or "")
            card_status = "Registry unavailable" if registry_unavailable else ("Connected" if active_rows else ("Preflight ready" if connect_available else "Blocked"))
            status_color = "#d7a34a" if registry_unavailable else ("#2f9e44" if active_rows else ("#b7791f" if connect_available else "#a0a0a0"))
            badges = [
                f'<span style="padding:3px 8px;border:1px solid #444;border-radius:999px">Credentials: {e(credential_status)}</span>',
                f'<span style="padding:3px 8px;border:1px solid #444;border-radius:999px">Preflight: {"Ready" if prereq_ready else "Blocked"}</span>',
                f'<span style="padding:3px 8px;border:1px solid #444;border-radius:999px">Official OAuth: {"Enabled" if official_ready else "Not enabled"}</span>',
            ]
            if "public_client_id_configured" in c:
                badges.append(f'<span style="padding:3px 8px;border:1px solid #444;border-radius:999px">Client ID: {"Configured" if c.get("public_client_id_configured") else "Missing"}</span>')
            account_parts = []
            for row in provider_rows:
                rid = row.get("id")
                row_status = str(row.get("status") or "unknown")
                account_name = str(row.get("display_name") or row.get("account_id") or "Connected account")
                action = ""
                if row_status.lower() == "connected" and rid is not None:
                    action = f'<form method="post" action="/settings/connections/disconnect?connection_id={e(str(rid))}" style="margin:0"><button type="submit">Disconnect</button></form>'
                else:
                    reason = blocker or "Reconnect is unavailable until official provider OAuth is enabled."
                    action = f'<button type="button" disabled title="{e(reason)}">Reconnect</button>'
                account_parts.append(f'<div style="display:flex;gap:12px;align-items:center;justify-content:space-between;padding:8px 0;border-top:1px solid #333"><span><strong>{e(account_name)}</strong><br><small>{e(row_status)}</small></span>{action}</div>')
            if not provider_rows:
                if registry_unavailable:
                    account_parts.append('<div style="padding-top:10px"><button type="button" disabled>Account state unavailable</button> <a class="btn btn2" href="/settings/connections">Retry</a></div>')
                else:
                    reason = blocker or ("Provider preflight is ready; live authorization is intentionally not started by this build." if connect_available else "Provider prerequisites are not ready.")
                    account_parts.append(f'<div style="padding-top:10px"><button type="button" disabled title="{e(reason)}">Connect</button></div>')
            blocker_html = f'<p class="muted" style="margin:8px 0 0">{e(blocker)}</p>' if blocker else ""
            cards.append(
                f'<div class="card" style="margin:12px 0"><div style="display:flex;justify-content:space-between;gap:16px;align-items:center"><h3 style="margin:0">{e(provider_name)}</h3><span style="color:{status_color}">{e(card_status)}</span></div>'
                + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px">' + "".join(badges) + "</div>"
                + blocker_html + "".join(account_parts) + "</div>"
            )
        registry_banner = (
            '<div class="errbox" style="margin:12px 0"><b>Connection registry temporarily unavailable</b>'
            '<div class="muted" style="margin-top:5px">MediaEngine could not read saved account state. No account data was changed. '
            'Try again or restart MediaEngine. Manual handoff and Analytics CSV remain available.</div>'
            '<div style="margin-top:8px"><a class="btn btn2" href="/settings/connections">Try again</a> '
            '<a class="btn btn2" href="/help">Help &amp; Recovery</a></div></div>'
            if registry_unavailable else ""
        )
        body = (
            "<h1>Setup &amp; Connections</h1>"
            + connection_disclosure_html()
            + registry_banner
            + "".join(cards)
            + '<div class="card" style="margin-top:16px"><h3>Manual fallback</h3><p class="muted">Manual handoff and Analytics CSV remain available while official provider OAuth is blocked or not registered.</p><p><a href="/social/manual-handoff">Manual handoff</a> &nbsp; <a href="/social/experiments">Analytics CSV</a></p></div>'
        )
        return layout("Setup & Connections", body)

    @app.post("/settings/connections/disconnect")
    def setup_connection_disconnect():
        from .connectors import disconnect_provider_connection
        connection_id = request.args.get("connection_id", type=int) or request.form.get("connection_id", type=int)
        if not connection_id:
            return redirect("/settings/connections")
        disconnect_provider_connection(connection_id)
        return redirect("/settings/connections", code=303)

    @app.post('/api/discover')
    def discover():
        started=start_discovery();return jsonify({'started':started,'message':'Discovery started' if started else 'Discovery is already running or paused while a foreground job is active'})

    def gallery(mode: str):
        is_import=mode=='import'
        page=max(1,request.args.get('page',1,type=int) or 1); per=48
        media_type=request.args.get('media_type',''); status=request.args.get('status',''); rights=request.args.get('rights',''); source_kind=request.args.get('source_kind',''); source_id=request.args.get('source_id','').strip(); q=request.args.get('q','').strip(); sort=request.args.get('sort','date_desc')
        imported=request.args.get('imported','no' if is_import and 'imported' not in request.args else '')
        where=['excluded=0','private_path IS NULL','rejected_path IS NULL',"analysis_status<>'private'",
               "COALESCE(sha256,'') NOT IN (SELECT sha256 FROM ignored_hashes)"]; args=[]      # a copy of a Private video too
        if is_import:
            # Import is the single source browser: Android, SD/USB and configured local folders.
            where.append("source_kind IN ('android','removable','fixed')")
            if imported=='no': where.append("work_selected=0")
            elif imported=='yes': where.append("work_selected=1")
        else:
            # Library is an explicit working set, not every file that happens to live locally.
            where.append("work_selected=1")
            where.append("(source_kind='fixed' OR staging_path IS NOT NULL OR archive_path IS NOT NULL)")
        if media_type: where.append('media_type=?');args.append(media_type)
        if status: where.append('analysis_status=?');args.append(status)
        if rights=='flagged': where.append("rights_status IN ('review','permission','blocked')")
        elif rights in ('unknown','review','permission','cleared','blocked'): where.append('rights_status=?');args.append(rights)
        if source_kind in ('android','removable','fixed'): where.append('source_kind=?');args.append(source_kind)
        if source_id: where.append('source_id=?');args.append(source_id)
        if q:   # any letters' case (Cyrillic too), also the folder names (where people name their trips and events)
            qf='%'+q.casefold().replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
            where.append("(fold(filename) LIKE ? ESCAPE '\\' OR fold(source_label) LIKE ? ESCAPE '\\' OR fold(path) LIKE ? ESCAPE '\\')");args += [qf,qf,qf]
        order={'date_desc':'COALESCE(date_taken,mtime,0) DESC','date_asc':'COALESCE(date_taken,mtime,0) ASC','size_desc':'COALESCE(size_bytes,0) DESC','size_asc':'COALESCE(size_bytes,0) ASC','duration_desc':'COALESCE(duration_ms,0) DESC','quality_desc':'COALESCE(quality_score,-1) DESC','name':'filename COLLATE NOCASE'}.get(sort,'COALESCE(date_taken,mtime,0) DESC')
        wh=' AND '.join(where)
        with db() as con:
            source_choices=[]
            if not is_import:
                source_choices=con.execute("""SELECT source_kind,source_id,MAX(source_label) AS source_label,COUNT(*) AS n FROM inventory WHERE excluded=0 AND private_path IS NULL AND rejected_path IS NULL AND analysis_status<>'private' AND work_selected=1 AND source_id IS NOT NULL AND source_id<>'' AND (source_kind='fixed' OR staging_path IS NOT NULL OR archive_path IS NOT NULL) GROUP BY source_kind,source_id ORDER BY CASE source_kind WHEN 'android' THEN 1 WHEN 'removable' THEN 2 WHEN 'fixed' THEN 3 ELSE 9 END, source_label COLLATE NOCASE""").fetchall()
            total=con.execute(f'SELECT COUNT(*) n FROM inventory WHERE {wh}',args).fetchone()['n']
            pages=max(1,(total+per-1)//per);page=min(page,pages);off=(page-1)*per
            rows=con.execute(f'SELECT * FROM inventory WHERE {wh} ORDER BY {order} LIMIT ? OFFSET ?',[*args,per,off]).fetchall()
            next_ids=[]
            if page < pages:
                next_ids=[int(x['id']) for x in con.execute(f'SELECT id FROM inventory WHERE {wh} ORDER BY {order} LIMIT ? OFFSET ?',[*args,per,off+per]).fetchall()]
        for r in rows:
            queue_thumbnail(int(r['id']), priority=0)
            if not is_import and r['media_type']=='video': queue_storyboard(int(r['id']), priority=10)
        for inv_id in next_ids:
            queue_thumbnail(inv_id, priority=20)
            if not is_import: queue_storyboard(inv_id, priority=35)
        def opt(cur,val,label): return f"<option value='{e(val)}' {'selected' if cur==val else ''}>{e(label)}</option>"
        if is_import:
            cfg=load_config()
            phone=phone_snapshot()
            phone_text=(phone.get('model') or phone.get('serial') or 'Android')+' connected' if phone['connected'] else (phone.get('error') or 'not connected')
            local_sources=[s for s in cfg.get('sources',[]) if s.get('enabled',True) and (s.get('kind') or 'fixed')=='fixed']
            removable_now=[d for d in windows_drives() if d.get('kind')=='removable']
            source_error=request.args.get('source_error','').strip()
            source_rows=''.join(
                f"<div class='row space' style='padding:6px 0'><div><b translate='no'>{e(s.get('label') or s.get('path'))}</b><div class='muted' translate='no'>{e(s.get('path'))}</div></div>"
                f"<form method='post' action='/import/remove-source'><input type='hidden' name='index' value='{i}'><input type='hidden' name='path' value='{e(str(s.get('path') or ''))}'><button class='btn2'>Remove source</button></form></div>"
                for i,s in enumerate(cfg.get('sources',[])) if s.get('enabled',True) and (s.get('kind') or 'fixed')=='fixed'
            )
            if not source_rows:
                source_rows="<div class='muted'>No local folders added yet.</div>"
            err_html=f"<div class='errbox' style='margin-top:8px'>{e(source_error)}</div>" if source_error else ''
            head=f"""<div class='pagehead row space'><div><div class='eyebrow'>Source browser</div><h1>Import</h1><div class='lead'>One place for Android, SD/USB and folders already on this computer. Choose what becomes part of Library.</div></div><div class='row'><div class='device'><span class='device-dot {'online' if phone['connected'] else ''}' data-phone-dot></span><span class='device-status'>Android: <span data-phone-text>{e(phone_text)}</span></span></div><span class='badge ready'>{len(local_sources)} local folder(s)</span><span class='badge'>{len(removable_now)} SD/USB mounted</span><button onclick=\"fetch('/api/discover',{{method:'POST'}}).then(r=>r.json()).then(x=>toast(x.message||'Discovery'))\">Discover all sources</button></div></div>
<div class='card' style='margin-bottom:12px'><div class='row space'><div><b>Import sources</b><div class='muted'>Local folders stay where they are. Android and SD/USB files are copied to Staging only after you select them.</div></div></div><div style='margin-top:8px'>{source_rows}</div><form method='post' action='/import/add-source' class='toolbar' style='margin-top:10px'><input name='label' placeholder='Label (optional)'><input name='path' style='min-width:360px' placeholder='D:\\Video'><button type='button' class='btn2' onclick=\"(async b=>{{b.disabled=true;try{{const r=await fetch('/api/auto/pick-folder',{{method:'POST'}});const x=await r.json();if(x.path)b.form.path.value=x.path}}catch(e){{}}b.disabled=false}})(this)\">Choose folder…</button><button>Add folder + Discover</button></form>{err_html}</div>"""
            filters=f"""<form method='get' class='toolbar toolpanel'><input name='q' value='{e(q)}' placeholder='Search source media'><select name='media_type'>{opt(media_type,'','Photos + videos')}{opt(media_type,'video','Videos')}{opt(media_type,'image','Photos')}</select><select name='source_kind'>{opt(source_kind,'','All sources')}{opt(source_kind,'android','Android')}{opt(source_kind,'removable','SD/USB')}{opt(source_kind,'fixed','Local folders')}</select><select name='imported'>{opt(imported,'no','Not in Library')}{opt(imported,'yes','In Library')}{opt(imported,'','All source items')}</select><select name='sort'>{opt(sort,'date_desc','Newest')}{opt(sort,'date_asc','Oldest')}{opt(sort,'size_desc','Largest')}{opt(sort,'duration_desc','Longest')}{opt(sort,'name','Name')}</select><button>Apply</button></form>"""
            actions="""<div class='toolbar'><b id='selectedCount'>0 selected</b><span class='badge ready' id='previewCount'>Previews …</span><button class='btn2' id='selectPage'>Select page</button><button class='btn2' id='clearSel'>Clear</button><button id='importBtn'>Add to Library</button><button id='importAnalyzeBtn' class='ok'>Add + Analyze</button></div><div id='actionMsg' class='mode-note'>Files in folders on this PC stay in place. Files from a phone, SD card or USB stick are copied to Staging. Source originals are never deleted.</div>"""
        else:
            head=f"""<div class='pagehead row space'><div><div class='eyebrow'>Videos</div><h1>Library</h1><div class='lead'>{total} local item(s). This is the media already selected/imported and available for work.</div></div><div class='row'><a class='btn btn2' href='/import'>Import more</a><a class='btn btn2' href='/jobs'>Jobs / errors</a></div></div>"""
            source_options=opt(source_id,'','By source: all')
            for s in source_choices:
                prefix={'android':'Android','removable':'SD/USB','fixed':'Folder'}.get(s['source_kind'],s['source_kind'])
                source_options+=opt(source_id,s['source_id'],f"{prefix}: {s['source_label']} ({s['n']})")
            filters=f"""<form method='get' class='toolbar toolpanel'><input name='q' value='{e(q)}' placeholder='Search Library'><select name='media_type'>{opt(media_type,'','Photos + videos')}{opt(media_type,'video','Videos')}{opt(media_type,'image','Photos')}</select><select name='source_kind'>{opt(source_kind,'','Any origin')}{opt(source_kind,'android','From Android')}{opt(source_kind,'removable','From SD/USB')}{opt(source_kind,'fixed','Existing local')}</select><select name='source_id'>{source_options}</select><select name='status'>{opt(status,'','Any privacy state')}{opt(status,'safe','Privacy safe')}{opt(status,'review','Privacy review')}{opt(status,'duplicate','Duplicate')}{opt(status,'error','Error')}</select><select name='rights'>{opt(rights,'','Any rights state')}{opt(rights,'flagged','Rights flagged')}{opt(rights,'unknown','Rights unknown')}{opt(rights,'review','Rights review')}{opt(rights,'permission','Permission needed')}{opt(rights,'cleared','Rights cleared')}{opt(rights,'blocked','Do not publish')}</select><select name='sort'>{opt(sort,'date_desc','Newest')}{opt(sort,'date_asc','Oldest')}{opt(sort,'size_desc','Largest')}{opt(sort,'size_asc','Smallest')}{opt(sort,'duration_desc','Longest')}{opt(sort,'quality_desc','Quality score')}{opt(sort,'name','Name')}</select><button>Apply</button></form>"""
            actions="""<div class='toolbar'><b id='selectedCount'>0 selected</b><span class='badge ready' id='previewCount'>Previews …</span><button class='btn2' id='selectPage'>Select page</button><button class='btn2' id='clearSel'>Clear</button><button id='reelBtn'>Make a reel</button><button id='analyzeBtn' class='btn2'>Analyze local</button><button id='mediaBrainBtn' class='btn2'>Media Brain</button><button id='convertBulkBtn' class='btn2'>Convert</button><button id='privateBtn' class='warn'>Private forever</button><button id='archiveBtn' class='ok'>Archive</button><button id='rejectBtn' class='danger'>Reject → quarantine</button><button id='removeBtn' class='danger'>Remove from Library</button><select id='rightsPreset'><option value=''>Rights…</option><option value='review'>Review rights</option><option value='permission'>Permission needed</option><option value='cleared'>Rights cleared</option><option value='blocked'>Do not publish</option><option value='reset'>Reset rights status</option></select><button id='rightsBtn' class='btn2'>Apply rights tag</button></div><div id='actionMsg' class='mode-note'>Hover over a video when its storyboard is ready to skim the clip without opening it.</div>"""
        body=head+(_aiplus_search_card() if not is_import else "")+filters+actions+"<div class='grid'>"
        for r in rows:
            if is_import:
                imp='in-library' if r['work_selected'] else ('local-source' if r['source_kind']=='fixed' else 'source')
            else:
                imp='archived' if r['archive_path'] else ('imported' if r['staging_path'] else ('local' if r['source_kind']=='fixed' else r['import_status']))
            qcls='quality-'+str(r['quality_status']) if r['quality_status'] in ('ok','review') else ''
            qs=r['quality_score']
            try: qs=str(int(round(float(qs)))) if qs is not None else ''
            except (TypeError,ValueError): qs=str(qs)
            extra=(f"<span class='badge qualityBadge {qcls}'>quality {e(r['quality_status'])} {e(qs)}</span>" if (not is_import and r['quality_status']!='unreviewed') else '')
            # only a rights tag the user set (most home videos never get one: "rights unknown" on every card is noise)
            rights_badge=(f"<span class='badge rightsBadge rights-{e(r['rights_status'])}'>rights {e(r['rights_status'])}</span>" if not is_import and (r['rights_status'] or 'unknown')!='unknown' else '')
            audio=("<span class='badge audioflag'>audio</span>" if (not is_import and r['rights_audio_present']) else '')
            analysis=(f"<span class='badge {e(r['analysis_status'])} analysisBadge'>{e(r['analysis_status'])}</span>" if not is_import else '')
            storyboard_err=("<span class='badge error' title='Open item for details'>preview error</span>" if (not is_import and r['media_type']=='video' and r['storyboard_status']=='unavailable') else '')
            story=(f"<span class='storybadge'>{int(r['storyboard_frames'] or 0)}/8 frames</span>" if (not is_import and r['media_type']=='video' and int(r['storyboard_frames'] or 0)>0) else ("<span class='storybadge'>preview…</span>" if (not is_import and r['media_type']=='video') else ''))
            body+=f"""<div class='media-card' data-id='{r['id']}' data-type='{e(r['media_type'])}'><input class='check itemCheck' type='checkbox' value='{r['id']}'>{story}<div class='thumb'><img class='mediaThumb' data-id='{r['id']}' loading='eager' decoding='async' src='/thumb/{r['id']}'></div><div class='meta'><div class='name' translate='no' title='{e(r['filename'])}'>{e(r['filename'])}</div><div class='small'><span translate='no'>{e(r['source_label'])}</span> · <span>{human_bytes(r['size_bytes'])}</span> · <span>{human_duration(r['duration_ms'])}</span></div><span class='badge {e(imp)} importBadge'>{e(imp)}</span>{analysis}{extra}{rights_badge}{audio}{storyboard_err}<div><a class='btn btn2 openLink' style='padding:4px 7px;font-size:11px' href='/item/{r['id']}'>Open</a></div></div></div>"""
        body+='</div>'
        if not rows:
            filtered=any(v for k,v in request.args.items() if k not in ('view','page','sort'))
            if filtered:
                body+="<div class='empty'>Nothing here with the current filters.</div>"
            elif is_import:
                body+="<div class='empty'>No videos found yet. Add a folder above (or connect a phone, a card or a USB drive).</div>"
            else:
                body+="<div class='empty'><span>The Library is empty. Add a folder on Import and choose its videos for the Library.</span> <a class='btn btn2' href='/import'>Import</a></div>"
        qs={k:v for k,v in request.args.items() if k!='page'}
        body+=page_nav(page,pages,qs)
        key='archivist.import.selected.v1' if is_import else 'archivist.library.selected.v3'
        mode_js='import' if is_import else 'library'
        script=f"""
const MODE={json.dumps(mode_js)};const KEY={json.dumps(key)};const cards=[...document.querySelectorAll('.media-card')],checks=[...document.querySelectorAll('.itemCheck')],count=document.getElementById('selectedCount'),msg=document.getElementById('actionMsg');
let selected=new Set();try{{selected=new Set(JSON.parse(localStorage.getItem(KEY)||'[]').map(String))}}catch(e){{}}
function save(){{localStorage.setItem(KEY,JSON.stringify([...selected]))}}function sync(){{cards.forEach((c,i)=>{{let id=String(checks[i].value),on=selected.has(id);checks[i].checked=on;c.classList.toggle('selected',on)}});if(count)count.textContent=selected.size+' selected'}}function setSel(ch,on){{let id=String(ch.value);on?selected.add(id):selected.delete(id);save();sync()}}
cards.forEach((c,i)=>c.addEventListener('click',ev=>{{if(ev.target.closest('.openLink')||ev.target===checks[i])return;setSel(checks[i],!selected.has(String(checks[i].value)))}}));checks.forEach(ch=>ch.addEventListener('change',()=>setSel(ch,ch.checked)));const sp=document.getElementById('selectPage'),cs=document.getElementById('clearSel');if(sp)sp.onclick=()=>{{checks.forEach(x=>selected.add(String(x.value)));save();sync()}};if(cs)cs.onclick=()=>{{selected.clear();save();sync()}};
let actionBusy=false;async function act(action,confirmText){{if(actionBusy)return;if(!selected.size){{toast('Select files first');return}}if(confirmText&&!confirm(confirmText))return;actionBusy=true;if(msg)msg.textContent='Creating durable job for '+selected.size+' selected files…';const ids=[...selected].map(Number);try{{let r=await fetch('/api/selection-action',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{action,ids}})}});let x=await r.json();if(!r.ok){{if(msg)msg.textContent='ERROR: '+(x.error||r.statusText);toast('ERROR: '+(x.error||r.statusText));return}}if(x.job_id){{selected.clear();save();sync();if(msg)msg.textContent='Job #'+x.job_id+' accepted.';toast('Job #'+x.job_id+' accepted')}}else{{selected.clear();save();if(msg)msg.textContent=x.message||'Done';toast(x.message||'Done');location.reload()}}}}finally{{actionBusy=false}}}}
const ib=document.getElementById('importBtn'),iab=document.getElementById('importAnalyzeBtn'),an=document.getElementById('analyzeBtn'),mb=document.getElementById('mediaBrainBtn'),cb=document.getElementById('convertBulkBtn'),pb=document.getElementById('privateBtn'),ab=document.getElementById('archiveBtn'),rbj=document.getElementById('rejectBtn'),rml=document.getElementById('removeBtn');if(ib)ib.onclick=()=>act('import');if(iab)iab.onclick=()=>act('import_analyze');if(an)an.onclick=()=>act('analyze');if(mb)mb.onclick=()=>act('media_brain');if(cb)cb.onclick=()=>{{const ids=cards.filter(c=>selected.has(c.dataset.id)&&c.dataset.type==='video').map(c=>c.dataset.id);if(!ids.length){{toast('Select local videos first');return}}location.href='/convert?ids='+encodeURIComponent(ids.join(','))}};if(pb)pb.onclick=()=>act('private','Mark selected Private forever?');if(ab)ab.onclick=()=>act('archive','Archive selected local/staged files? Source-device originals are never deleted.');if(rbj)rbj.onclick=()=>act('reject','Move selected Staging copies to Rejected quarantine and hide them? Phone/SD originals stay untouched.');if(rml)rml.onclick=()=>act('remove','Remove selected items from Library? Imported Staging copies move to the Rejected / Removed from Library folder (delete them there when you are sure). Source originals and local/archive files stay untouched.');sync();
const rlb=document.getElementById('reelBtn');if(rlb)rlb.onclick=()=>{{const all=[...selected];if(!all.length){{toast('Select videos first');return}}location.href='/auto/from-library?ids='+encodeURIComponent(all.join(','))}};
async function tagRights(){{const el=document.getElementById('rightsPreset');if(!el)return;const preset=el.value;if(!preset){{toast('Choose a rights tag');return}}if(!selected.size){{toast('Select files first');return}}const ids=[...selected].map(Number);const r=await fetch('/api/selection-action',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{action:'rights',ids,preset}})}});const x=await r.json();if(!r.ok){{toast('ERROR: '+(x.error||r.statusText));return}}toast(x.message||'Rights updated');refreshVisible()}}const rbt=document.getElementById('rightsBtn');if(rbt)rbt.onclick=tagRights;
async function refreshVisible(){{try{{const ids=cards.map(c=>c.dataset.id).join(',');if(!ids)return;const r=await fetch('/api/items?ids='+ids,{{cache:'no-store'}}),data=await r.json();for(const c of cards){{const d=data[c.dataset.id];if(!d)continue;const ib=c.querySelector('.importBadge'),ab=c.querySelector('.analysisBadge');if(ib){{ib.textContent=(window.ME_L?ME_L(d.import_state):d.import_state);ib.className='badge importBadge '+d.import_state}}if(ab){{ab.textContent=(window.ME_L?ME_L(d.analysis_status):d.analysis_status);ab.className='badge analysisBadge '+d.analysis_status}}let qb=c.querySelector('.qualityBadge');if(d.quality_status&&d.quality_status!=='unreviewed'&&MODE==='library'){{if(!qb&&ab){{qb=document.createElement('span');qb.className='badge qualityBadge';ab.insertAdjacentElement('afterend',qb)}}if(qb){{qb.textContent='quality '+d.quality_status+(d.quality_score!=null?' '+d.quality_score:'');qb.className='badge qualityBadge quality-'+d.quality_status}}}}let rr=c.querySelector('.rightsBadge');if(rr){{rr.textContent='rights '+(d.rights_status||'unknown');rr.className='badge rightsBadge rights-'+(d.rights_status||'unknown')}}}}}}catch(e){{}}setTimeout(refreshVisible,1200)}}refreshVisible();
const previewCount=document.getElementById('previewCount'),previewImgs=[...document.querySelectorAll('.mediaThumb')];async function refreshPreviews(){{if(!previewImgs.length){{if(previewCount)previewCount.textContent='Previews 0/0';return}}try{{const ids=previewImgs.map(x=>x.dataset.id).join(',');const r=await fetch('/api/thumb-status?ids='+ids,{{cache:'no-store'}}),x=await r.json();const ready=new Set((x.ready||[]).map(String));for(const img of previewImgs){{const id=String(img.dataset.id);if(ready.has(id)&&img.dataset.ready!=='1'){{img.dataset.ready='1';img.src='/thumb/'+id+'?v='+(x.generation||Date.now())}}}}const unavailable=Number(x.unavailable_count||0),pending=Number(x.pending_count||0),readyN=Number(x.ready_count||0);if(previewCount)previewCount.textContent='Previews '+readyN+'/'+previewImgs.length+(unavailable?' · '+unavailable+' unavailable':pending?' · '+pending+' loading':'');if(pending>0)setTimeout(refreshPreviews,800)}}catch(e){{if(previewCount)previewCount.textContent='Previews status unavailable';setTimeout(refreshPreviews,2000)}}}}refreshPreviews();
if(MODE==='library'){{const videoCards=cards.filter(c=>c.dataset.type==='video');async function refreshStoryboards(){{if(!videoCards.length)return;try{{const ids=videoCards.map(c=>c.dataset.id).join(',');const r=await fetch('/api/storyboard-status?ids='+ids,{{cache:'no-store'}}),x=await r.json();for(const c of videoCards){{const st=(x.items||{{}})[c.dataset.id],b=c.querySelector('.storybadge');if(st&&st.ready&&st.count>1){{c.dataset.storyReady='1';c.dataset.storyCount=String(st.count);if(b){{b.style.display='block';b.textContent=st.count+' frames'}}}}}}if(Number(x.pending_count||0)>0)setTimeout(refreshStoryboards,1200)}}catch(e){{setTimeout(refreshStoryboards,2500)}}}}for(const c of videoCards){{let timer=null,idx=0;const img=c.querySelector('.mediaThumb');c.addEventListener('mouseenter',async()=>{{if(!img)return;const id=c.dataset.id;if(c.dataset.storyReady!=='1'){{try{{await fetch('/api/storyboard/'+id+'/queue',{{method:'POST'}})}}catch(e){{}}return}}const n=Number(c.dataset.storyCount||0);if(n<2)return;idx=0;clearInterval(timer);timer=setInterval(()=>{{img.src='/storyboard/'+id+'/'+idx+'?v='+Date.now();idx=(idx+1)%n}},420)}});c.addEventListener('mouseleave',()=>{{clearInterval(timer);timer=null;if(img)img.src='/thumb/'+c.dataset.id+'?v='+Date.now()}})}}refreshStoryboards();}}
"""
        return layout('Import' if is_import else 'Library',body,script)



    @app.get('/search')
    def smart_search():
        q=request.args.get('q','').strip()[:240]
        try: page=max(1,int(request.args.get('page','1') or 1))
        except Exception: page=1
        per=48
        data=semantic_search(q,limit=500) if q else {'results':[],'intents':[],'tokens':[],'index_count':0,'model':'signals_v1'}
        rows=data.get('results') or [];total=len(rows);pages=max(1,(total+per-1)//per);page=min(page,pages);shown=rows[(page-1)*per:page*per]
        examples=[('best vertical videos','Best vertical'),('high motion videos','High motion'),('dark videos','Dark / night'),('drone videos','Drone'),('long Android videos','Long Android')]
        chips=''.join(f"<a class='btn btn2' style='padding:6px 9px' href='/search?q={urllib.parse.quote_plus(x)}'>{e(label)}</a>" for x,label in examples)
        cap=', '.join(semantic_capabilities())
        body=f"""<div class='pagehead'><div class='eyebrow'>Local Search</div><h1>Search your footage</h1>
<div class='lead'>Describe useful properties of the media. Search runs locally and uses MediaEngine's existing Media Brain and catalog signals.</div></div>
<form method='get' action='/search' class='card row' style='padding:12px'><input name='q' value='{e(q)}' autofocus style='min-width:min(680px,75vw);font-size:16px' placeholder='e.g. best vertical high-motion videos'><button>Search</button>{("<a class='btn btn2' href='/search'>Clear</a>" if q else "")}</form>
<div class='toolbar'>{chips}</div>
<div class='mode-note'>Understands: {e(cap)}. Exact people/objects/scenes that are not already in local text are not vision-indexed yet; this page is the stable foundation for a future optional local visual-embedding layer.</div>"""
        if q:
            intent_txt=', '.join(data.get('intents') or []) or 'text'
            body+=f"<div class='row space section-title'><span>{total} result(s)</span><span class='badge'>signals v1 · {e(intent_txt)}</span></div><div class='grid'>"
            for r in shown:
                why=' · '.join(r.get('why') or []) or 'text / Media Brain relevance'
                best=(f"<a class='btn btn2 openLink' style='padding:4px 7px;font-size:11px' href='/clip/{int(r['best_clip_id'])}?back=item'>Best clip</a>" if r.get('best_clip_id') else '')
                tags=''.join(f"<span class='badge'>{e(x.replace('_',' '))}</span>" for x in (r.get('tags') or [])[:5])
                body+=f"""<div class='media-card'><div class='thumb'><img loading='lazy' src='/thumb/{int(r['id'])}'></div><div class='meta'>
<div class='row space'><span class='badge ready'>match {float(r.get('semantic_score') or 0):.1f}</span><span class='small'>{human_duration(r.get('duration_ms'))}</span></div>
<div class='name' title='{e(r.get('filename'))}'>{e(r.get('filename'))}</div><div class='small'><span translate='no'>{e(r.get('source_label'))}</span> · <span>{human_bytes(r.get('size_bytes'))}</span></div>
<div class='small' style='margin-top:5px' title='{e(why)}'>{e(why)}</div><div>{tags}</div>
<div class='row' style='margin-top:7px'><a class='btn btn2 openLink' style='padding:4px 7px;font-size:11px' href='/item/{int(r['id'])}'>Open</a>{best}</div></div></div>"""
            body+='</div>'
            if not shown:body+="<div class='empty'>No match yet. Try a property such as vertical, high motion, dark, drone, long, Android, audio, safe, or best. Object/people vision search comes in the next semantic layer.</div>"
            body+=page_nav(page,pages,{'q':q})
        else:
            body+="<div class='empty' style='margin-top:18px'>Try one of the examples above. Nothing leaves this computer.</div>"
        return layout('Search',body)

    @app.get('/api/search')
    def smart_search_api():
        q=request.args.get('q','').strip()[:240]
        try: limit=min(200,max(1,int(request.args.get('limit','50') or 50)))
        except Exception: limit=50
        data=semantic_search(q,limit=limit)
        out=[]
        for r in data.get('results') or []:
            out.append({'id':int(r['id']),'media_type':r.get('media_type'),'duration_ms':r.get('duration_ms'),
                        'semantic_score':r.get('semantic_score'),'why':r.get('why'),'tags':r.get('tags'),
                        'best_clip_id':r.get('best_clip_id'),'best_clip_score':r.get('best_clip_score')})
        return jsonify({'query':data.get('query'),'model':data.get('model'),'intents':data.get('intents'),
                        'tokens':data.get('tokens'),'index_count':data.get('index_count'),'results':out})

    @app.get('/best')
    def best_moments():
        rows=best_clips(160)
        body="<div class='pagehead row space'><div><div class='eyebrow'>Media Brain</div><h1>Best Moments</h1><div class='lead'>Virtual clips ranked from your existing footage. Nothing here creates a new video file.</div></div><a class='btn btn2' href='/library?media_type=video'>Videos</a></div><div class='grid'>"
        for r in rows:
            start=r['start_ms']/1000.0; end=r['end_ms']/1000.0
            body+=f"""<div class='media-card'><div class='thumb'><img loading='lazy' src='/clip-preview/{r['id']}'></div><div class='meta'><div class='row space'><span class='badge {'safe' if r['label']=='best' else 'ready'}'>{e(r['label'])} {e(r['score'])}</span><span class='small'>{int(start//60)}:{int(start%60):02d}–{int(end//60)}:{int(end%60):02d}</span></div><div class='name' translate='no'>{e(r['filename'])}</div><div class='small'>{e(r['reason'])}</div><div><a class='btn btn2 openLink' style='padding:4px 7px;font-size:11px' href='/clip/{r['id']}?back=best'>Open clip</a></div></div></div>"""
        body+="</div>"
        if not rows: body+="<div class='empty'>No Media Brain clips yet. Select local videos in Library and run Media Brain.</div>"
        return layout('Best Moments',body)


    @app.get('/clip/<int:clip_id>')
    def virtual_clip(clip_id):
        with db() as con:
            r=con.execute("""SELECT vc.*,i.filename,i.width,i.height,i.source_label,i.media_type,i.work_selected,i.excluded,
                i.path,i.staging_path,i.archive_path,i.private_path,i.duration_ms
                FROM virtual_clips vc JOIN inventory i ON i.id=vc.inventory_id
                WHERE vc.id=? AND i.excluded=0""",(clip_id,)).fetchone()
            if not r or not inventory_visible(con,r['inventory_id']):     # (a copy of a Private video too)
                return 'Clip not found',404
            crops=[dict(x) for x in con.execute("""SELECT * FROM crop_plans WHERE clip_id=?
                ORDER BY CASE aspect WHEN '16:9' THEN 1 WHEN '4:5' THEN 2 WHEN '1:1' THEN 3 ELSE 4 END""",(clip_id,)).fetchall()]
        d=dict(r)
        inv_id=int(d['inventory_id'])
        start=float(d['start_ms'])/1000.0
        end=float(d['end_ms'])/1000.0
        clip_len=max(.05,end-start)
        ratios={'16:9':16/9,'4:5':4/5,'1:1':1.0,'9:16':9/16}
        try:
            src_ratio=float(d.get('width') or 0)/float(d.get('height') or 1)
            if src_ratio <= 0:
                src_ratio=16/9
        except Exception:
            src_ratio=16/9
        crop_map={x['aspect']:x for x in crops}
        default_aspect=min(crop_map.keys(),key=lambda a:abs(ratios.get(a,1)-src_ratio)) if crop_map else 'original'
        preset=(crops[0].get('preset') if crops else None) or 'general'
        back=request.args.get('back','best')
        back_url=f"/item/{inv_id}" if back=='item' else '/best'
        back_label='Video' if back=='item' else 'Best Moments'
        def mm(s):
            return f"{int(s//60)}:{int(s%60):02d}"
        plans={a:{'x':float(x['x']),'y':float(x['y']),'w':float(x['w']),'h':float(x['h']),
                  'confidence':float(x['confidence'] or 0),'preset':x['preset']} for a,x in crop_map.items()}
        v2_enabled=request.args.get('smart_crop_v2')=='1' or os.environ.get('ARCHIVIST_SMART_CROP_V2')=='1'
        trajectories=trajectories_for_clip(clip_id) if v2_enabled else {}
        trajectory_payload={a:{k:v for k,v in t.items() if k not in ('id','clip_id','created_at','updated_at')} for a,t in trajectories.items()}
        clip_config=json.dumps({'start':start,'end':end,'length':clip_len,'sourceRatio':src_ratio,
                                'defaultAspect':default_aspect,'plans':plans,'smartCropV2':v2_enabled,
                                'trajectories':trajectory_payload}).replace('<','\\u003c')
        body=render_template('virtual_clip.html',clip_config=clip_config,clip_id=clip_id,inv_id=inv_id,
                             filename=d['filename'],start_label=mm(start),end_label=mm(end),
                             length_label=mm(clip_len),clip_len=clip_len,score=d['score'],label=d['label'],
                             reason=d['reason'] or '',back_url=back_url,back_label=back_label,
                             src_ratio=src_ratio,plans=plans,preset=preset,show_car_rebuild=preset!='car',
                             smart_crop_v2=v2_enabled,trajectories=trajectory_payload,
                             review_url=f"/clip/{clip_id}?back={urllib.parse.quote(back)}&smart_crop_v2=1")
        export_opts="<option value='original'>Original framing</option>"+''.join(f"<option value='{e(a)}'>{e(a)} Smart Crop</option>" for a in ('16:9','4:5','1:1','9:16') if a in plans)
        body+=f"<div class='card' style='margin-top:12px'><div class='eyebrow'>Local Render</div><h3>Export clip</h3><div class='muted'>Create a new MP4 from this virtual clip. Original footage stays untouched. Smart Crop export uses the approved static crop plan for this first render layer.</div><form method='post' action='/clip/{clip_id}/export' class='toolbar'><select name='aspect'>{export_opts}</select><button>Export MP4</button></form></div>"
        return layout('Virtual clip',body,script_srcs=('/static/virtual_clip.js',))

    @app.post('/api/clip/<int:clip_id>/trajectory/<aspect>')
    def save_trajectory(clip_id,aspect):
        aspect=urllib.parse.unquote(aspect)
        p=_json_obj()
        try:
            result=save_crop_trajectory(clip_id,aspect,p.get('keyframes') or [],preset=str(p.get('preset') or 'general'),
                status=str(p.get('status') or 'draft'),confidence=float(p.get('confidence') or 0),
                smoothing=float(p.get('smoothing') or .35),max_pan_per_second=float(p.get('max_pan_per_second') or .35),
                max_zoom_per_second=float(p.get('max_zoom_per_second') or .25),source='manual')
            return jsonify({'ok':True,'trajectory':result})
        except ValueError as exc:
            return jsonify({'error':str(exc)}),400

    @app.post('/api/clip/<int:clip_id>/track/<aspect>')
    def track_trajectory(clip_id,aspect):
        aspect=urllib.parse.unquote(aspect)
        with db() as con:
            row=con.execute("""SELECT vc.*,i.path,i.staging_path,i.archive_path,i.private_path,i.duration_ms
                FROM virtual_clips vc JOIN inventory i ON i.id=vc.inventory_id WHERE vc.id=? AND i.excluded=0""",(clip_id,)).fetchone()
            plan=con.execute("SELECT * FROM crop_plans WHERE clip_id=? AND aspect=? ORDER BY id DESC LIMIT 1",(clip_id,aspect)).fetchone()
            if row and not inventory_visible(con,row['inventory_id']): row=None
        if not row or not plan: return jsonify({'error':'Clip or crop plan not found'}),404
        local=next((Path(row[k]) for k in ('staging_path','archive_path','private_path','path') if row[k] and Path(row[k]).exists()),None)
        if not local: return jsonify({'error':'Local video file is unavailable'}),409
        try:
            duration=max(float(row['duration_ms'] or 0)/1000.0,float(row['end_ms'])/1000.0)
            result=build_tracked_trajectory(clip_id,aspect,dict(plan),local,float(row['start_ms'])/1000.0,float(row['end_ms'])/1000.0,duration,str(plan['preset'] or 'general'))
            return jsonify({'ok':True,'trajectory':result})
        except Exception as exc:
            return jsonify({'error':str(exc)[:500]}),400

    @app.post('/api/clip/<int:clip_id>/trajectory-status/<aspect>')
    def trajectory_status(clip_id,aspect):
        aspect=urllib.parse.unquote(aspect); p=_json_obj(); status=str(p.get('status') or '')
        current=trajectory_for_clip(clip_id,aspect)
        if not current: return jsonify({'error':'Build or save a trajectory first'}),404
        try:
            result=save_crop_trajectory(clip_id,aspect,current['keyframes'],preset=current['preset'],status=status,
                confidence=float(current.get('confidence') or 0),smoothing=float(current.get('smoothing') or .35),
                max_pan_per_second=float(current.get('max_pan_per_second') or .35),max_zoom_per_second=float(current.get('max_zoom_per_second') or .25),source='manual_review')
            return jsonify({'ok':True,'trajectory':result})
        except ValueError as exc:
            return jsonify({'error':str(exc)}),400


    @app.post('/clip/<int:clip_id>/export')
    def clip_export(clip_id):
        aspect=request.form.get('aspect','original')
        try:
            result=export_clip(clip_id,aspect)
            body=f"<div class='pagehead'><div class='eyebrow'>Local Render</div><h1>Export complete</h1><div class='lead'>A new derived MP4 was created in MediaEngine Exports. The source video was not modified.</div></div><div class='card'><div class='row space'><div><b>{e(aspect)}</b><div class='muted'>{human_bytes(result['output_bytes'])}</div></div><a class='btn' href='/export-file/{int(result['export_id'])}'>Open exported MP4</a></div><div style='margin-top:12px'><a class='btn btn2' href='/clip/{clip_id}'>Back to clip</a></div></div>"
            return layout('Export complete',body)
        except Exception as exc:
            return layout('Export failed',f"<div class='card'><h2>Export failed</h2><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/clip/{clip_id}'>Back</a></div>"),400

    @app.get('/export-file/<int:export_id>')
    def export_file(export_id):
        x=export_by_id(export_id)
        if not x:return 'Not found',404
        with db() as con:     # made before its video became Private: not shown any more
            vis=con.execute("SELECT inventory_id FROM virtual_clips WHERE id=?",(int(x['clip_id']),)).fetchone()
            if not vis or not inventory_visible(con,vis['inventory_id']):return 'Export unavailable',404
        p=Path(x['output_path'])
        if not p.exists() or p.parent.resolve()!=EXPORTS.resolve():return 'Export unavailable',404
        return send_file(p,mimetype='video/mp4',conditional=True)


    @app.get('/composer')
    def composer_home():
        ensure_composer_schema();clips=best_clips(80)
        body="<div class='pagehead'><div class='eyebrow'>Content Composer</div><h1>Content Composer</h1><div class='lead'>Select existing Virtual Clips, choose one target aspect and build a local composition. Renders run locally in the background with normalized stereo audio; silent clips receive silence so every segment concatenates reliably. Originals stay untouched.</div></div>"
        if not clips:     # (nothing to choose from yet: say where the moments come from, not a form that cannot work)
            body+=("<div class='card'><b>No moments to put together yet</b><div class='muted' style='margin-top:6px'>Here you put "
                   "together moments that MediaEngine found in your videos. First let it find them: in the Library tick your "
                   "videos and press Media Brain (a few minutes for an hour of video); the moments then appear here and in "
                   "Best Moments. To make a reel from a whole folder of videos at once, use Auto Edit.</div>"
                   "<div class='row' style='margin-top:10px;gap:8px;flex-wrap:wrap'><a class='btn' href='/library?media_type=video'>Library</a>"
                   "<a class='btn btn2' href='/import'>Import videos</a><a class='btn btn2' href='/auto'>Auto Edit</a></div></div>")
        body+="<form method='post' action='/composer/create' id='cmpForm'"+(" hidden" if not clips else "")+"><div class='card toolbar'><input name='title' placeholder='Composition title' maxlength='80'><select name='aspect'><option>16:9</option><option>9:16</option><option>4:5</option><option>1:1</option></select><button id='cmpGo' disabled>Create composition</button><span class='muted'>Up to 20 clips / 180 seconds</span><span class='muted' id='cmpHint'>Tick the moments below</span></div><div class='grid'>"
        for r in clips:
            st=float(r['start_ms'])/1000;en=float(r['end_ms'])/1000
            body+=f"<label class='media-card'><input class='check' type='checkbox' name='clip_id' value='{int(r['id'])}'><div class='thumb'><img loading='lazy' src='/clip-preview/{int(r['id'])}'></div><div class='meta'><div class='row space'><b>{e(r['label'])} {e(r['score'])}</b><span class='small'>{int(st//60)}:{int(st%60):02d}–{int(en//60)}:{int(en%60):02d}</span></div><div class='name' translate='no'>{e(r['filename'])}</div></div></label>"
        body+="</div></form>"
        with db() as con: existing=[dict(x) for x in con.execute("SELECT id,title,aspect,status,output_bytes FROM compositions ORDER BY id DESC LIMIT 20").fetchall()]
        if existing:
            body+="<div class='section-title'>Recent compositions</div><div class='jobs'>"
            for x in existing:body+=f"<a class='card jobrow' href='/composer/{int(x['id'])}'><b>#{int(x['id'])}</b><span>{e(x['title'])}</span><span class='badge {e(x['status'])}'>{e(x['status'])}</span><span>{e(x['aspect'])} · {human_bytes(x['output_bytes']) if x['output_bytes'] else 'not rendered'}</span></a>"
            body+="</div>"
        body+=("<script>(()=>{const f=document.getElementById('cmpForm');if(!f)return;const go=document.getElementById('cmpGo'),"
               "h=document.getElementById('cmpHint');const upd=()=>{const n=f.querySelectorAll('input[name=clip_id]:checked').length;"
               "go.disabled=!n;h.textContent=n?((window.ME_L?ME_L('Chosen:'):'Chosen:')+' '+n):(window.ME_L?ME_L('Tick the moments below'):"
               "'Tick the moments below');};f.addEventListener('change',upd);upd();})();</script>")
        return layout('Content Composer',body)

    @app.post('/composer/create')
    def composer_create():
        try:
            cid=create_composition(request.form.getlist('clip_id'),request.form.get('aspect','16:9'),request.form.get('title',''))
            return redirect(f'/composer/{cid}')
        except Exception as exc:return layout('Composer',f"<div class='card'><h2>Could not create composition</h2><div class='errbox'>{e(str(exc)[:500])}</div><a class='btn btn2' href='/composer'>Back</a></div>"),400
    # (the message is the composer's own sentence: translated like the page)

    @app.get('/composer/<int:cid>')
    def composer_detail_page(cid):
        c=composition_detail(cid)
        if not c:return 'Not found',404
        body=f"<div class='pagehead row space'><div><div class='eyebrow'>Content Composer</div><h1>{e(c['title'])}</h1><div class='lead'>{e(c['aspect'])} · {len(c['items'])} clips · {e(c['status'])}</div></div><a class='btn btn2' href='/composer'>Composer</a></div><div class='jobs'>"
        busy=c.get('status') in ('queued','rendering')      # the order stays as the video being made has it
        for x in c['items']:
            pos=int(x['position']);st=float(x['start_ms'])/1000;en=float(x['end_ms'])/1000
            moves='' if busy else f"<form method='post' action='/composer/{cid}/move'><input type='hidden' name='position' value='{pos}'><input type='hidden' name='direction' value='up'><button class='btn2'>↑</button></form><form method='post' action='/composer/{cid}/move'><input type='hidden' name='position' value='{pos}'><input type='hidden' name='direction' value='down'><button class='btn2'>↓</button></form><form method='post' action='/composer/{cid}/remove'><input type='hidden' name='position' value='{pos}'><input type='hidden' name='clip' value='{int(x['id'])}'><button class='btn2'>Remove</button></form>"
            body+=f"<div class='card jobrow'><b>{pos}</b><img src='/clip-preview/{int(x['id'])}' style='width:88px;height:50px;object-fit:cover;border-radius:7px'><span><span translate='no'>{e(x['filename'])}</span><div class='muted'>{int(st//60)}:{int(st%60):02d}–{int(en//60)}:{int(en%60):02d}</div></span><span class='row'>{moves}</span></div>"
        if c.get('hidden_items'):body+=(f"<div class='card muted'><span>Moments of videos that are now Private or no longer in the Library are not shown, and this composition cannot be made into a video until they are taken out:</span> {int(c['hidden_items'])}"
                                        + ("" if busy else f"<form method='post' action='/composer/{cid}/drop-hidden' style='margin-top:8px'><button class='btn2'>Take them out</button></form>") + "</div>")
        body+="</div><div class='card' style='margin-top:12px'><b>Render composition</b><div class='muted'>Local MP4 rendered in the background. Every segment is normalized to the target aspect and stereo AAC; silent clips receive a silent track. Existing Smart Crop plans are used when available.</div><form method='post' action='/composer/%d/render' style='margin-top:10px'><button>Render MP4</button></form>"%cid
        if c.get('output_path') and Path(c['output_path']).exists():body+=f"<a class='btn btn2' style='margin-left:8px' href='/composition-file/{cid}'>Open latest MP4</a>"
        if c.get('last_error'):body+=f"<div class='errbox'>{e(c['last_error'])}</div>"
        body+="</div>"
        if not busy:      # two steps: the button, then "Delete for good"
            body+=(f"<details class='card' style='margin-top:12px'><summary>Delete this composition</summary><div class='muted' style='margin:8px 0'>Its moments stay in the Library; its MP4 files in Exports are deleted.</div>"
                   f"<form method='post' action='/composer/{cid}/delete'><button class='btn2'>Delete for good</button></form></details>")
        script="setTimeout(()=>location.reload(),1500);" if c.get('status') in ('queued','rendering') else ''
        return layout('Composition',body,script)

    @app.post('/composer/<int:cid>/move')
    def composer_move(cid):
        try:pos=int(str(request.form.get('position','1')).strip())
        except ValueError:pos=0
        try:
            if 0<pos<100000:move_composer_item(cid,pos,request.form.get('direction','down'))
        except ValueError:pass          # (a page from before the render started: the order stays as it is being made)
        return redirect(f'/composer/{cid}')

    @app.post('/composer/<int:cid>/remove')
    def composer_remove(cid):
        try:pos=int(str(request.form.get('position','0')).strip())
        except ValueError:pos=0
        try:clip=int(str(request.form.get('clip','')).strip())
        except ValueError:clip=None
        try:
            if 0<pos<100000:remove_composer_item(cid,pos,clip if clip and 0<clip<2**62 else None)
        except ValueError:pass
        return redirect(f'/composer/{cid}')

    @app.post('/composer/<int:cid>/drop-hidden')
    def composer_drop_hidden(cid):
        drop_composer_hidden(cid)
        return redirect(f'/composer/{cid}')

    @app.post('/composer/<int:cid>/delete')
    def composer_delete(cid):
        try:delete_composition(cid)
        except ValueError as exc:
            return layout('Composer',f"<div class='card'><h2>Could not delete</h2><div class='errbox'>{e(str(exc))}</div><a class='btn btn2' href='/composer/{cid}'>Back</a></div>"),400
        return redirect('/composer')

    @app.post('/composer/<int:cid>/render')
    def composer_render(cid):
        try:start_composer_render(cid)
        except Exception:pass
        return redirect(f'/composer/{cid}')

    @app.get('/composition-file/<int:cid>')
    def composition_file(cid):
        c=composition_detail(cid)
        if not c or not c.get('output_path'):return 'Not found',404
        if c.get('hidden_items'):return 'Unavailable: a video in it is Private or no longer in the Library',404
        p=Path(c['output_path'])
        if not p.exists() or p.parent.resolve()!=COMPOSER_EXPORTS.resolve():return 'Unavailable',404
        return send_file(p,mimetype='video/mp4',conditional=True)

    @app.get('/import')
    def import_page():
        return gallery('import')


    @app.get('/convert')
    def convert_page():
        q=request.args.get('q','').strip()
        source_id=request.args.get('source_id','').strip()
        source_kind=request.args.get('source_kind','').strip()
        scope=request.args.get('scope','all').strip() or 'all'
        sort=request.args.get('sort','date_desc').strip() or 'date_desc'
        preselect_ids=set(_id_list(request.args.get('ids',''),2000))
        where=["excluded=0","media_type='video'","private_path IS NULL","rejected_path IS NULL","COALESCE(analysis_status,'')<>'private'"]
        args=[]
        if scope=='library': where.append("work_selected=1")
        if q:
            qf='%'+q.casefold().replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
            where.append("(fold(filename) LIKE ? ESCAPE '\\' OR fold(path) LIKE ? ESCAPE '\\')");args += [qf,qf]
        if source_kind:
            where.append("source_kind=?");args.append(source_kind)
        if source_id:
            where.append("source_id=?");args.append(source_id)
        order_map={'date_desc':'COALESCE(date_taken,mtime,0) DESC,id DESC','date_asc':'COALESCE(date_taken,mtime,0) ASC,id ASC','size_desc':'COALESCE(size_bytes,0) DESC','size_asc':'COALESCE(size_bytes,0) ASC','duration_desc':'COALESCE(duration_ms,0) DESC','name':'LOWER(filename) ASC','source':"LOWER(COALESCE(source_label,source_id,'')) ASC,LOWER(filename) ASC"}
        order_sql=order_map.get(sort,order_map['date_desc'])
        page=max(1,request.args.get('page',1,type=int) or 1); per=120
        where_sql=' AND '.join(where)
        with db() as con:
            source_rows=con.execute("SELECT source_id,MAX(source_label) source_label FROM inventory WHERE "+where_sql+" GROUP BY source_id ORDER BY LOWER(COALESCE(MAX(source_label),source_id,''))",args).fetchall()
            if preselect_ids:
                chosen=sorted(preselect_ids)
                marks=','.join('?' for _ in chosen)
                raw_rows=con.execute("SELECT * FROM inventory WHERE "+where_sql+" AND id IN ("+marks+") ORDER BY "+order_sql,args+chosen).fetchall()
                total_catalog=len(raw_rows); pages=1; page=1
            else:
                total_catalog=int(con.execute("SELECT COUNT(*) n FROM inventory WHERE "+where_sql,args).fetchone()['n'])
                pages=max(1,(total_catalog+per-1)//per); page=min(page,pages)
                raw_rows=con.execute("SELECT * FROM inventory WHERE "+where_sql+" ORDER BY "+order_sql+" LIMIT ? OFFSET ?",args+[per,(page-1)*per]).fetchall()
        available_paths={}
        for r in raw_rows:
            local_path=next((r[k] for k in ('staging_path','archive_path','path') if r[k] and Path(r[k]).exists()),None)
            if local_path: available_paths[int(r['id'])]=local_path
        local=[r for r in raw_rows if int(r['id']) in available_paths]
        sources={}
        for r in source_rows:
            sid=r['source_id'] or ''
            sources[sid]=r['source_label'] or sid or 'Local'
        skipped_preselected=max(0,len(preselect_ids)-len(local)) if preselect_ids else 0
        total_local=len(local)
        with db() as con:
            _rr=con.execute("SELECT id FROM jobs WHERE kind='convert' AND status IN ('running','queued') ORDER BY id DESC LIMIT 1").fetchone()
            _rd=con.execute("SELECT id FROM jobs WHERE kind='convert' AND status IN ('finished','failed','cancelled','partial') "
                            "AND NOT (status='cancelled' AND started_at IS NULL) ORDER BY COALESCE(finished_at,'') DESC,id DESC LIMIT 1").fetchone()
            _rw=con.execute("SELECT id,options_json FROM jobs WHERE kind='convert' AND status='waiting' AND cancel_requested=0 ORDER BY id").fetchall()
        running=convert_job_snapshot(int(_rr['id'])) if _rr else None
        last_done=convert_job_snapshot(int(_rd['id'])) if _rd else None
        latest=running or last_done
        # the jobs taken off the page ("Remove from the page": each one by itself; an older build kept only the highest)
        _hc=load_config()
        hidden_jobs={int(x) for x in (_hc.get('convert_hidden_jobs') or []) if str(x).isdigit()}
        if str(_hc.get('convert_hidden_job') or '').isdigit():
            hidden_jobs.add(int(_hc['convert_hidden_job']))
        # earlier conversions (the last ten before the one shown, not those taken off the page): their files and buttons
        history=''
        try:
            with db() as con:
                hrows=con.execute("SELECT id FROM jobs WHERE kind='convert' AND status IN ('finished','failed','partial') "
                                  "ORDER BY id DESC LIMIT 40").fetchall()
            hparts=[]
            for hr in hrows:
                hid=int(hr['id'])
                if (latest and hid==int(latest['id'])) or (last_done and hid==int(last_done['id'])) or hid in hidden_jobs:
                    continue
                hj=convert_job_snapshot(hid); inner=_convert_outputs_html(hj)
                if not inner or len(hparts)>=10:
                    continue
                try:
                    from datetime import datetime as _dt
                    when=_dt.fromisoformat(str(hj.get('finished_at') or '')).astimezone().strftime('%Y-%m-%d %H:%M')
                except Exception:
                    when=''
                hparts.append(f"<div data-job-box='{hid}' style='margin-top:10px'><div class='small muted'><span>Conversion</span> #{hid}"
                              f"{(' · <span translate=no>'+e(when)+'</span>') if when else ''}</div>{inner}</div>")
            if hparts:
                history=(f"<details class='card' style='margin-top:10px'><summary><b>Earlier conversions</b> <span class='badge'>{len(hparts)}</span></summary>"
                         f"{''.join(hparts)}</details>")
        except Exception:
            history=''
        # an NVIDIA card that was never tested for converting: the one-minute test offered here (then used by itself)
        gpu_hint=''
        try:
            from .converter import gpu_test_saved, gpu_test_state
            from . import hwdecode as _hwd
            if not gpu_test_saved() and not gpu_test_state().get('running') and any('NVIDIA' in str(n).upper() for n in (_hwd.saved().get('gpu') or [])):
                gpu_hint=("<div class='card' style='margin-top:10px'><b>This PC has an NVIDIA graphics card</b>"
                          "<div class='small muted' style='white-space:normal'>A two-minute test shows whether converting on it is faster with the same picture; "
                          "after that, Convert uses it by itself (the first conversion runs the test by itself). Your videos are not used.</div>"
                          "<form method='post' action='/auto/check/convert-gpu-test' style='margin:6px 0 0'><button class='btn2'>Test converting on the graphics card</button></form></div>")
        except Exception:
            gpu_hint=''
        from .converter import output_folder, logo_saved, LOGO_CORNERS
        out_dir=output_folder()
        lg=logo_saved()
        corner_names={'bottom-right':'bottom right','bottom-left':'bottom left','top-right':'top right','top-left':'top left'}
        logo_html=(("<label><input type='checkbox' id='logoOut'> <span>Logo</span></label>"
                    f"<img src='/api/convert/logo.png?v={int(Path(lg['path']).stat().st_mtime)}' alt='' style='height:28px;max-width:90px;object-fit:contain;background:#555;border-radius:4px'>"
                    "<select id='logoCorner'>"+''.join(f"<option value='{c}' {'selected' if c==lg['corner'] else ''}>{corner_names[c]}</option>" for c in LOGO_CORNERS)+"</select>"
                    "<select id='logoSize'>"+''.join(f"<option value='{z}' {'selected' if z==lg['size'] else ''}>{z}%</option>" for z in sorted({8,12,16,20,25,int(lg['size'])}))+"</select>"
                    "<button class='btn2' type='button' data-cv='logo-pick'>Another logo…</button><button class='btn2' type='button' data-cv='logo-clear'>Remove the logo</button>")
                   if lg else "<button class='btn2' type='button' data-cv='logo-pick'>Choose a logo…</button><span class='muted small'>Your logo in a corner of every video (chosen once).</span>")
        srcopts="<option value=''>All local sources</option>"+''.join(f"<option value='{e(k)}' translate='no' {'selected' if k==source_id else ''}>{e(v)}</option>" for k,v in sorted(sources.items(),key=lambda x:x[1].lower()))
        cards=''
        for r in local:
            local_path=available_paths.get(int(r['id']))
            available=bool(local_path)
            if available: queue_thumbnail(int(r['id']),priority=0)
            prechecked='checked' if (available and int(r['id']) in preselect_ids) else ''
            disabled='' if available else 'disabled'
            unavailable='' if available else "<div class='small error'>Local file unavailable — reconnect the source or restore the file.</div>"
            cards+=f"""<label class='card convertRow' data-size='{int(r['size_bytes'] or 0)}' data-duration-ms='{int(r['duration_ms'] or 0)}' data-width='{int(r['width'] or 0)}' data-height='{int(r['height'] or 0)}' style='display:grid;grid-template-columns:auto 92px 1fr auto;gap:12px;align-items:center;padding:10px;cursor:pointer;opacity:{1 if available else .55}'>
<input type='checkbox' name='ids' value='{int(r['id'])}' class='convertCheck' data-name='{e(r['filename'])}' data-folder='{e(str(Path(local_path).parent) if local_path else "")}' data-size='{int(r['size_bytes'] or 0)}' data-duration-ms='{int(r['duration_ms'] or 0)}' data-width='{int(r['width'] or 0)}' data-height='{int(r['height'] or 0)}' {prechecked} {disabled}>
<div class='convertThumbWrap' style='width:92px;height:58px;position:relative'><img class='convertThumb' data-id='{int(r['id'])}' src='/thumb/{int(r['id'])}' style='width:92px;height:58px;object-fit:cover;border-radius:7px;background:#090b0e'><span class='storybadge convertStoryBadge' style='left:4px;top:4px'></span></div>
<div style='min-width:0'><b style='display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' translate='no'>{e(r['filename'])}</b>
<div class='small muted'><span translate='no'>{e(r['source_label'])}</span> · <span>{human_duration(r['duration_ms'])}</span> · <span>{human_bytes(r['size_bytes'])}</span>{_filmed_txt(r)}</div><div class='small cvCutNote' style='color:#9db4ff'></div>{unavailable}</div>
<div style='text-align:right'><span class='badge'>#{int(r['id'])}</span><div class='small muted estimateOne' style='margin-top:5px'></div>{"" if not available else "<button type='button' class='btn2 cvCutBtn' data-cut-for='"+str(int(r['id']))+"' style='padding:2px 10px;margin-top:4px'>Cut…</button>"}</div></label>"""
        if not cards:
            cards=("<div class='card muted'>None of the selected videos are currently accessible. Restore/reconnect the source, or choose another local video.</div>" if preselect_ids else "<div class='card muted'>No accessible videos on this catalog page. Reconnect/restore the source, choose another page, or clear the filter.</div>")
        selection_notice=(f"<div class='card' style='border-color:#6f5c31;background:#1d1a12'><b>{skipped_preselected} selected video{'s' if skipped_preselected!=1 else ''} skipped</b><div class='small muted'>The item is no longer eligible for Convert or its local file is not currently accessible, so it was skipped safely.</div></div>" if skipped_preselected else "")
        active=''
        if latest:
            terminal=str(latest.get('status') or '') in ('finished','failed','cancelled','partial')
            if terminal and int(latest['id']) in hidden_jobs:
                pass
            elif terminal:
                tone='error' if str(latest.get('status')) in ('failed','cancelled') else 'ready'
                err=(f"<div class='small error' style='margin-top:6px'>{e(latest.get('error'))}</div>" if latest.get('error') and latest.get('error')!='interrupted_by_restart' else '')
                active=f"<div class='card' id='convertStatus' data-job='{int(latest['id'])}' data-done='1'><div class='row space'><b>Last converter job #{int(latest['id'])}</b><div class='row'><span class='badge {tone}'>{e(latest.get('status'))}</span><button class='btn btn2' type='button' data-cv='hide'>Remove from the page</button></div></div><div class='muted'>{e(latest.get('message') or latest.get('status'))}</div>{err}<div id='convertResults' style='margin-top:8px'>{_convert_outputs_html(latest)}</div></div>"
            else:
                active=f"<div id='convertStatus' class='card' data-job='{int(latest['id'])}'><div class='row space'><b>Converter job #{int(latest['id'])}</b><button class='btn btn2' type='button' data-cv='stop' id='convertStop'>Stop</button></div><div class='muted' id='convertMsg'>{e(latest.get('message') or latest.get('status'))}</div><div class='progress'><i id='convertPct' style='width:{float(latest.get('percent') or 0):.1f}%'></i></div><div class='small muted' id='convertEta'></div><div id='convertResults'></div></div>"
                # the job finished before this one stays on the page with its buttons (until removed from it)
                if last_done and int(last_done['id']) not in hidden_jobs:
                    ld=last_done; tone='error' if str(ld.get('status')) in ('failed','cancelled') else 'ready'
                    active+=(f"<div class='card' data-job-box='{int(ld['id'])}' style='margin-top:10px'><div class='row space'><b>Last converter job #{int(ld['id'])}</b>"
                             f"<div class='row'><span class='badge {tone}'>{e(ld.get('status'))}</span><button class='btn btn2' type='button' data-cv='hide'>Remove from the page</button></div></div>"
                             f"<div class='muted'>{e(ld.get('message') or ld.get('status'))}</div><div style='margin-top:8px'>{_convert_outputs_html(ld)}</div></div>")
        if _rw:
            wl=[]
            for w in _rw:
                try:
                    wo=json.loads(w['options_json'] or '{}')
                except Exception:
                    wo={}
                nv=len(wo.get('inventory_ids') or [])+len(wo.get('paths') or [])
                wx=wo.get('extra') if isinstance(wo.get('extra'),dict) else {}
                what=(f"<span>pictures every {int(wx['frames'])} s</span>" if str(wx.get('frames') or '').isdigit()
                      else f"<span>{e(CONVERT_PRESETS.get(str(wo.get('preset')),{}).get('label') or '')}</span>")
                wl.append(f"<div class='row space' data-wait='{int(w['id'])}' style='margin-top:6px'><span class='small'>#{int(w['id'])} · <span>{nv} video{'s' if nv!=1 else ''}</span> · {what}"
                          f"{' · <span>into one video</span>' if wo.get('join') else ''}</span><button class='btn btn2' type='button' data-cv='unqueue' data-job='{int(w['id'])}'>Take out of the line</button></div>")
            try:
                from .converter import gpu_test_state as _gts
                card_now=bool(_gts().get('running'))
            except Exception:
                card_now=False
            active+=(f"<div class='card' id='convertQueue' style='margin-top:10px'><b>Waiting in line</b> <span class='badge'>{len(wl)}</span>"
                     + ("<div class='small' style='color:#f0b35a'>The graphics card is being tested first (about two minutes, test clips only): then they start, on whichever was faster with the same picture.</div>" if card_now else "")
                     + f"<div class='small muted'>They start one by one, by themselves, when the job before them ends.</div>{''.join(wl)}</div>")
        body=f"""<div class='pagehead row space'><div><div class='eyebrow'>Tools</div><h1>Convert</h1><div class='lead'><span>Make smaller shareable copies without touching originals.</span> <span>Converted files go into:</span> <span class='ae-path'>{e(str(out_dir))}</span> <button class='btn2' type='button' data-cv='outdir' style='padding:2px 10px'>Change…</button>{"<button class='btn2' type='button' data-cv='outdir-reset' style='padding:2px 10px;margin-left:4px'>Back to Converted</button>" if out_dir!=HOME/'Converted' else ''}<br><span>Source folders and cards are never written to.</span></div></div><div class='row'><button class='btn' type='button' data-cv='folder'>Open the folder</button><a class='btn btn2' href='/import'>Add / discover a folder</a></div></div>
<div class='card'><div class='row space'><div style='min-width:0'><b>Preset</b><div class='muted small' style='white-space:normal'>Choose a preset. For messengers / sharing, Share 1080p is the balanced option.</div></div><span id='selectedCount' class='badge'>0 selected</span></div>
<div id='estimateSummary' class='card' style='margin-top:10px;padding:10px 12px;background:#111823'><b id='estimateOutput'>Select videos to see estimated output size.</b><div id='estimateNote' class='small muted' style='margin-top:3px'>Estimate is shown before conversion and may vary with image complexity.</div></div>
<style>.convertRow.convertSelected{{border-color:#6f91ff;box-shadow:0 0 0 1px #6f91ff inset;background:#192231}}.convertRow .estimateOne{{min-height:16px}}</style>
<div class='row' style='margin-top:10px;flex-wrap:wrap'>
<label class='card' style='padding:9px'><input type='radio' name='presetChoice' value='keep_resolution'> <b>Original Resolution</b><div class='small muted'>keep 4K / source resolution · lower bitrate</div></label>
<label class='card' style='padding:9px'><input type='radio' name='presetChoice' value='hq_1080p'> <b>High Quality 1080p</b><div class='small muted'>best-looking smaller 1080p copy</div></label>
<label class='card' style='padding:9px'><input type='radio' name='presetChoice' value='share_1080p'> <b>Share 1080p</b><div class='small muted'>balanced for messengers / sharing</div></label>
<label class='card' style='padding:9px'><input type='radio' name='presetChoice' value='small_720p'> <b>Small 720p</b><div class='small muted'>smallest practical share copy</div></label>
</div>
<div class='toolbar'><label>Fit under (optional) <input id='targetMb' type='number' min='5' step='1' placeholder='500' style='width:120px'> <span>MB</span></label><button id='startConvert' class='btn' disabled>Convert selected</button><span class='muted small'>Target size uses two-pass encoding and may take longer.</span></div>
<div class='toolbar' style='margin-top:4px'><label title='One video from all chosen ones, one after another'><input type='checkbox' id='joinOne'> <span>Join into one video</span></label><label><input type='checkbox' id='muteOut'> <span>Without sound</span></label><label><span>Turn the picture</span> <select id='turnOut'><option value='0'>as it is</option><option value='90'>90° right</option><option value='270'>90° left</option><option value='180'>upside down (180°)</option></select></label><button id='pickConvert' class='btn btn2' type='button'>Choose videos on this PC…</button><span class='muted small'>Any video on this computer, without adding it to the library.</span></div>
<div id='joinHint' class='small' style='display:none;margin-top:4px;white-space:normal'></div>
<details id='cvMore' style='margin-top:6px'><summary class='small'>More: speed, vertical 9:16, logo, date and time, sound</summary>
<div class='toolbar' style='margin-top:6px;flex-wrap:wrap'><label><span>Speed</span> <select id='speedOut'><option value='1'>as it is</option><option value='2'>2× faster</option><option value='4'>4× faster (no sound)</option><option value='8'>8× faster (no sound)</option><option value='0.5'>½× slow motion (for 60 fps videos)</option><option value='0.25'>¼× slow motion (no sound, for 120 fps)</option></select></label>
<label><span>Vertical 9:16</span> <select id='vertOut'><option value=''>as it is</option><option value='crop'>the middle, sides cut off</option><option value='blur'>the whole picture on a blurred background</option></select></label>
<label title='When it was filmed, every second, from the camera or phone clock - for reports'><input type='checkbox' id='clockOut'> <span>Date and time in the corner</span></label>
<label title='For videos filmed in the dark: the picture stretched to its full range, a little lighter'><input type='checkbox' id='brightOut'> <span>Brighter</span></label></div>
<div class='toolbar' style='margin-top:6px;flex-wrap:wrap'><span>Sound:</span><label><input type='checkbox' id='windOut'> <span>Less wind noise</span></label>
<label title='Quiet speech louder, loud parts softer - as loud as phones and players play videos'><input type='checkbox' id='loudOut'> <span>Even out the sound</span></label></div>
<div class='toolbar' style='margin-top:6px;flex-wrap:wrap'><label><span>Pictures every</span> <select id='framesEvery'><option value='5'>5 s</option><option value='10' selected>10 s</option><option value='30'>30 s</option><option value='60'>60 s</option></select></label><input id='framesTitle' maxlength='120' placeholder='Report title (optional)' style='width:260px;max-width:100%'><button id='framesStart' class='btn btn2' type='button' disabled>Save pictures of the selected videos</button><span class='muted small'>Photos for a report, into a folder next to the converted videos - and all of them in one PDF.</span></div>
<div class='toolbar' style='margin-top:6px;flex-wrap:wrap'>{logo_html}</div></details></div>
{active}{history}{gpu_hint}
{selection_notice}
<form class='toolbar' method='get' action='/convert'><input name='q' value='{e(q)}' placeholder='Search local videos'><select name='scope'><option value='all' {'selected' if scope=='all' else ''}>All accessible videos</option><option value='library' {'selected' if scope=='library' else ''}>Library only</option></select><select name='source_kind'><option value='' {'selected' if not source_kind else ''}>Any origin</option><option value='fixed' {'selected' if source_kind=='fixed' else ''}>Local folders</option><option value='android' {'selected' if source_kind=='android' else ''}>Android</option><option value='removable' {'selected' if source_kind=='removable' else ''}>SD/USB</option></select><select name='source_id'>{srcopts}</select><select name='sort'><option value='date_desc' {'selected' if sort=='date_desc' else ''}>Newest</option><option value='date_asc' {'selected' if sort=='date_asc' else ''}>Oldest</option><option value='size_desc' {'selected' if sort=='size_desc' else ''}>Largest</option><option value='size_asc' {'selected' if sort=='size_asc' else ''}>Smallest</option><option value='duration_desc' {'selected' if sort=='duration_desc' else ''}>Longest</option><option value='name' {'selected' if sort=='name' else ''}>Name</option><option value='source' {'selected' if sort=='source' else ''}>Source</option></select><button class='btn2'>Filter</button><a class='btn2' href='/convert'>Clear</a></form>
<div class='row space section-title'><span>{'Selected videos currently accessible' if preselect_ids else 'Accessible on this catalog page'} <span id='convertTotal' class='badge'>{total_local}</span></span><span class='row'><button class='btn2' type='button' id='cvAll'>Select all</button><button class='btn2' type='button' id='cvNone'>Clear the selection</button>{"<a class='btn btn2' href='/convert'>Show all local videos</a>" if preselect_ids else ''}</span></div><div class='small muted' style='margin:-6px 0 10px'>{"Only the selected IDs were checked for local availability." if preselect_ids else f"{total_catalog} matching catalog videos · local availability is checked only for the current page."}</div><div style='display:grid;gap:8px'>{cards}</div>"""
        script="""const checks=()=>[...document.querySelectorAll('.convertCheck:checked')];
const allChecks=[...document.querySelectorAll('.convertCheck')];
const presetKbps={share_1080p:4800,small_720p:2400,hq_1080p:8500};
const presetFallback={share_1080p:.20,small_720p:.11,hq_1080p:.34,keep_resolution:.58};
function chosenPreset(){return (document.querySelector('input[name=presetChoice]:checked')||{}).value||''}
function cutOf(ch){const a=Number(ch.dataset.cutStart),b=Number(ch.dataset.cutEnd);return (ch.dataset.cutStart!==undefined&&ch.dataset.cutEnd!==undefined&&b>a)?[a,b]:null}
function estimateBytes(ch){
  const full=Math.max(0,Number(ch.dataset.durationMs||0)/1000),c=cutOf(ch),frac=(c&&full>0)?Math.min(1,Math.max(0,(c[1]-c[0])/full)):1;
  const sp=Math.min(8,Math.max(0.25,Number((document.getElementById('speedOut')||{}).value||1)));
  const size=Number(ch.dataset.size||0)*frac/sp,dur=(c?(c[1]-c[0]):full)/sp,target=Number(document.getElementById('targetMb').value||0)||0;
  if(target)return Math.min(size||Infinity,target*1024*1024);
  const p=chosenPreset();
  if(!p)return null;
  if(p==='keep_resolution'){
    const w=Number(ch.dataset.width||0),h=Number(ch.dataset.height||0),px=w*h;
    const kbps=(Math.max(w,h)>=3000||px>=7000000)?32000:(px>=1800000?12000:6000);
    return dur>0?kbps*1000/8*dur:size*presetFallback.keep_resolution;
  }
  const kbps=presetKbps[p]||4800;
  return dur>0?kbps*1000/8*dur:size*(presetFallback[p]||.20);
}
function updSel(){
  const xs=checks(),selectedSet=new Set(xs),n=xs.length,x=document.getElementById('selectedCount'),out=document.getElementById('estimateOutput'),note=document.getElementById('estimateNote');
  if(x)x.textContent=n+' selected';
  let src=0,est=0,unknown=0;
  for(const ch of allChecks){
    const row=ch.closest('.convertRow'),one=row&&row.querySelector('.estimateOne');
    if(selectedSet.has(ch)){
      const sz=Number(ch.dataset.size||0),eb=estimateBytes(ch);src+=sz;if(Number.isFinite(eb))est+=eb;if(Number(ch.dataset.durationMs||0)<=0)unknown++;
      if(row)row.classList.add('convertSelected');if(one)one.textContent=Number.isFinite(eb)?'≈ '+hb(eb):'choose preset';
    }else{if(row)row.classList.remove('convertSelected');if(one)one.textContent=''}
  }
  const preset=chosenPreset(),start=document.getElementById('startConvert');if(start)start.disabled=!(n&&preset);
  const fs=document.getElementById('framesStart');if(fs)fs.disabled=!n;
  if(!n){if(out)out.textContent='Select videos to see estimated output size.';if(note)note.textContent='Estimate appears after you choose videos and a preset.';return}
  if(!preset){if(out)out.textContent=n+' video'+(n===1?'':'s')+' · '+hb(src)+' · choose a preset';if(note)note.textContent='No compression preset is selected yet.';return}
  const target=Number(document.getElementById('targetMb').value||0)||0;
  const delta=src-est,pct=src>0?Math.round(delta/src*100):0;
  if(target){
    // joined: one file per recording (each at most the size); a size too small for the length: said
    const jo=document.getElementById('joinOne'),join=jo&&jo.checked&&n>1,files=join?Math.max(1,joinGroups(xs.map(x=>({name:x.dataset.name||'',folder:x.dataset.folder||''}))).length):n;
    const spd=Math.min(8,Math.max(0.25,Number((document.getElementById('speedOut')||{}).value||1)));
    const tot=join?Math.min(src,files*target*1024*1024):est,d=xs.map(ch=>{const c=cutOf(ch);return (c?c[1]-c[0]:Number(ch.dataset.durationMs||0)/1000)/spd});
    const longest=join?d.reduce((a,b)=>a+b,0)/files:Math.max(0,...d),mute=(document.getElementById('muteOut')||{}).checked;
    const kbps=longest>0?target*8*1024*1024*0.94/longest/1000-(mute?0:128):Infinity,low=preset==='small_720p'?350:(preset==='keep_resolution'?1500:700);
    if(out)out.textContent=n+' video'+(n===1?'':'s')+' · '+hb(src)+' → target ≤ '+hb(tot)+' total';
    if(note)note.textContent=kbps<low?'This size is small for videos this long: the picture will be blurry.':
      target+' MB per file · save up to '+hb(Math.max(0,src-tot))+(src>0&&src-tot>0?' / '+Math.round((src-tot)/src*100)+'%':'')+'.';
  }else{
    if(out)out.textContent=n+' video'+(n===1?'':'s')+' · '+hb(src)+' → estimated ≈ '+hb(est);
    if(note)note.textContent=(delta>=0?'Estimated saving '+hb(delta)+(pct>0?' / '+pct+'%':''):'Estimated output may be larger than source')+(unknown?' · refining from video duration…':' · actual size can vary by about 20–30%.');
  }
}
let probeBusy=false;
async function probeMissingDurations(){
  if(probeBusy)return;
  const missing=checks().filter(ch=>(Number(ch.dataset.durationMs||0)<=0||Number(ch.dataset.width||0)<=0||Number(ch.dataset.height||0)<=0)&&ch.dataset.probeState!=='done');
  if(!missing.length)return;
  probeBusy=true;missing.forEach(ch=>ch.dataset.probeState='pending');
  try{
    const r=await fetch('/api/convert/probe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:missing.map(ch=>Number(ch.value))})});
    const x=await r.json();
    for(const ch of missing){
      const meta=(x.items||{})[String(ch.value)]||{},ms=Number(meta.duration_ms||0),w=Number(meta.width||0),h=Number(meta.height||0);
      if(ms>0)ch.dataset.durationMs=String(ms);if(w>0)ch.dataset.width=String(w);if(h>0)ch.dataset.height=String(h);const row=ch.closest('.convertRow');if(row){if(ms>0)row.dataset.durationMs=String(ms);if(w>0)row.dataset.width=String(w);if(h>0)row.dataset.height=String(h)}
      ch.dataset.probeState='done';
    }
  }catch(e){missing.forEach(ch=>ch.dataset.probeState='done')}finally{probeBusy=false;updSel()}
}
allChecks.forEach(x=>x.addEventListener('change',()=>{updSel();probeMissingDurations()}));
document.querySelectorAll('input[name=presetChoice]').forEach(x=>{x.addEventListener('change',updSel);x.addEventListener('click',updSel)});
document.getElementById('targetMb').addEventListener('input',updSel);
updSel();probeMissingDurations();
const convertRows=[...document.querySelectorAll('.convertRow')],convertImgs=[...document.querySelectorAll('.convertThumb')];
async function refreshConvertPreviews(){
  if(!convertImgs.length)return;
  try{
    const ids=convertImgs.map(x=>x.dataset.id).join(','),r=await fetch('/api/thumb-status?ids='+ids,{cache:'no-store'}),x=await r.json(),ready=new Set((x.ready||[]).map(String));
    for(const img of convertImgs){
      const id=String(img.dataset.id);
      if(ready.has(id)&&img.dataset.ready!=='1'){img.dataset.ready='1';img.src='/thumb/'+id+'?v='+(x.generation||Date.now())}
    }
    const unavailable=new Set((x.unavailable||[]).map(String));
    if(Number(x.pending_count||0)>0)setTimeout(refreshConvertPreviews,800);
    else if(unavailable.size)setTimeout(()=>{for(const img of convertImgs){if(unavailable.has(String(img.dataset.id))){img.dataset.ready='';img.src='/thumb/'+img.dataset.id+'?retry='+Date.now()}}setTimeout(refreshConvertPreviews,1200)},30000)
  }catch(e){setTimeout(refreshConvertPreviews,1800)}
}
function setupConvertStoryHover(){
  for(const row of convertRows){
    const ch=row.querySelector('.convertCheck'),img=row.querySelector('.convertThumb'),badge=row.querySelector('.convertStoryBadge');
    if(!ch||ch.disabled||!img)continue;
    let timer=null,hover=false;
    async function ensure(){
      const id=ch.value;
      for(let tries=0;tries<12&&hover;tries++){
        try{
          const r=await fetch('/api/storyboard-status?ids='+id,{cache:'no-store'}),x=await r.json(),st=(x.items||{})[id];
          if(st&&st.ready&&st.count>1){
            if(badge){badge.style.display='block';badge.textContent=st.count+' frames'}
            let idx=0;clearInterval(timer);
            timer=setInterval(()=>{if(!hover)return;img.src='/storyboard/'+id+'/'+idx+'?v='+Date.now();idx=(idx+1)%st.count},420);
            return
          }
          if(tries===0)await fetch('/api/storyboard/'+id+'/queue',{method:'POST'})
        }catch(e){}
        await new Promise(r=>setTimeout(r,700))
      }
    }
    row.addEventListener('mouseenter',()=>{hover=true;ensure()});
    row.addEventListener('mouseleave',()=>{hover=false;clearInterval(timer);timer=null;img.src='/thumb/'+ch.value+'?v='+Date.now()})
  }
}
refreshConvertPreviews();setupConvertStoryHover();
// the same order as the converter's part_key (converter.py): GoPro recording and chapter, else names with numbers as numbers
function natural(t){return String(t).toLowerCase().split(/(\\d+)/).filter(x=>x).map(x=>/^\\d+$/.test(x)?[1,Number(x),'']:[0,0,x])}
function partKey(n){const st=String(n||'').replace(/\\.[^.]*$/,'');let m=/^G[XHP](\\d{2})(\\d{4})$/i.exec(st);if(m)return [0,m[2],Number(m[1]),st.toLowerCase()];
 m=/^GOPR(\\d{4})$/i.exec(st);if(m)return [0,m[1],0,st.toLowerCase()];return [1,natural(st),0,st.toLowerCase()]}
function cmpKey(x,y){if(Array.isArray(x)&&Array.isArray(y)){for(let k=0;k<Math.min(x.length,y.length);k++){const c=cmpKey(x[k],y[k]);if(c)return c}return x.length-y.length}
 return x<y?-1:(x>y?1:0)}
function joinOrder(names){return names.slice().sort((a,b)=>cmpKey(partKey(a),partKey(b)))}
// the videos a join makes (converter.join_groups): GoPro parts - one per recording; else one of all
function joinGroups(xs){const it=xs.map(x=>typeof x==='string'?{name:x,folder:''}:x),ks=it.map(o=>partKey(o.name));
 if(it.length&&ks.every(k=>k[0]===0)){const arr=it.map((o,i)=>({o,k:ks[i],f:String(o.folder||'').toLowerCase()}));
  arr.sort((a,b)=>a.f<b.f?-1:(a.f>b.f?1:cmpKey(a.k,b.k)));const g=new Map();
  for(const a of arr){const key=a.f+'|'+a.k[1];if(!g.has(key))g.set(key,[]);g.get(key).push(a.o.name)}
  const v=[...g.values()];if(v.some(x=>x.length>1))return v}
 return it.length?[joinOrder(it.map(o=>o.name))]:[]}
function updJoin(){const box=document.getElementById('joinHint'),j=document.getElementById('joinOne');if(!box||!j)return;
 const sel=checks().map(x=>({name:x.dataset.name||'',folder:x.dataset.folder||''})),names=sel.map(o=>o.name);const groups=joinGroups(sel);
 const parts=names.length>=2&&groups.some(g=>g.length>1)&&names.every(n=>partKey(n)[0]===0);
 if(names.length<2){box.style.display='none';box.innerHTML='';return}
 if(!j.checked&&!parts){box.style.display='none';box.innerHTML='';return}
 const esc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let h='';if(parts&&!j.checked)h+=(groups.length>1?"<span>These videos are parts of GoPro recordings - each recording can be joined into one video.</span> ":"<span>These videos are parts of one GoPro recording - they can be joined into one video.</span> ");
 if(j.checked){if(groups.length>1){h+="<span>Each recording becomes one video:</span>";for(const g of groups)h+="<br><span translate='no'>"+g.map(esc).join(' → ')+"</span>"}
  else h+="<span>Order:</span> <span translate='no'>"+groups[0].map(esc).join(' → ')+"</span>"}
 box.innerHTML=h;box.style.display='block'}
document.getElementById('joinOne').addEventListener('change',()=>{updJoin();updSel()});
[['cvAll',true],['cvNone',false]].forEach(([id,on])=>{const b=document.getElementById(id);if(b)b.onclick=()=>{for(const ch of allChecks){if(!ch.disabled&&ch.checked!==on){ch.checked=on}}updJoin();updSel()}});
['logoCorner','logoSize'].forEach(id=>{const el=document.getElementById(id);if(el)el.addEventListener('change',()=>{fetch('/api/convert/logo',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({action:'set',corner:document.getElementById('logoCorner').value,size:Number(document.getElementById('logoSize').value)})}).catch(()=>{});const lo=document.getElementById('logoOut');if(lo&&!lo.checked){lo.checked=true;lo.dispatchEvent(new Event('change'))}})});
['speedOut'].forEach(id=>document.getElementById(id).addEventListener('change',updSel));document.getElementById('muteOut').addEventListener('change',updSel);allChecks.forEach(x=>x.addEventListener('change',updJoin));updJoin();
// the choices one keeps from time to time (the preset, sound and picture fixes, the date and time, the logo, how often
// pictures are taken) are remembered in this browser, as other programs do; speed, 9:16, turn, cut and join are per job
(function(){const K='me.convert.prefs',ids=['windOut','loudOut','clockOut','brightOut','logoOut','framesEvery'];
 function save(){try{const o={preset:chosenPreset()};for(const id of ids){const el=document.getElementById(id);if(el)o[id]=el.type==='checkbox'?el.checked:el.value}localStorage.setItem(K,JSON.stringify(o))}catch(e){}}
 try{const o=JSON.parse(localStorage.getItem(K)||'{}');if(o.preset){const r=document.querySelector("input[name=presetChoice][value='"+String(o.preset).replace(/[^a-z0-9_]/g,'')+"']");if(r)r.checked=true}
  for(const id of ids){const el=document.getElementById(id);if(!el||!(id in o))continue;if(el.type==='checkbox')el.checked=!!o[id];else if([...el.options].some(x=>x.value===String(o[id])))el.value=String(o[id])}
  if(ids.some(id=>id!=='framesEvery'&&o[id]===true&&document.getElementById(id))){const m=document.getElementById('cvMore');if(m)m.open=true}}catch(e){}
 document.querySelectorAll("input[name=presetChoice]").forEach(x=>x.addEventListener('change',save));
 for(const id of ids){const el=document.getElementById(id);if(el)el.addEventListener('change',save)}
 updSel()})();
function convOpts(){const preset=(document.querySelector('input[name=presetChoice]:checked')||{}).value||'';
 return {preset,target_mb:Number(document.getElementById('targetMb').value||0)||null,join:document.getElementById('joinOne').checked,mute:document.getElementById('muteOut').checked,turn:Number(document.getElementById('turnOut').value||0),
 extra:{speed:Number(document.getElementById('speedOut').value||1),vertical:document.getElementById('vertOut').value||'',wind:document.getElementById('windOut').checked,loud:!!(document.getElementById('loudOut')||{}).checked,clock:!!(document.getElementById('clockOut')||{}).checked,bright:!!(document.getElementById('brightOut')||{}).checked,
 logo:!!(document.getElementById('logoOut')||{}).checked}}}
// a cut: only the part between start and end is converted (the player, or the times typed as m:ss / seconds)
function fmtT(t){t=Math.round(Math.max(0,Number(t)||0)*10)/10;const m=Math.floor(t/60),x=Math.round((t-m*60)*10)/10;return m+':'+(x<10?'0':'')+x.toFixed(1)}
function fmtS(t){t=Math.round(Math.max(0,Number(t)||0));return Math.floor(t/60)+':'+String(t%60).padStart(2,'0')}
function parseT(v){v=String(v||'').trim().replace(',','.');if(!v)return null;const p=v.split(':').map(Number);if(p.some(x=>!Number.isFinite(x)||x<0))return NaN;
 return p.reduce((a,x)=>a*60+x,0)}
function showCut(ch){const row=ch.closest('.convertRow'),note=row&&row.querySelector('.cvCutNote'),c=cutOf(ch);
 if(note)note.textContent=c?'cut '+fmtS(c[0])+'–'+fmtS(c[1]):''}
document.addEventListener('click',ev=>{const b=ev.target.closest('.cvCutBtn');if(!b)return;ev.preventDefault();ev.stopPropagation();
 const id=b.dataset.cutFor,ch=document.querySelector(".convertCheck[value='"+id+"']"),row=ch&&ch.closest('.convertRow');if(!row)return;
 let pan=document.getElementById('cvCut'+id);if(pan){pan.remove();return}
 const full=Number(ch.dataset.durationMs||0)/1000;
 pan=document.createElement('div');pan.id='cvCut'+id;pan.className='card';pan.style.margin='-4px 0 4px';pan.style.minWidth='0';
 pan.innerHTML="<video controls preload='metadata' style='width:100%;max-height:320px;background:#000;border-radius:8px'></video>"
  +"<div class='small muted cvNoPlay' style='display:none;white-space:normal'></div><div class='small muted cvWhen' style='white-space:normal'></div>"
  +"<div class='toolbar' style='margin-top:6px;flex-wrap:wrap'><button type='button' class='btn2' data-set='s'>Start here</button><input class='cvS' style='width:90px' placeholder='0:00'>"
  +"<button type='button' class='btn2' data-set='e'>End here</button><input class='cvE' style='width:90px'>"
  +"<button type='button' class='btn2' data-set='x'>Whole video</button><button type='button' class='btn2' data-set='f'>Save this picture</button></div>"
  +"<div class='small muted' style='white-space:normal'>Only the part between start and end is converted. Save this picture: a photo of the moment in the player (or at the start), into the folder of converted videos.</div>";
 row.after(pan);const v=pan.querySelector('video'),S=pan.querySelector('.cvS'),E=pan.querySelector('.cvE');v.src='/media/'+id;if(full>0)E.placeholder=fmtT(full);
 v.addEventListener('error',()=>{const n=pan.querySelector('.cvNoPlay');n.style.display='block';n.textContent='This video does not play here - type the start and end (minutes:seconds).';v.style.display='none';pan.querySelectorAll("[data-set='s'],[data-set='e']").forEach(x=>x.style.display='none')});
 const c0=cutOf(ch);if(c0){S.value=fmtT(c0[0]);E.value=fmtT(c0[1])}
 fetch('/api/convert/when?id='+Number(id),{cache:'no-store'}).then(r=>r.json()).then(x=>{if(!x.ok)return;const w=pan.querySelector('.cvWhen'),m=String(x.start).match(/^(\\d{4})-(\\d\\d)-(\\d\\d)T(\\d\\d):(\\d\\d):(\\d\\d)$/);if(!w||!m)return;
  const t0=Date.UTC(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+m[6]),p2=n=>String(n).padStart(2,'0'),f=ms=>{const d=new Date(ms);return p2(d.getUTCDate())+'.'+p2(d.getUTCMonth()+1)+'.'+d.getUTCFullYear()+' '+p2(d.getUTCHours())+':'+p2(d.getUTCMinutes())+':'+p2(d.getUTCSeconds())};
  const who={camera:"the camera's clock",phone:"the phone's time",file:"the file's date"}[x.how]||'';
  w.innerHTML="<span>Filmed:</span> <span translate='no'>"+f(t0)+"</span>"+(who?" (<span>"+who+"</span>)":"")+" · <span>in the player:</span> <span translate='no' class='cvNow'>"+f(t0)+"</span>";
  const upd=()=>{const n=w.querySelector('.cvNow');if(n)n.textContent=f(t0+Math.floor(v.currentTime||0)*1000)};v.addEventListener('timeupdate',upd);v.addEventListener('seeked',upd)}).catch(()=>{});
 function apply(){const a=parseT(S.value),z=parseT(E.value);const s=a===null?0:a,e=z===null?(full>0?full:NaN):(full>0?Math.min(z,full):z);
  if(a===null&&z===null){delete ch.dataset.cutStart;delete ch.dataset.cutEnd}
  else if(Number.isFinite(s)&&Number.isFinite(e)&&e-s>=0.5){ch.dataset.cutStart=String(s);ch.dataset.cutEnd=String(e);if(!ch.checked){ch.checked=true;ch.dispatchEvent(new Event('change'))}}
  else{toast('The start must be at least half a second before the end.');return}
  showCut(ch);updSel()}
 pan.addEventListener('click',e2=>{const t=e2.target.closest('[data-set]');if(!t)return;
  if(t.dataset.set==='f'){const at=(v.style.display!=='none'&&v.readyState>=1)?(v.currentTime||0):(parseT(S.value)||0);t.disabled=true;
   fetch('/api/convert/frame',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:Number(id),t:at,clock:!!(document.getElementById('clockOut')||{}).checked})}).then(r=>r.json())
   .then(x=>{toast(x.ok?'Saved: '+x.name:(x.error||'Could not save'))}).catch(e=>toast(String(e))).finally(()=>{t.disabled=false});return}
  if(t.dataset.set==='s')S.value=fmtT(v.currentTime||0);else if(t.dataset.set==='e')E.value=fmtT(v.currentTime||0);else{S.value='';E.value=''}apply()});
 S.addEventListener('change',apply);E.addEventListener('change',apply)});
async function startConv(){const ids=checks().map(x=>Number(x.value));if(!ids.length){toast('Select at least one video');return}
 const o=convOpts();if(!o.preset){toast('Choose a preset first');return}
 if(o.join&&ids.length<2){toast('Choose at least two videos to join into one');return}
 const cuts={};for(const ch of checks()){const c=cutOf(ch);if(c)cuts[ch.value]=c}if(Object.keys(cuts).length)o.cuts=cuts;
 const b=document.getElementById('startConvert');b.disabled=true;
 try{const r=await fetch('/api/convert/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids,...o})});const x=await r.json();if(!r.ok)throw new Error(x.error||'Could not start');toast(x.card?'The graphics card is tested first (about two minutes), then it starts.':x.waiting?'Added to the line: it starts when the job before it ends.':'Conversion started');setTimeout(()=>{location.href='/convert'},x.waiting?1200:0)}catch(e){toast(e.message||String(e));b.disabled=false}}
document.getElementById('startConvert').onclick=startConv;
document.getElementById('framesStart').onclick=async ev=>{const ids=checks().map(x=>Number(x.value));if(!ids.length){toast('Select at least one video');return}
 const b=ev.currentTarget;b.disabled=true;
 try{const r=await fetch('/api/convert/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids,preset:'share_1080p',extra:{frames:Number(document.getElementById('framesEvery').value),clock:!!(document.getElementById('clockOut')||{}).checked,title:((document.getElementById('framesTitle')||{}).value||'').trim()}})});
  const x=await r.json();if(!r.ok)throw new Error(x.error||'Could not start');toast(x.card?'The graphics card is tested first (about two minutes), then it starts.':x.waiting?'Added to the line: it starts when the job before it ends.':'Saving pictures');setTimeout(()=>{location.href='/convert'},x.waiting?1200:0)}catch(e){toast(e.message||String(e));b.disabled=false}};
document.getElementById('pickConvert').onclick=async ev=>{const o=convOpts();if(!o.preset){toast('Choose a preset first');return}
 const b=ev.currentTarget;b.disabled=true;
 try{const r=await fetch('/api/convert/pick',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});const x=await r.json();
  if(x.job_id){toast(x.card?'The graphics card is tested first (about two minutes), then it starts.':x.waiting?'Added to the line: it starts when the job before it ends.':'Conversion started');setTimeout(()=>{location.href='/convert'},x.waiting?1200:0);return}if(x.error)toast(x.error)}catch(e){toast(e.message||String(e))}b.disabled=false};
const winPC=%s;
function hb(n){n=Number(n||0);for(const u of ['B','KB','MB','GB','TB']){if(n<1024||u==='TB')return (u==='B'||u==='KB'?n.toFixed(0):n.toFixed(1))+' '+u;n/=1024}}
async function pollConvert(){const box=document.getElementById('convertStatus');if(!box||box.dataset.done)return;const id=box.dataset.job;try{const r=await fetch('/api/convert/status?id='+id,{cache:'no-store'});const x=await r.json();if(!x.job)return;const j=x.job;document.getElementById('convertMsg').textContent=j.message||j.status;document.getElementById('convertPct').style.width=(j.percent||0)+'%';const et=document.getElementById('convertEta');if(et){const t=Number(j.eta_s);const v=!(t>=0)||j.eta_s===null?'':(t<60?'less than a minute left':(Math.round(t/60)<60?'about '+Math.max(1,Math.round(t/60))+' min left':'about '+Math.floor(Math.round(t/60)/60)+' h '+(Math.round(t/60)%60)+' min left'));if(et.dataset.v!==v){et.dataset.v=v;et.textContent=v}}if(['finished','failed','cancelled','partial'].includes(j.status)){const st=document.getElementById('convertStop');if(st)st.remove();const et2=document.getElementById('convertEta');if(et2)et2.remove();const outs=((j.options||{}).outputs||[]);let h='';const esc=t=>String(t==null?'':t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let i=-1;for(const o of outs){i++;const nm=String(o.source||'').split(String.fromCharCode(92)).join('/').split('/').pop();if(o.frames&&!o.error){h+="<div class='cv-out'><div class='small'><b><span>"+Number(o.frames)+" pictures</span></b> · <span>every "+Number(o.every||0)+" s</span>"+(o.clock?(o.clock==='file'?" · <span>date and time (from the file's date)</span>":" · <span>date and time</span>"):"")+"<br><span class='muted ae-path' translate='no'>"+esc(o.output)+"</span></div><div class='row' style='margin:4px 0 8px'><button class='btn btn2' type='button' data-cv='open' data-i='"+i+"'>Open the folder</button>"+(o.pdf?"<button class='btn btn2' type='button' data-cv='pdf' data-i='"+i+"'>Open the PDF</button>":"")+"</div></div>";continue}if(o.error){h+="<div class='small error'><span>Failed:</span> <span translate='no'>"+esc(nm)+"</span> — <span>"+esc(o.error)+"</span></div>"}else{h+="<div class='cv-out'><div class='small'><b><span>"+hb(o.source_bytes)+"</span> → <span>"+hb(o.output_bytes)+"</span></b> · "+(Number(o.output_bytes)>Number(o.source_bytes)?"<span>larger than the original</span>":"<span>smaller by "+esc(o.saved_percent)+"%</span>")+(o.joined?" · <span>joined from "+Number(o.joined)+" parts</span>":"")+(o.made_on==='nvidia'?" · <span>made on the graphics card</span>":"")+(o.mute===true?" · <span>without sound</span>":"")+(()=>{const x=o.extra||{};return ([2,4,8].includes(Number(x.speed))?" · <span>"+Number(x.speed)+"× faster</span>":({0.5:" · <span>½× slow motion</span>",0.25:" · <span>¼× slow motion</span>"}[Number(x.speed)]||""))+(x.vertical?" · <span>vertical 9:16</span>":"")+(x.logo?" · <span>logo</span>":"")+(x.wind?" · <span>less wind</span>":"")+(x.loud?" · <span>even sound</span>":"")+(x.bright?" · <span>brighter</span>":"")+(x.clock?(o.clock==='file'?" · <span>date and time (from the file's date)</span>":" · <span>date and time</span>"):"")})()+({90:" · <span>turned right</span>",270:" · <span>turned left</span>",180:" · <span>turned upside down</span>"}[Number(o.turn)]||"")+(Array.isArray(o.cut)?" · <span>cut "+fmtS(o.cut[0])+"–"+fmtS(o.cut[1])+"</span>":"")+(Array.isArray(o.short)?" · <span class='error'>shorter than the video: "+Number(o.short[0])+" of "+Number(o.short[1])+" s</span>":"")+"<br><span class='muted ae-path' translate='no'>"+esc(o.output)+"</span></div><div class='row' style='margin:4px 0 8px'><button class='btn btn2' type='button' data-cv='reveal' data-i='"+i+"'>Show in folder</button><button class='btn btn2' type='button' data-cv='open' data-i='"+i+"'>Open video</button>"+(winPC?"<button class='btn btn2' type='button' data-cv='copy' data-i='"+i+"'>Copy file</button>":"")+"</div></div>"}}h+="<div class='row' style='justify-content:flex-end'><button class='btn btn2' type='button' data-cv='hide'>Remove from the page</button></div>";document.getElementById('convertResults').innerHTML=h;return}}catch(e){}setTimeout(pollConvert,1000)}
document.addEventListener('click',async ev=>{const b=ev.target.closest('[data-cv]');if(!b)return;const box=document.getElementById('convertStatus');
 if(b.dataset.cv==='logo-pick'||b.dataset.cv==='logo-clear'){b.disabled=true;try{const r=await fetch('/api/convert/logo',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:b.dataset.cv==='logo-pick'?'pick':'clear'})});const x=await r.json();if(x.ok){location.reload();return}if(x.error)toast(x.error)}catch(e){}b.disabled=false;return}
 if(b.dataset.cv==='stop'){if(!box)return;b.disabled=true;try{await fetch('/api/jobs/'+Number(box.dataset.job)+'/cancel',{method:'POST'})}catch(e){}return}
 if(b.dataset.cv==='outdir'||b.dataset.cv==='outdir-reset'){b.disabled=true;try{const r=await fetch('/api/convert/output-folder',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reset:b.dataset.cv==='outdir-reset'})});const x=await r.json();if(x.ok){location.reload();return}if(x.error)toast(x.error)}catch(e){}b.disabled=false;return}
 if(b.dataset.cv==='hide'){const jb=b.closest('[data-job-box]'),card=jb||box;try{const r=await fetch('/api/convert/hide',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job:card?Number(jb?jb.dataset.jobBox:card.dataset.job):0})});if(r.ok&&card)card.remove()}catch(e){}return}
 if(b.dataset.cv==='unqueue'){b.disabled=true;try{const r=await fetch('/api/jobs/'+Number(b.dataset.job)+'/cancel',{method:'POST'});const y=await r.json();if(!y.ok){location.reload();return}if(r.ok){const row=b.closest('[data-wait]');if(row)row.remove();const q=document.getElementById('convertQueue');if(q&&!q.querySelector('[data-wait]'))q.remove();return}}catch(e){}b.disabled=false;return}
 try{const r=await fetch(b.dataset.cv==='folder'?'/api/convert/open-folder':'/api/convert/reveal',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({job:b.closest('[data-job-box]')?Number(b.closest('[data-job-box]').dataset.jobBox):(box?Number(box.dataset.job):0),i:Number(b.dataset.i||0),open:b.dataset.cv==='open',copy:b.dataset.cv==='copy',...(b.dataset.cv==='pdf'?{pdf:true}:{})})});const x=await r.json();if(!x.ok&&x.error)toast(x.error);else if(x.ok&&b.dataset.cv==='copy')toast('Copied: paste it with Ctrl+V into a folder, an e-mail or a messenger.')}catch(e){}});
pollConvert();
async function pollQueue(){const q=document.getElementById('convertQueue');if(!q)return;try{const r=await fetch('/api/convert/queue',{cache:'no-store'});const x=await r.json();
 const box=document.getElementById('convertStatus'),shown=box&&!box.dataset.done?Number(box.dataset.job):null;
 if(x.running&&x.running!==shown){
  // the next conversion started: the page shows it - at once, unless videos are being chosen (nothing chosen is lost)
  if(!document.querySelector('.convertCheck:checked')&&!document.querySelector("[id^='cvCut']")){location.reload();return}
  if(!q.querySelector('.cvNext')){const n=document.createElement('div');n.className='row cvNext';n.style.marginTop='6px';n.innerHTML="<span class='small'>The next conversion has started.</span> <button class='btn btn2' type='button' onclick='location.reload()'>Show it</button>";q.prepend(n)}}if(!x.running&&!(x.waiting||[]).length){q.remove();return}}catch(e){}setTimeout(pollQueue,2000)}
pollQueue();""".replace("const winPC=%s;","const winPC="+("true" if os.name=='nt' else "false")+";",1)
        if not preselect_ids and pages>1:
            base={k:v for k,v in request.args.items() if k not in ('page','ids')}
            body+=page_nav(page,pages,base)
        return layout('Convert',body,script)

    @app.post('/api/convert/probe')
    def convert_probe():
        payload=_json_obj()
        return jsonify({'items':{str(k):v for k,v in probe_local_media_meta(payload.get('ids') or []).items()}})

    @app.post('/api/convert/start')
    def convert_start():
        payload=_json_obj()
        try:
            job_id=start_convert_job(payload.get('ids') or [],payload.get('preset') or 'share_1080p',payload.get('target_mb'),
                                     join=payload.get('join') is True,cuts=payload.get('cuts') or None,mute=payload.get('mute') is True,
                                     turn=payload.get('turn') or 0,extra=payload.get('extra') or None)
            return jsonify({'ok':True,'job_id':job_id,'waiting':str((convert_job_snapshot(job_id) or {}).get('status'))=='waiting','card':'graphics card first' in str((convert_job_snapshot(job_id) or {}).get('message') or '')})
        except Exception as exc:
            return jsonify({'ok':False,'error':str(exc)}),409

    @app.post('/api/convert/pick')
    def convert_pick():
        """Videos chosen in the Windows Open window (anywhere on this PC, not added to the library) converted at once
        with the page's preset; their paths never come from the page."""
        payload=_json_obj()
        from . import auto_edit as _ae
        files=_ae.pick_files("Choose videos to convert (Ctrl+click for several)",initial=_ae.last_source_folder())
        if not files:
            return jsonify({'ok':False,'error':'No videos chosen.'})
        try:
            job_id=start_convert_job([],payload.get('preset') or 'share_1080p',payload.get('target_mb'),paths=files,
                                     join=payload.get('join') is True,mute=payload.get('mute') is True,turn=payload.get('turn') or 0,
                                     extra=payload.get('extra') or None)
            return jsonify({'ok':True,'job_id':job_id,'waiting':str((convert_job_snapshot(job_id) or {}).get('status'))=='waiting','card':'graphics card first' in str((convert_job_snapshot(job_id) or {}).get('message') or '')})
        except Exception as exc:
            return jsonify({'ok':False,'error':str(exc)}),409

    def _filmed_txt(r):
        """When a library video was filmed (its header's time, else the file's date), on this PC's clock."""
        try:
            ts=float(r['date_taken'] or r['mtime'] or 0)
            return f" · <span translate='no' title='filmed'>{time.strftime('%d.%m.%Y %H:%M',time.localtime(ts))}</span>" if ts>946684800 else ''
        except Exception:
            return ''

    def _convert_outputs_html(job):
        """The files a converter job made, each with buttons to show it in Explorer or play it (the same markup the
        page's script writes when a running job ends)."""
        outs=((job or {}).get('options') or {}).get('outputs') or []
        copy_btn=("<button class='btn btn2' type='button' data-cv='copy' data-i='{i}'>Copy file</button>"
                  if os.name=='nt' else '')
        h=[]
        for i,o in enumerate(outs):
            if not isinstance(o,dict):
                continue
            if o.get('error'):
                h.append(f"<div class='small error'><span>Failed:</span> <span translate='no'>{e(Path(str(o.get('source') or '')).name)}</span> — <span>{e(o.get('error'))}</span></div>")
            elif o.get('frames') and o.get('output'):
                there=Path(str(o['output'])).is_dir()
                ck=((" · <span>date and time (from the file's date)</span>" if o.get('clock')=='file' else " · <span>date and time</span>")
                    if o.get('clock') else '')
                pdf_btn=(f"<button class='btn btn2' type='button' data-cv='pdf' data-i='{i}'>Open the PDF</button>"
                         if o.get('pdf') and Path(str(o['pdf'])).is_file() else '')
                h.append(f"<div class='cv-out'><div class='small'><b><span>{int(o['frames'])} pictures</span></b> · <span>every {int(o.get('every') or 0)} s</span>{ck}"
                         f"<br><span class='muted ae-path' translate='no'>{e(o.get('output'))}</span></div>"
                         +(f"<div class='row' style='margin:4px 0 8px'><button class='btn btn2' type='button' data-cv='open' data-i='{i}'>Open the folder</button>{pdf_btn}</div></div>"
                           if there else "<div class='small muted' style='margin:2px 0 8px'>The file is no longer there.</div></div>"))
            elif o.get('output'):
                there=Path(str(o['output'])).is_file()
                more=(f" · <span>joined from {int(o.get('joined'))} parts</span>" if str(o.get('joined') or '').isdigit() else '')
                more+=(" · <span>made on the graphics card</span>" if o.get('made_on')=='nvidia' else '')
                more+=(" · <span>without sound</span>" if o.get('mute') is True else '')
                ex=o.get('extra') if isinstance(o.get('extra'),dict) else {}
                more+=(f" · <span>{int(ex['speed'])}× faster</span>" if str(ex.get('speed') or '') in ('2','4','8') else
                       {'0.5':" · <span>½× slow motion</span>",'0.25':" · <span>¼× slow motion</span>"}.get(str(ex.get('speed') or ''),''))
                more+=(" · <span>vertical 9:16</span>" if ex.get('vertical') else '')+(" · <span>logo</span>" if ex.get('logo') else '')
                more+=(" · <span>less wind</span>" if ex.get('wind') else '')+(" · <span>even sound</span>" if ex.get('loud') is True else '')
                more+=(" · <span>brighter</span>" if ex.get('bright') is True else '')
                more+=((" · <span>date and time (from the file's date)</span>" if o.get('clock')=='file' else " · <span>date and time</span>")
                       if ex.get('clock') is True else '')
                more+=({'90':" · <span>turned right</span>",'270':" · <span>turned left</span>",'180':" · <span>turned upside down</span>"}.get(str(o.get('turn') or ''),''))
                def _n(x):
                    try:
                        return float(x or 0)
                    except (TypeError, ValueError):
                        return 0.0
                sv=("<span>larger than the original</span>" if _n(o.get('output_bytes'))>_n(o.get('source_bytes'))
                    else "<span>smaller by "+e(o.get('saved_percent'))+"%</span>")
                if isinstance(o.get('cut'),list) and len(o['cut'])==2:
                    fm=lambda t:f"{int(round(float(t)))//60}:{int(round(float(t)))%60:02d}"
                    more+=f" · <span>cut {fm(o['cut'][0])}–{fm(o['cut'][1])}</span>"
                if isinstance(o.get('short'),list) and len(o['short'])==2:
                    more+=(" · <span class='error' title='The video may be damaged or not fully copied'>shorter than the video: "
                           f"{float(o['short'][0]):g} of {float(o['short'][1]):g} s</span>")
                h.append(f"<div class='cv-out'><div class='small'><b><span>{human_bytes(o.get('source_bytes'))}</span> → <span>{human_bytes(o.get('output_bytes'))}</span></b> · {sv}{more}<br><span class='muted ae-path' translate='no'>{e(o.get('output'))}</span></div>"
                         +(f"<div class='row' style='margin:4px 0 8px'><button class='btn btn2' type='button' data-cv='reveal' data-i='{i}'>Show in folder</button><button class='btn btn2' type='button' data-cv='open' data-i='{i}'>Open video</button>{copy_btn.format(i=i)}</div></div>"
                           if there else "<div class='small muted' style='margin:2px 0 8px'>The file is no longer there.</div></div>"))
        return ''.join(h)

    @app.post('/api/convert/reveal')
    def convert_reveal():
        """A converted file shown in Explorer (or played): found by its job and place in that job, never by a path
        sent from the page."""
        payload=_json_obj()
        try:
            jid,i=int(payload.get('job')),int(payload.get('i'))
        except (TypeError,ValueError):
            return jsonify({'ok':False,'error':'No such file.'}),400
        job=convert_job_snapshot(jid) if jid>0 else None
        outs=((job or {}).get('options') or {}).get('outputs') or []
        if not 0<=i<len(outs) or not outs[i].get('output'):
            return jsonify({'ok':False,'error':'No such file.'}),404
        p=Path(str(outs[i]['output']))
        if payload.get('pdf') is True:              # the pictures' PDF (written by this job into its pictures folder)
            q=Path(str(outs[i].get('pdf') or ''))
            if not (outs[i].get('frames') and outs[i].get('pdf') and q.is_file() and q.parent==p):
                return jsonify({'ok':False,'error':'The file is no longer there.'}),404
            from .auto_edit import open_path
            open_path(q,reveal=False)
            return jsonify({'ok':True})
        if not (p.is_file() or (outs[i].get('frames') and p.is_dir())):
            return jsonify({'ok':False,'error':'The file is no longer there.'}),404
        if payload.get('copy') is True and p.is_file():   # Ctrl+C of the file, as in Explorer
            from .platform_adapter import copy_files_to_clipboard
            if copy_files_to_clipboard([p]):
                return jsonify({'ok':True})
            return jsonify({'ok':False,'error':'The file could not be copied (the clipboard is busy?). Try again.'}),409
        from .auto_edit import open_path
        open_path(p,reveal=payload.get('open') is not True)
        return jsonify({'ok':True})

    @app.post('/api/convert/logo')
    def convert_logo():
        """The logo for converted videos: chosen in the Windows Open window (any picture, kept as a PNG in the data
        folder), its corner and size, or removed."""
        from .converter import LOGO_FILE, LOGO_CORNERS
        payload=_json_obj(); action=payload.get('action'); dst=HOME/'data'/LOGO_FILE
        if action=='clear':
            for _ in range(10):
                try:
                    dst.unlink(missing_ok=True); break
                except OSError:
                    time.sleep(0.2)                  # (Windows: a moment while another reader closes it)
            if dst.exists():
                return jsonify({'ok':False,'error':'The logo is in use - try again in a moment.'}),409
            return jsonify({'ok':True})
        if action=='set':
            corner=payload.get('corner') if payload.get('corner') in LOGO_CORNERS else 'bottom-right'
            try: size=min(40,max(5,int(payload.get('size') or 12)))
            except (TypeError,ValueError): size=12
            update_config(lambda c: c.setdefault('convert',{}).__setitem__('logo',{'corner':corner,'size':size}))
            return jsonify({'ok':True})
        if action!='pick':
            return jsonify({'ok':False,'error':'Unknown option'}),400
        from . import auto_edit as _ae
        files=_ae.pick_files("Choose your logo (a PNG with a transparent background looks best)",kind="image")
        if not files:
            return jsonify({'ok':False,'error':'No picture chosen.'})
        try:
            from PIL import Image, ImageOps
            with Image.open(files[0]) as im0:
                im0.draft('RGB',(2000,2000))
                im=ImageOps.exif_transpose(im0)
                if max(im.size)>2000: im.thumbnail((2000,2000))
                im=im.convert('RGBA')
                dst.parent.mkdir(parents=True,exist_ok=True)
                tmp=dst.with_suffix('.part.png'); im.save(tmp,'PNG'); os.replace(tmp,dst)
        except Exception:
            return jsonify({'ok':False,'error':'This picture cannot be read. Choose a PNG or JPG.'}),400
        return jsonify({'ok':True})

    @app.get('/api/convert/logo.png')
    def convert_logo_png():
        from .converter import LOGO_FILE
        f=HOME/'data'/LOGO_FILE
        if not f.is_file():
            return 'Not found',404
        # the bytes, not the open file: on Windows an open file could not be removed by "Remove the logo"
        return Response(f.read_bytes(),mimetype='image/png',headers={'Cache-Control':'no-store'})

    @app.get('/api/convert/when')
    def convert_when():
        """When a library video was filmed (for "Date and time in the corner"): its first picture's time as the clock
        showed it, and whose clock that is."""
        try:
            iid=int(request.args.get('id',''))
        except (TypeError,ValueError):
            return jsonify({'ok':False}),400
        if not 0<iid<2**62:
            return jsonify({'ok':False}),404
        with db() as con:
            r=con.execute("SELECT * FROM inventory WHERE id=? AND excluded=0 AND media_type='video' AND private_path IS NULL "
                          "AND rejected_path IS NULL AND COALESCE(analysis_status,'')<>'private' "
                          "AND COALESCE(sha256,'') NOT IN (SELECT sha256 FROM ignored_hashes)",(iid,)).fetchone()
        src=next((Path(r[k]) for k in ('staging_path','archive_path','path') if r and r[k] and Path(r[k]).is_file()),None)
        if not src:
            return jsonify({'ok':False}),404
        from .converter import recording_start
        from .media import _ffmpeg_exe
        try:
            when,how=recording_start(_ffmpeg_exe(),src)
        except Exception:
            when,how=None,''
        if not when:
            return jsonify({'ok':False}),404
        return jsonify({'ok':True,'start':when.isoformat(timespec='seconds'),'how':how})

    @app.post('/api/convert/frame')
    def convert_frame():
        """'Save this picture': one frame of a library video at the second shown in the player, as a JPEG in the
        folder of converted videos."""
        payload=_json_obj()
        try:
            iid,t=int(payload.get('id')),float(payload.get('t'))
        except (TypeError,ValueError,OverflowError):
            return jsonify({'ok':False,'error':'That moment is not in the video'}),400
        if not 0<iid<2**62:
            return jsonify({'ok':False,'error':'This video is not on this computer now.'}),404
        with db() as con:
            r=con.execute("SELECT * FROM inventory WHERE id=? AND excluded=0 AND media_type='video' AND private_path IS NULL "
                          "AND rejected_path IS NULL AND COALESCE(analysis_status,'')<>'private' "
                          "AND COALESCE(sha256,'') NOT IN (SELECT sha256 FROM ignored_hashes)",(iid,)).fetchone()
        src=next((Path(r[k]) for k in ('staging_path','archive_path','path') if r and r[k] and Path(r[k]).is_file()),None)
        if not src:
            return jsonify({'ok':False,'error':'This video is not on this computer now.'}),404
        from .converter import save_frame
        try:
            out=save_frame(src,t,clock=payload.get('clock') is True)
        except ValueError as exc:
            return jsonify({'ok':False,'error':str(exc)}),400
        except Exception as exc:
            return jsonify({'ok':False,'error':str(exc)[:300]}),409
        return jsonify({'ok':True,'name':out.name})

    @app.post('/api/convert/hide')
    def convert_hide():
        """A finished job's list off the Convert page (its files stay in Converted); a newer job shows again."""
        try:
            jid=int(_json_obj().get('job'))
        except (TypeError,ValueError):
            return jsonify({'ok':False,'error':'No such file.'}),400
        job=convert_job_snapshot(jid) if jid>0 else None
        if not job or str(job.get('status') or '') not in ('finished','failed','cancelled','partial'):
            return jsonify({'ok':False,'error':'No such file.'}),404
        def hide(c):
            ids=[int(x) for x in (c.get('convert_hidden_jobs') or []) if str(x).isdigit()]
            c['convert_hidden_jobs']=(ids+[jid])[-200:]
        update_config(hide)
        return jsonify({'ok':True})

    @app.post('/api/convert/output-folder')
    def convert_output_folder():
        """The folder converted videos go into: chosen in the Windows folder window (never a path from the page), or
        back to Converted in the data folder. Not inside a library folder (the copies would be found as new videos)
        nor in the program's own folder (replaced by updates); it must take a file."""
        from .converter import output_folder
        if _json_obj().get('reset') is True:
            update_config(lambda c: (c.setdefault('convert',{}).pop('output_dir',None),None)[1])
            return jsonify({'ok':True,'path':str(HOME/'Converted')})
        from . import auto_edit as _ae
        chosen=_ae.pick_folder("Choose a folder for converted videos",initial=str(output_folder()))
        if not chosen:
            return jsonify({'ok':False,'error':'No folder chosen.'})
        d=Path(chosen).resolve()
        def inside(a,b):
            try:
                a.relative_to(b);return True
            except ValueError:
                return False
        from .service import configured_sources
        for src in configured_sources(load_config()):
            raw=os.path.expanduser(os.path.expandvars(str((src or {}).get('path') or '').strip()))
            if raw and inside(d,Path(raw).resolve()):
                if src.get('kind')=='removable':
                    return jsonify({'ok':False,'error':'This is a memory card or USB stick: MediaEngine never writes to cards. Choose a folder on the computer.'})
                return jsonify({'ok':False,'error':'This folder is in the library: converted copies would be found as new videos. Choose another folder.'})
        inst,home=Path(INSTALL).resolve(),Path(HOME).resolve()
        if inside(d,inst) and not inside(d,home):
            return jsonify({'ok':False,'error':'This is the program folder (updates replace it). Choose another folder.'})
        try:
            d.mkdir(parents=True,exist_ok=True)
            probe=d/f".mediaengine-write-test-{os.getpid()}"
            probe.write_bytes(b"")
            probe.unlink()
        except OSError:
            return jsonify({'ok':False,'error':'MediaEngine cannot write into this folder. Choose another folder.'})
        update_config(lambda c: c.setdefault('convert',{}).__setitem__('output_dir',str(d)))
        return jsonify({'ok':True,'path':str(d)})

    @app.post('/api/convert/open-folder')
    def convert_open_folder():
        from .converter import output_folder
        d=output_folder()
        try:
            d.mkdir(parents=True,exist_ok=True)
        except OSError:
            return jsonify({'ok':False,'error':'The folder is not there now (a disk not connected?).'}),404
        from .auto_edit import open_path
        open_path(d)
        return jsonify({'ok':True})

    @app.get('/api/convert/queue')
    def convert_queue():
        """The conversion running now and those waiting in line (the page reloads when the next one starts)."""
        with db() as con:
            r=con.execute("SELECT id FROM jobs WHERE kind='convert' AND status IN ('running','queued') ORDER BY id DESC LIMIT 1").fetchone()
            w=con.execute("SELECT id FROM jobs WHERE kind='convert' AND status='waiting' AND cancel_requested=0 ORDER BY id").fetchall()
        return jsonify({'running':int(r['id']) if r else None,'waiting':[int(x['id']) for x in w]})

    @app.get('/api/convert/status')
    def convert_status():
        raw=request.args.get('id','').strip()
        one=_id_list(raw,1)
        job=convert_job_snapshot(one[0]) if one else convert_job_snapshot()
        return jsonify({'job':job})


    @app.get('/library')
    def library():
        return gallery('library')

    def _aiplus_search_card():
        """Library: search the videos by a theme with the AI+ model, and 'Prepare AI+ for the whole Library' (the search
        and what AI+ reels need, ahead of time - it can run overnight). Only when AI+ is installed."""
        try:
            from . import aiplus_library as al, auto_edit as _ae
            st=al.status()
        except Exception:
            return ""
        if not st["model_ready"]:
            return ""
        opts="".join(f"<option value='{k}'>{e(v)}</option>" for k,v in _ae.THEMES.items())
        missing=al.needs_preparing(st)
        running=st["state"]=="running"
        failed=(f"<div class='errbox' style='margin-top:8px'>{e(st['error'])}</div>") if st["state"]=="failed" and st.get("error") else ""
        if missing or running:
            prep=failed+(f"<div class='row' style='margin-top:8px'><span class='muted'>Search ready for {st['indexed']} of {st['videos']} video(s).</span> "
                  f"<span class='muted'>Reels ready for {st['reels_ready']} of {st['reels_videos']} video(s).</span> "
                  f"<button type='button' class='btn2' id='apIdx' {'disabled' if running else ''}>Prepare AI+ for the whole Library</button>"
                  f"<button type='button' class='btn2' id='apStop' style='{'' if running else 'display:none'}'>Stop preparing</button>"
                  f"<span class='muted' id='apIdxMsg'></span></div>"
                  "<div class='muted small' style='margin-top:6px;white-space:normal'>The computer looks at every video once: it can run overnight, "
                  "waits while a reel is being built and continues where it stopped. After that every search is instant and AI+ reels are built much faster.</div>")
        elif st["videos"]:
            prep="<div class='muted small' style='margin-top:6px'>AI+ is prepared for the whole Library.</div>"
        else:
            prep=""
        return (f"<div class='card' style='margin-bottom:12px'><form method='get' action='/library/theme' class='row'>"
                f"<b>Find by theme (AI+)</b><select name='theme'>{opts}</select><button>Find</button></form>{prep}"
                + "<script>(function(){const b=document.getElementById('apIdx');if(!b)return;const m=document.getElementById('apIdxMsg');const s=document.getElementById('apStop');"
                  "function left(t){if(!t)return'';return t>5400?' · about '+Math.round(t/3600)+' h left':' · about '+Math.max(1,Math.round(t/60))+' min left'}"
                  "async function poll(){try{const r=await fetch('/api/aiplus/library-index',{cache:'no-store'});const x=await r.json();"
                  "if(x.state==='running'){b.disabled=true;s.style.display='';m.textContent=' '+(x.phase==='reels'?'For reels: ':'Search: ')+x.done+' / '+x.total"
                  "+(x.waiting?' · waiting until the reel is built':'')+(x.waiting?'':left(x.eta_s));setTimeout(poll,1500)}"
                  "else{b.disabled=false;s.style.display='none';m.textContent=x.error||'';if(x.state==='done')location.href='/library?aiplus='+Date.now()}}catch(e){setTimeout(poll,3000)}}"
                  "b.onclick=async()=>{b.disabled=true;const r=await fetch('/api/aiplus/library-index',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});"
                  "const x=await r.json();if(!x.ok){m.textContent=x.error||'';b.disabled=false;return}poll()};"
                  "s.onclick=async()=>{s.disabled=true;await fetch('/api/aiplus/library-index',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({stop:true})});s.disabled=false};"
                  + ("poll();" if running else "") + "})();</script></div>")

    @app.get('/library/theme')
    def library_theme():
        from . import aiplus_library as al, auto_edit as _ae
        theme=request.args.get('theme','')
        name=_ae.THEMES.get(theme)
        if not name:                      # no theme chosen: every theme as a button
            chips="".join(f"<a class='btn btn2' style='margin:0 8px 8px 0' href='/library/theme?theme={k}'>{e(v)}</a>" for k,v in _ae.THEMES.items())
            return layout('Find by theme',f"<div class='pagehead row space'><div><div class='eyebrow'>Library · AI+</div><h1>Find by theme</h1>"
                          f"<div class='lead'>Choose a theme.</div></div><a class='btn btn2' href='/library'>Back</a></div><div class='card' style='display:flex;flex-wrap:wrap'>{chips}</div>")
        try:
            st=al.status()
            if not st['model_ready']:
                raise ValueError("The AI+ model is not on this computer yet. Download it once on 'Check this PC'.")
            res=al.search(theme)
        except Exception as exc:
            return layout('Find by theme',f"<div class='card'><div class='errbox'>{e(str(exc)[:300])}</div><a class='btn btn2' href='/library'>Back</a> "
                          f"<a class='btn btn2' href='/auto/check#aiplus'>Check this PC</a></div>"),400
        good=[r for r in res if r['score']>0]
        SHOW=150
        def pic(r):                       # the preview frame of the best moment (the cover if the previews are being redone)
            iid=r['inventory_id']
            return f"/storyboard/{iid}/{r['frame']}" if cached_storyboard(iid) else f"/thumb/{iid}"
        cards="".join(f"<a class='media-card' href='/item/{r['inventory_id']}?t={r['best_s']:.1f}'><div class='thumb'><img loading='lazy' src='{pic(r)}' onerror=\"this.onerror=null;this.src='/thumb/{r['inventory_id']}'\"></div>"
                      f"<div class='meta'><div class='name' translate='no'>{e(r['filename'])}</div><div class='small'><span>best moment</span> "
                      f"{int(r['best_s']//60)}:{int(r['best_s']%60):02d}</div></div></a>" for r in good[:SHOW])
        if len(good)>SHOW:                # a big Library: the best ones (the page stays quick)
            cards+=f"<div class='muted' style='grid-column:1/-1;padding:8px'>The best {SHOW} of {len(good)} are shown.</div>"
        if st['indexed']<st['videos']:
            note=(f"<div class='callout card' style='margin-bottom:12px'><span>Only {st['indexed']} of {st['videos']} video(s) are prepared for the search.</span> "
                  f"<a href='/library'>Prepare the rest</a> <span>on the Library page.</span></div>")
        elif al.search_needs_preparing(st):
            note=("<div class='callout card' style='margin-bottom:12px'><span>The search needs preparing again (new themes).</span> "
                  "<a href='/library'>Prepare the rest</a> <span>on the Library page.</span></div>")
        else:
            note=""
        # a reel about this theme from the matching videos: the new-reel page picks them (no paths in the address)
        reel=(f"<a class='btn' href='/auto/new?library_theme={e(theme)}'>Make a reel about this theme</a>") if good else ""
        body=(f"<div class='pagehead row space'><div><div class='eyebrow'>Library · AI+</div><h1>{e(name)}</h1>"
              f"<div class='lead'>{len(good)} video(s) match the theme, best first. Open one to start at its best moment.</div></div>"
              f"<div class='row'>{reel}<a class='btn btn2' href='/library'>Back</a></div></div>{note}"
              + (f"<div class='grid'>{cards}</div>" if good else "<div class='empty'>No video matches this theme.</div>"))
        return layout('Find by theme',body)

    @app.route('/api/aiplus/library-index',methods=['GET','POST'])
    def aiplus_library_index():
        from . import aiplus_library as al
        if request.method=='POST':
            if _json_obj().get('stop'):
                al.stop(); return jsonify({'ok':True})
            try:
                al.start()
            except Exception as exc:
                return jsonify({'ok':False,'error':str(exc)})
            return jsonify({'ok':True})
        return jsonify(al.status())

    @app.post('/api/selection-action')
    def selection_action():
        p=_json_obj(); action=p.get('action'); raw_ids=p.get('ids',[])
        if not isinstance(raw_ids,list): return jsonify({'error':'No files selected'}),400      # "12" is not [1,2]
        ids=[int(x) for x in raw_ids if (isinstance(x,int) and not isinstance(x,bool) and 0<x<2**63)
             or (isinstance(x,str) and x.isascii() and x.isdigit() and 0<int(x)<2**63)]
        if not ids: return jsonify({'error':'No files selected'}),400
        try:
            if action=='import': return jsonify({'job_id':queue_job('import',ids,{'analyze':False})})
            if action=='import_analyze': return jsonify({'job_id':queue_job('import_analyze',ids,{'analyze':True})})
            if action=='analyze': return jsonify({'job_id':queue_job('analyze',ids)})
            if action=='media_brain': return jsonify({'job_id':queue_job('media_brain',ids,{'preset':str(p.get('preset') or 'general')})})
            if action=='archive': return jsonify({'job_id':queue_job('archive',ids)})
            if action=='private': return jsonify({'job_id':queue_job('private',ids)})
            if action=='reject': return jsonify({'job_id':queue_job('reject',ids)})
            if action=='remove':
                rr=remove_from_library(ids)
                msg=f"Removed {rr['removed']} item(s) from Library"
                if rr['staging_deleted']: msg+=f"; moved {rr['staging_deleted']} Staging copy/copies to Rejected/Removed from Library"
                if rr['errors']: msg+=f"; {len(rr['errors'])} failed"
                return jsonify({'message':msg,'removed':rr['removed'],'staging_deleted':rr['staging_deleted'],'errors':rr['errors']})
            if action=='rights':
                n=set_rights(ids,str(p.get('preset') or ''),str(p.get('notes') or '')); return jsonify({'message':f'Rights updated for {n} item(s)'})
            if action=='exclude': set_excluded(ids,True); return jsonify({'message':'Excluded'})
            return jsonify({'error':'Unknown action'}),400
        except ValueError as exc: return jsonify({'error':str(exc)}),400     # what the user asked for cannot be done
        except Exception as exc: return jsonify({'error':str(exc)}),500

    @app.get('/api/items')
    def items_api():
        ids=_id_list(request.args.get('ids',''),200)
        if not ids:return jsonify({})
        with db() as con: rows=con.execute(f"SELECT id,analysis_status,import_status,source_kind,staging_path,archive_path,private_path,quality_status,quality_score,rights_status,rights_audio_present,error,import_error FROM inventory WHERE id IN ({','.join('?' for _ in ids)})",ids).fetchall()
        out={}
        for r in rows:
            imp='archived' if r['archive_path'] else ('private' if r['private_path'] else ('imported' if r['staging_path'] else ('local' if r['source_kind']=='fixed' else r['import_status'])))
            out[str(r['id'])]={'analysis_status':r['analysis_status'],'import_state':imp,'quality_status':r['quality_status'],'quality_score':r['quality_score'],'rights_status':r['rights_status'],'rights_audio_present':r['rights_audio_present'],'error':r['import_error'] or r['error']}
        return jsonify(out)

    @app.get('/api/thumb-status')
    def thumb_status():
        ids=_id_list(request.args.get('ids',''),200)
        if not ids:return jsonify({'ready':[],'ready_count':0,'pending_count':0,'unavailable_count':0,'generation':int(time.time())})
        with db() as con:
            rows=con.execute(f"SELECT id,preview_status,preview_path FROM inventory WHERE excluded=0 AND id IN ({','.join('?' for _ in ids)})",ids).fetchall()
        ready=[]; unavailable=[]
        for r in rows:
            p=Path(r['preview_path']) if r['preview_path'] else THUMBS / f"{int(r['id'])}.jpg"
            if p.exists(): ready.append(int(r['id']))
            elif r['preview_status']=='unavailable': unavailable.append(int(r['id']))
        ready_set=set(ready); unavailable_set=set(unavailable)
        pending=[i for i in ids if i not in ready_set and i not in unavailable_set]
        return jsonify({'ready':ready,'unavailable':unavailable,'ready_count':len(ready),'unavailable_count':len(unavailable),'pending_count':len(pending),'generation':int(time.time())})

    @app.get('/api/storyboard-status')
    def storyboard_status():
        ids=_id_list(request.args.get('ids',''),200)
        out={}; pending=0
        if not ids:return jsonify({'items':{},'pending_count':0})
        with db() as con:
            rows=con.execute(f"SELECT id,media_type,source_kind,path,staging_path,archive_path,private_path,rejected_path,storyboard_status,storyboard_frames,storyboard_best_index FROM inventory WHERE excluded=0 AND id IN ({','.join('?' for _ in ids)})",ids).fetchall()
        for r in rows:
            if r['media_type']!='video':continue
            info=cached_storyboard(int(r['id']))
            if info:
                out[str(r['id'])]={'ready':True,'count':len(info['frames']),'best_index':int(info.get('best_index') or 0),'times':[f['time'] for f in info['frames']]}
            else:
                local=bool((r['staging_path'] and Path(r['staging_path']).exists()) or (r['archive_path'] and Path(r['archive_path']).exists()) or (r['private_path'] and Path(r['private_path']).exists()) or (r['rejected_path'] and Path(r['rejected_path']).exists()) or (r['source_kind']=='fixed' and r['path'] and Path(r['path']).exists()))
                out[str(r['id'])]={'ready':False,'count':0,'local':local,'status':r['storyboard_status'] or 'pending'}
                if local and r['storyboard_status']!='unavailable':pending+=1
        return jsonify({'items':out,'pending_count':pending,'generation':int(time.time())})

    @app.post('/api/storyboard/<int:inv_id>/queue')
    def storyboard_queue(inv_id):
        queue_storyboard(inv_id,priority=-20)
        return jsonify({'ok':True})

    @app.get('/storyboard/<int:inv_id>/<int:index>')
    def storyboard_frame(inv_id,index):
        info=cached_storyboard(inv_id)
        if not info:
            queue_storyboard(inv_id,priority=-20)
            return Response(placeholder_svg('video'),mimetype='image/svg+xml')
        frames=info.get('frames') or []
        if index<0 or index>=len(frames):return Response(placeholder_svg('video'),mimetype='image/svg+xml'),404
        return send_file(frames[index]['path'],mimetype='image/jpeg',conditional=True)


    @app.get('/clip-preview/<int:clip_id>')
    def clip_preview(clip_id):
        c=clip_by_id(clip_id)
        if c:      # a moment of a Private, rejected or removed video is not shown (as its thumbnail is not)
            with db() as con:
                ok=con.execute("SELECT 1 FROM inventory WHERE id=? AND excluded=0 AND private_path IS NULL AND rejected_path IS NULL "
                               "AND COALESCE(analysis_status,'')<>'private' AND COALESCE(sha256,'') NOT IN (SELECT sha256 FROM ignored_hashes)",
                               (int(c['inventory_id']),)).fetchone()
            if not ok:
                return Response(placeholder_svg('video'),mimetype='image/svg+xml'),404
        if c and c.get('preview_path') and Path(c['preview_path']).exists():
            return send_file(c['preview_path'],mimetype='image/jpeg',conditional=True)
        if c:
            return redirect(f"/thumb/{c['inventory_id']}")
        return Response(placeholder_svg('video'),mimetype='image/svg+xml'),404

    @app.get('/thumb/<int:inv_id>')
    def thumb(inv_id):
        p=cached_thumbnail(inv_id)
        if p:return send_file(p,mimetype='image/jpeg',conditional=True)
        queue_thumbnail(inv_id, priority=-10)
        with db() as con:r=con.execute('SELECT media_type FROM inventory WHERE id=?',(inv_id,)).fetchone()
        return Response(placeholder_svg(r['media_type'] if r else 'video'),mimetype='image/svg+xml')


    @app.get('/api/similar/<int:inv_id>')
    def similar_api(inv_id):
        try:
            lim=max(1,min(100,int(request.args.get('limit','24') or 24)))
        except Exception: lim=24
        return jsonify(find_similar(inv_id,lim))

    @app.get('/similar/<int:inv_id>')
    def similar_page(inv_id):
        with db() as con:
            src=con.execute('SELECT id,filename FROM inventory WHERE id=?',(inv_id,)).fetchone()
        if not src:return 'Not found',404
        data=find_similar(inv_id,48); rows=data.get('results') or []
        body=f"<div class='pagehead'><div class='eyebrow'>Local visual similarity</div><h1>Find Similar</h1><div class='lead'>Perceptual comparison uses cached local thumbnails only. Nothing is uploaded.</div></div><div class='card row space'><div><b>Reference</b><div class='muted' translate='no'>{e(src['filename'])}</div></div><img src='/thumb/{inv_id}' style='width:132px;height:84px;object-fit:cover;border-radius:9px'></div><div class='grid'>"
        for r in rows:
            iid=int(r['inventory_id']); sc=round(100*float(r.get('visual_score') or 0))
            body+=f"<a class='media-card' href='/item/{iid}'><div class='thumb'><img loading='lazy' src='/thumb/{iid}'></div><div class='meta'><div class='row space'><b translate='no'>{e(r.get('filename') or '')}</b><span class='badge ready'>{sc}% similar</span></div><div class='muted' translate='no'>{e(r.get('source_label') or '')}</div></div></a>"
        body+="</div>"
        return layout('Find Similar',body)

    @app.get('/item/<int:inv_id>')
    def item(inv_id):
        with db() as con:r=con.execute('SELECT * FROM inventory WHERE id=?',(inv_id,)).fetchone()
        if not r:return 'Not found',404
        local=next((r[k] for k in ('staging_path','archive_path','private_path','rejected_path','path') if r[k] and Path(r[k]).exists()),None)
        preview=f"<img src='/thumb/{inv_id}'>"
        story_html=''
        brain_html=''
        if local and r['media_type']=='video':
            preview=f"<video id='mainVideo' controls preload='metadata' poster='/thumb/{inv_id}' src='/media/{inv_id}'></video>"
            queue_storyboard(inv_id,priority=-10)
            info=cached_storyboard(inv_id)
            if info:
                story_html="<div id='storyboardMount' class='storystrip' data-ready='1'>"+''.join(f"<div class='storyframe' data-time='{f['time']}'><img src='/storyboard/{inv_id}/{f['index']}'><span class='storytime'>{int(f['time']//60)}:{int(f['time']%60):02d}</span></div>" for f in info['frames'])+"</div>"
            else:
                story_html=f"<div id='storyboardMount' class='card' data-ready='0' style='margin-top:12px'><b>8 preview frames</b><div class='muted small'>Generating locally… They will appear here automatically; no reload and no Explorer needed.</div></div>"
            clips=clips_for_inventory(inv_id)
            brain_html="<div class='card' style='margin-top:12px'><div class='row space'><div><div class='eyebrow'>Media Brain</div><b>Virtual clips + Smart Crop</b></div><form method='post' action='/item/%d/media-brain' class='row'><select name='preset'><option value='general'>General</option><option value='car'>Car / dashboard</option></select><button class='btn2'>%s</button></form></div>" % (inv_id, "Rebuild" if clips else "Build")
            if clips:
                brain_html+="<div class='muted' style='margin:8px 0'>%d virtual clips. Use Open clip to play only that interval and preview its Smart Crop.</div><div class='storystrip'>" % len(clips)
                for c in clips:
                    st=c['start_ms']/1000.0; en=c['end_ms']/1000.0
                    crop=", ".join(x['aspect'] for x in c.get('crops',[]))
                    brain_html+=f"<div class='storyframe' id='clip-{c['id']}' data-time='{st}' style='min-width:150px'><img src='/clip-preview/{c['id']}'><span class='storytime'>{int(st//60)}:{int(st%60):02d}–{int(en//60)}:{int(en%60):02d}</span><div class='small' style='padding:5px'><b>{e(c['label'])} {e(c['score'])}</b><br>{e(crop)}<br><a class='btn btn2 openLink' style='margin-top:5px;padding:3px 7px;font-size:11px' href='/clip/{c['id']}?back=item'>Open clip</a></div></div>"
                brain_html+="</div>"
            else:
                brain_html+="<div class='muted' style='margin-top:8px'>Build scene/window clips, rank Best Moments and calculate static 16:9 / 4:5 / 1:1 / 9:16 crop suggestions.</div>"
            brain_html+="</div>"
            story_html+=brain_html
        body=f"<div class='details'><div><div class='preview'>{preview}</div>{story_html}</div><div class='card'><div class='row space'><h2 translate='no'>{e(r['filename'])}</h2><a class='btn btn2' href='/similar/{inv_id}'>Find similar</a></div><div class='kv'>"
        vals=[('Source',r['source_label']),('Type',r['media_type']),('Size',human_bytes(r['size_bytes'])),('Duration',human_duration(r['duration_ms'])),('Import',('in Library (the file stays in its folder)' if (r['import_status']=='not_imported' and r['work_selected'] and r['source_kind']=='fixed') else r['import_status'])),('Staging',r['staging_path'] or '—'),('Privacy',r['analysis_status']),('Privacy reason',r['privacy_reason'] or '—'),('Quality',f"{r['quality_status']} {r['quality_score'] if r['quality_score'] is not None else ''}"),('Quality reason',r['quality_reason'] or '—'),('SHA-256',r['sha256'] or '—'),('Archive copy',r['archive_path'] or '—'),('Rejected',r['rejected_path'] or '—'),('Rights',r['rights_status'] or 'unknown'),('Rights place',r['rights_place'] or '—'),('Rights reason',r['rights_reason'] or '—'),('Audio present','yes' if r['rights_audio_present'] else 'no'),('Rights source',r['rights_source_url'] or '—'),('Rights notes',r['rights_notes'] or '—'),('Error',r['import_error'] or r['error'] or '—')]
        keep={'Source','Staging','SHA-256','Archive copy','Rejected','Rights place','Rights source','Rights notes'}   # names, paths, hashes: never translated
        no_tr=" translate='no'"
        for k,v in vals:body+=f"<div>{e(k)}</div><div{no_tr if k in keep else ''}>{e(v)}</div>"
        if local:   # the file itself: watch it in the usual player, find it in Explorer, make a reel from it
            body+=(f"</div><div class='toolbar'><form method='post' action='/item/{inv_id}/open'><button class='btn2'>Open in player</button></form>"
                   f"<form method='post' action='/item/{inv_id}/reveal'><button class='btn2'>Show in folder</button></form>"
                   + (f"<a class='btn' href='/auto/new?file={urllib.parse.quote(str(local))}'>Make a reel from this video</a>" if r['media_type']=='video' else ""))
        body+=f"</div><div class='toolbar'><form method='post' action='/item/{inv_id}/remove' onsubmit=\"return confirm('Remove this item from Library? Its imported Staging copy moves to the Rejected / Removed from Library folder (delete it there when you are sure); the source original stays untouched.')\"><button class='danger'>Remove from Library</button></form></div><hr style='border-color:#303842;margin:18px 0'><h3>Rights / location risk</h3><div class='muted'>Triage only — not a legal determination. Manual tags are never overwritten by automatic analysis.</div><form method='post' action='/item/%d/rights' class='toolbar'><select name='status'><option value='unknown'>Unknown</option><option value='review'>Review</option><option value='permission'>Permission needed</option><option value='cleared'>Cleared</option><option value='blocked'>Do not publish</option></select><input name='place' placeholder='Place / venue' value='%s'><input name='source_url' placeholder='Policy/source URL' value='%s'><input name='notes' placeholder='Notes' value='%s'><button>Save rights status</button></form></div></div>" % (inv_id,e(r['rights_place'] or ''),e(r['rights_source_url'] or ''),e(r['rights_notes'] or ''));return layout(r['filename'],body,f"""(function(){{const t=new URLSearchParams(location.search).get('t'),v=document.getElementById('mainVideo');if(t&&v){{v.addEventListener('loadedmetadata',()=>{{v.currentTime=Number(t)||0}},{{once:true}})}}}})();
function bindStoryFrames(){{document.querySelectorAll('#storyboardMount .storyframe').forEach(x=>x.onclick=()=>{{const v=document.getElementById('mainVideo');if(v){{v.currentTime=Number(x.dataset.time||0);v.play().catch(()=>{{}})}}}})}}
function fmtTime(t){{t=Math.max(0,Number(t||0));return Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0')}}
async function loadStoryboard(){{const m=document.getElementById('storyboardMount');if(!m||m.dataset.ready==='1'){{bindStoryFrames();return}};try{{const r=await fetch('/api/storyboard-status?ids={inv_id}',{{cache:'no-store'}}),x=await r.json(),it=(x.items||{{}})['{inv_id}'];if(it&&it.ready&&it.count){{let h="<div id='storyboardMount' class='storystrip' data-ready='1'>";for(let i=0;i<it.count;i++){{const t=(it.times||[])[i]||0;h+="<div class='storyframe' data-time='"+t+"'><img src='/storyboard/{inv_id}/"+i+"?g="+(x.generation||0)+"'><span class='storytime'>"+fmtTime(t)+"</span></div>"}}h+='</div>';m.outerHTML=h;bindStoryFrames();return}}if(it&&it.status==='unavailable'){{m.innerHTML="<b>8 preview frames</b><div class='muted small'>Preview generation is temporarily unavailable for this file. MediaEngine will retry later.</div>";return}}await fetch('/api/storyboard/{inv_id}/queue',{{method:'POST'}})}}catch(e){{}}setTimeout(loadStoryboard,1200)}}
bindStoryFrames();loadStoryboard();""")


    @app.post('/item/<int:inv_id>/media-brain')
    def item_media_brain(inv_id):
        preset='car' if request.form.get('preset')=='car' else 'general'
        try:
            jid=queue_job('media_brain',[inv_id],{'preset':preset})
            return redirect(f'/jobs/{jid}')
        except Exception as exc:
            return f'Media Brain failed: {e(exc)}',400

    @app.get('/auto/from-library')
    def auto_from_library():
        """The videos selected in the Library -> the new-reel page with exactly them (the files where they are now)."""
        if request.headers.get('Sec-Fetch-Site','') not in ('same-origin','none',''):
            return 'This page can only be opened from MediaEngine itself.',403
        ids=_id_list(request.args.get('ids'),2000)
        files=[]
        if ids:
            with db() as con:
                rows=con.execute(f"SELECT * FROM inventory WHERE id IN ({','.join('?' for _ in ids)}) AND media_type='video' AND excluded=0 "
                                 "AND work_selected=1 AND analysis_status<>'private' AND private_path IS NULL AND rejected_path IS NULL "
                                 "AND COALESCE(sha256,'') NOT IN (SELECT sha256 FROM ignored_hashes) ORDER BY COALESCE(date_taken,mtime,0)",ids).fetchall()
            for r in rows:
                local=next((r[k] for k in ('staging_path','archive_path','path') if r[k] and Path(r[k]).is_file()),None)
                if local: files.append(str(local))
        from .auto_edit import MAX_INPUTS
        if not files:
            return layout('Auto Edit',"<div class='errbox'>No selected video is on this PC now (photos are not used in reels).</div>"
                          "<div style='margin-top:12px'><a class='btn btn2' href='/library'>Back</a></div>"),400
        if len(files)>MAX_INPUTS:
            return layout('Auto Edit',f"<div class='errbox'><span>One reel can use up to {MAX_INPUTS} videos. Selected:</span> {len(files)}</div>"
                          "<div style='margin-top:12px'><a class='btn btn2' href='/library'>Back</a></div>"),400
        return redirect('/auto/new?'+urllib.parse.urlencode([('file',x) for x in files]))

    @app.post('/item/<int:inv_id>/open',defaults={'action':'open'})
    @app.post('/item/<int:inv_id>/reveal',defaults={'action':'reveal'})
    def item_open(inv_id,action):
        if request.headers.get('Sec-Fetch-Site','') not in ('same-origin','none',''):
            return 'This page can only be used from MediaEngine itself.',403
        with db() as con:r=con.execute('SELECT staging_path,archive_path,private_path,rejected_path,path FROM inventory WHERE id=?',(inv_id,)).fetchone()
        local=next((r[k] for k in ('staging_path','archive_path','private_path','rejected_path','path') if r and r[k] and Path(r[k]).exists()),None)
        from .auto_edit import open_path
        if not local or not open_path(Path(local),reveal=(action=='reveal')):
            return layout('Not available',"<div class='errbox'>The file is not available on this PC now (disk not connected?).</div>"
                          f"<div style='margin-top:12px'><a class='btn btn2' href='/item/{inv_id}'>Back</a></div>"),404
        return redirect(f'/item/{inv_id}')

    @app.post('/item/<int:inv_id>/remove')
    def item_remove(inv_id):
        rr=remove_from_library([inv_id])
        if not rr['removed']:
            detail='; '.join(rr['errors']) if rr['errors'] else 'Not found or already removed'
            return e(detail),400 if rr['errors'] else 404
        return redirect('/library')

    @app.post('/item/<int:inv_id>/rights')
    def item_rights(inv_id):
        try:
            set_rights_custom(inv_id, request.form.get('status','unknown'), request.form.get('place','').strip(), request.form.get('notes','').strip(), request.form.get('source_url','').strip())
        except Exception as exc:
            return f'Rights update failed: {e(exc)}',400
        return redirect(f'/item/{inv_id}')

    @app.get('/media/<int:inv_id>')
    def media(inv_id):
        with db() as con:r=con.execute('SELECT staging_path,archive_path,private_path,rejected_path,path FROM inventory WHERE id=?',(inv_id,)).fetchone()
        if not r:return 'Not found',404
        for k in ('staging_path','archive_path','private_path','rejected_path','path'):
            if r[k] and Path(r[k]).exists():return send_file(r[k],conditional=True)
        return 'Not local',404

    @app.get('/jobs')
    def jobs():
        js=latest_jobs(30)
        active_any=any(j['status'] in ('queued','running','waiting') for j in js)
        body="<div class='row space'><div><h1 style='margin:0'>Jobs</h1><div class='muted'>Live queue. Running jobs refresh automatically; completed jobs keep their actual start, finish and elapsed time.</div></div></div><div class='jobs'>"
        for j in js:
            pct=round(100*j['done']/j['total']) if j['total'] else 0
            progress=f"{j['done']}/{j['total']}"
            if j['kind']=='media_brain' and j['status'] in ('queued','running'):
                mm=re.search(r'clip\s+(\d+)/(\d+)',j['message'] or '',re.I)
                if mm:
                    n,total=int(mm.group(1)),max(1,int(mm.group(2)))
                    pct=min(99,round(100*n/total));progress=f"clip {n}/{total}"
                elif 'scene scan' in (j['message'] or ''):
                    pct=2;progress='scene scan'
            elapsed=_job_elapsed(j)
            started=j.get('started_at') or j.get('created_at') or ''
            finished=j.get('finished_at') or ''
            timing=(f"Started <span data-local-ts='{e(started)}'>{e(started)}</span>" if j.get('started_at') or j['status']!='waiting'
                    else "<span>Waiting in line</span>")
            if finished:
                timing+=f" · Finished <span data-local-ts='{e(finished)}'>{e(finished)}</span>"
            if elapsed:
                timing+=f" · Elapsed {e(elapsed)}"
            body+=f"<a class='card jobrow' href='/jobs/{j['id']}'><b>#{j['id']}</b><span>{e(j['kind'])}</span><span class='badge {e(j['status'])}'>{e(j['status'])}</span><span>{e(j['message'] or '')}<div class='muted'>{e(j['current_filename'] or '')}</div><div class='muted' style='margin-top:3px'>{timing}</div></span><span>{e(progress)} · {pct}% · {j['failed']} errors</span></a>"
        if not js:
            body+="<div class='muted'>No library jobs yet.</div>"
        body+='</div>'
        try:      # reel builds live on their project pages; list them here too, so Activity shows every job
            from . import auto_edit as _ae
            rj=_ae.recent_jobs(20)
        except Exception:
            rj=[]
        if rj:
            body+="<h2 style='margin:22px 0 8px'>Reel builds (Auto Edit)</h2><div class='jobs'>"
            for j in rj:
                st=j['settings']
                body+=(f"<a class='card row space' href='/auto/p/{int(j['project_id'])}'><span><b translate='no'>{e(j['title'])}</b> "
                       f"<span class='muted'>· {e(st.get('length',''))} s · {e(j['created_at'][:16].replace('T',' '))}</span>"
                       + (f"<div class='muted'>{e((j.get('error') or '')[:160])}</div>" if j['status']=='failed' and j.get('error') else '')
                       + f"</span><span class='badge {e(j['status'])}'>{e(j['label'])}</span></a>")
            body+="</div>"
        script="""document.querySelectorAll('[data-local-ts]').forEach(x=>{try{const d=new Date(x.dataset.localTs);if(!isNaN(d))x.textContent=d.toLocaleTimeString(document.documentElement.lang||[],{hour:'numeric',minute:'2-digit',second:'2-digit'})}catch(e){}});"""
        if active_any:
            script+="setTimeout(()=>location.reload(),1200);"
        return layout('Jobs',body,script)

    @app.get('/jobs/<int:jid>')
    def job_page(jid):
        d=job_detail(jid)
        if not d:return 'Not found',404
        j=d['job']
        from .service import transfers_pending
        safe=' · source can be disconnected' if j.get('source_releasable') and j['status']=='running' and not transfers_pending() else ''
        body=f"<div class='row space'><div><h1>Job #{jid}</h1><div class='muted'><span>{e(j['kind'])}</span> · <span>{e(j['status'])}</span> · {j['done']}/{j['total']}{(' · <span>'+human_bytes(j['bytes_done'])+'</span>/<span>'+human_bytes(j['bytes_total'])+'</span>') if j['bytes_total'] else ''}{safe}</div></div><div class='row'>"
        if j['failed']:
            body += f"<button onclick=\"jobAction(this,'/api/jobs/{jid}/retry','retry')\" class='warn'>Retry failed</button>"
        if j['status'] in ('queued','running','waiting'):
            body += f"<button onclick=\"jobAction(this,'/api/jobs/{jid}/cancel','cancel')\" class='danger'>Cancel job</button>"
        body+='</div></div><div class="jobs">'
        for x in d['items']:
            err=f"<div class='errbox'>{e(x['error'])}</div>" if x['error'] else ''
            body+=f"<div class='card'><div class='row space'><b>{x['seq']}. <span translate='no'>{e(x['filename'])}</span></b><span class='badge {e(x['status'])}'>{e(x['phase'])}</span></div><div class='muted'><span translate='no'>{e(x['source_label'])}</span> · {('<span>'+human_bytes(x['bytes_total'])+'</span>') if (x['status']=='done' and not x['bytes_done']) else ('<span>'+human_bytes(x['bytes_done'])+'</span>/<span>'+human_bytes(x['bytes_total'])+'</span>')} · <span>{e(x['result_status'] or '')}</span></div>{err}</div>"
        body+='</div>'
        script="""window.jobActionBusy=false;
async function jobAction(btn,url,mode){
  if(window.jobActionBusy)return;
  window.jobActionBusy=true;
  const label=btn.textContent;
  btn.disabled=true;
  btn.textContent=mode==='retry'?'Retrying…':'Cancelling…';
  try{
    const r=await fetch(url,{method:'POST'});
    let x={};
    try{x=await r.json()}catch(_){}
    if(!r.ok)throw new Error(x.error||('HTTP '+r.status));
    if(mode==='retry'&&x.job_id){toast('Retry job #'+x.job_id);location.href='/jobs/'+x.job_id;return}
    if(mode==='cancel'&&x.ok){toast('Cancellation requested');setTimeout(()=>location.reload(),500);return}
    throw new Error(x.error||'Action did not complete');
  }catch(err){
    toast('Action outcome is unknown — check job status before trying again. '+((err&&err.message)||''));
    btn.disabled=false;
    btn.textContent='Check status';
    btn.onclick=()=>location.reload();
    window.jobActionBusy=false;
  }
}
"""
        if j['status'] in ('queued','running','waiting'):
            script+="setTimeout(()=>{if(!window.jobActionBusy)location.reload()},1500);"
        return layout(f'Job {jid}',body,script)

    @app.post('/api/jobs/<int:jid>/retry')
    def retry(jid):
        try:return jsonify({'job_id':retry_failed(jid)})
        except Exception as exc:return jsonify({'error':str(exc)}),400

    @app.post('/api/jobs/<int:jid>/cancel')
    def cancel(jid):
        try:
            ok=cancel_job(jid);return jsonify({'ok':ok,'error':None if ok else 'Job is already finished or not found'})
        except Exception as exc:return jsonify({'ok':False,'error':str(exc)}),400

    @app.get('/settings')
    def settings():
        cfg=load_config(); body=f"""<div class='pagehead'><div class='eyebrow'>Configuration</div><h1>Settings</h1><div class='lead'>Storage, privacy and local analysis behavior. External capabilities are managed separately in Setup & Connections.</div><div class='row' style='margin-top:10px'><span class='muted'>Interface language</span><form method='post' action='/lang' style='margin:0'><input type='hidden' name='lang' value='en'><input type='hidden' name='back' value='/settings'><button class='{'btn2' if i18n.ui_language()=='ru' else ''}' translate='no'>English</button></form><form method='post' action='/lang' style='margin:0'><input type='hidden' name='lang' value='ru'><input type='hidden' name='back' value='/settings'><button class='{'' if i18n.ui_language()=='ru' else 'btn2'}' translate='no'>Русский</button></form></div></div>{_look_card()}{_phone()}<div class='about-grid'><div><div class='section-title'>Storage</div><div class='card about-list'><div><b>Data folder</b><div class='muted'>{e(HOME)} <span class='muted'>(projects, database, exports{' — kept outside the program folder, shared by every release' if INSTALL!=HOME else ''})</span></div></div><div><b>Program folder</b><div class='muted'>{e(INSTALL)}</div></div><div><b>Staging</b><div class='muted'>{e(STAGING)}</div></div><div><b>Private</b><div class='muted'>{e(PRIVATE)}</div></div><div><b>Rejected quarantine</b><div class='muted'>{e(REJECTED)}</div></div><div><b>Archive folder</b><div class='muted'>{e(cfg['archive_root'])}</div></div></div></div><div><div class='section-title'>Behavior</div><form method='post' action='/settings/save' class='card'><label>Archive folder<br><input name='archive_root' style='width:100%;margin-top:5px' value='{e(cfg['archive_root'])}'></label><br><br><label>Free-space reserve GB<br><input name='min_free_gb' type='number' value='{e(cfg['ingest']['min_free_gb'])}' style='margin-top:5px'></label><br><br><label><input type='checkbox' name='privacy' {'checked' if cfg['privacy']['enabled'] else ''}> Privacy screening</label><br><label><input type='checkbox' name='quality' {'checked' if cfg['analysis']['technical_quality'] else ''}> Technical quality triage</label><br><label><input type='checkbox' name='notify' {'checked' if (cfg.get('auto_edit') or {}).get('notify',True) is not False else ''}> Windows notification when a reel or a conversion that took more than a minute is ready</label><br>{_autostart_box()}<br><button>Save settings</button></form></div></div><div class='section-title'>Existing local sources</div><div class='card'>"""
        for i,s in enumerate(cfg.get('sources',[])):
            body+=f"<div class='row space' style='padding:7px 0'><span><b translate='no'>{e(s.get('label') or s.get('path'))}</b><div class='muted' translate='no'>{e(s.get('path'))}</div></span><form method='post' action='/settings/remove-source'><input type='hidden' name='index' value='{i}'><input type='hidden' name='path' value='{e(str(s.get('path') or ''))}'><button class='danger'>Remove</button></form></div>"
        if request.args.get('source_error','').strip():
            body+=f"<div class='errbox' style='margin:8px 0'>{e(request.args.get('source_error','').strip())}</div>"
        body+=f"""<form method='post' action='/settings/add-source' class='toolbar'><input name='label' placeholder='Label'><input name='path' style='min-width:360px' placeholder='D:\\Videos'><button type='button' class='btn2' onclick=\"(async b=>{{b.disabled=true;try{{const r=await fetch('/api/auto/pick-folder',{{method:'POST'}});const x=await r.json();if(x.path)b.form.path.value=x.path}}catch(e){{}}b.disabled=false}})(this)\">Choose folder…</button><button>Add source</button></form></div><div class='section-title'>Rights Guard</div><div class='card'>Privacy, technical quality and publishing-rights risk stay separate. Rights flags are conservative workflow hints, not legal determinations. Manual rights decisions are preserved across later analysis.</div>"""
        if request.args.get('saved'):
            body="<div class='card ae-done' style='margin-bottom:12px'>Settings saved.</div>"+body
        return layout('Settings',body)

    @app.post('/lang')
    def set_language():
        want=request.form.get('lang') or ('en' if i18n.ui_language()=='ru' else 'ru')
        i18n.set_ui_language(want)
        back=request.form.get('back') or '/'
        if not back.startswith('/') or back.startswith('//'): back='/'
        return redirect(back)

    @app.get('/about')
    def about():
        cfg=load_config(); phone=phone_snapshot(); phone_text=(phone.get('model') or phone.get('serial') or 'Android')+' connected' if phone['connected'] else (phone.get('error') or 'not connected')
        body=f"""<div class='card about-hero tone-blue'><div class='eyebrow'>Why we built it</div><h1 style='font-size:36px;letter-spacing:-.8px;margin:4px 0 8px'>MediaEngine</h1><div class='lead' style='max-width:880px'>Your footage may already be spread across phones, cameras, cards and old folders while the useful moments stay buried inside thousands of files. MediaEngine is a private workspace designed to turn that mess into a usable creative library.</div><div class='row' style='margin-top:16px'><span class='badge ready'>local-first</span><span class='badge safe'>privacy-first</span><span class='badge duplicate'>AI-assisted</span><span class='badge audioflag'>built for video</span></div></div><div class='section-title'>Who is building it</div><div class='card tone-violet'><h2 style='margin-top:0'>Built local-first</h2><p class='lead' style='font-size:15px'>MediaEngine is being shaped around real mixed-device media workflows: explicit import, source safety, private local analysis, nondestructive editing and clear control over every optional external connection.</p><div class='muted'>The product identity is installation-neutral: no personal paths, devices, accounts or credentials are built into defaults.</div></div><div class='section-title'>The idea</div><div class='about-grid'><div class='card'><h2 style='margin-top:0'>One place between the camera and the final story.</h2><p class='lead' style='font-size:15px'>We do not want another photo viewer. We want MediaEngine to remember what we chose, protect what must stay private, understand what is inside long videos, and surface the clips that are actually worth using.</p><div class='principles'><div class='principle tone-mint'><b>Keep the originals safe</b><span class='muted'>Phone, SD and camera originals are never automatically deleted or rewritten.</span></div><div class='principle tone-rose'><b>Private means private</b><span class='muted'>Private Forever stays out of the normal Library and future creative workflows.</span></div><div class='principle tone-violet'><b>AI suggests, we decide</b><span class='muted'>Quality, privacy and rights checks help us review; they do not silently make destructive decisions.</span></div></div></div><div class='card'><h2 style='margin-top:0'>Where we are</h2><div class='roadmap'><div class='roadmap-step'><span class='step-dot'></span><div><b>Import → Library</b><div class='muted'>Browse Android, SD/USB and local folders in Import; only selected media becomes the working collection.</div></div></div><div class='roadmap-step'><span class='step-dot'></span><div><b>Understand video</b><div class='muted'>Storyboards and hover previews are the start; semantic tags and scene-level understanding come next.</div></div></div><div class='roadmap-step'><span class='step-dot'></span><div><b>Virtual clips</b><div class='muted'>Mark useful moments without cutting or duplicating the original file.</div></div></div><div class='roadmap-step'><span class='step-dot'></span><div><b>Content Composer</b><div class='muted'>The long-term goal: ask for a story or Reel and let the system find the right safe, useful moments from your own archive.</div></div></div></div></div></div><div class='section-title'>Our rules</div><div class='about-grid'><div class='card about-list'><div><b>Privacy, quality and publishing rights stay separate.</b><div class='muted'>A technically beautiful clip can still be private or need a rights review.</div></div><div><b>No mystery copies.</b><div class='muted'>Import is explicit. Library means the local working set.</div></div><div><b>No automatic source cleanup.</b><div class='muted'>Disconnect only after MediaEngine explicitly says the source is safe to disconnect.</div></div><div><b>No fake certainty.</b><div class='muted'>Rights Guard flags risk and context; it does not pretend every venue question has a simple legal yes/no answer.</div></div></div><div class='card'><h2 style='margin-top:0'>This installation</h2><div class='about-list'><div><b>Version</b><div class='muted'>MediaEngine v{e(VERSION)}{(' ' + e(BUILD)) if BUILD else ''}</div></div><div><b>Android</b><div class='device' style='margin-top:5px'><span class='device-dot {'online' if phone['connected'] else ''}' data-phone-dot></span><span class='muted' data-phone-text>{e(phone_text)}</span></div></div><div><b>Data folder</b><div class='muted'>{e(HOME)}</div></div><div><b>Program folder</b><div class='muted'>{e(INSTALL)}</div></div><div><b>Staging</b><div class='muted'>{e(STAGING)}</div></div><div><b>Archive folder</b><div class='muted'>{e(cfg['archive_root'])}</div></div></div></div></div><div class='section-title'>Updates</div><div class='card callout'><b>A new version goes next to this one.</b><div class='muted' style='margin-top:4px'>The Update button looks on GitHub for a newer version only when you press it. The new version goes into its own folder and the previous one stays, so you can go back to it on Check this PC. If a new version does not start, the previous one is started again.</div><div class='row' style='margin-top:8px'><a class='btn btn2' href='/auto/update'>Updates</a><a class='btn btn2' href='/auto/check'>Check this PC</a></div></div>"""
        return layout('About',body)

    @app.post('/import/add-source')
    def import_add_source():
        try:
            err=_add_source(request.form)
            if err:
                return redirect('/import?source_error='+urllib.parse.quote(err))
            start_discovery()
            return redirect('/import?source_kind=fixed')
        except Exception as exc:
            return redirect('/import?source_error='+urllib.parse.quote(str(exc)))

    @app.post('/import/remove-source')
    def import_remove_source():
        _remove_source(request.form)
        return redirect('/import')

    @app.post('/settings/add-source')
    def add_source():
        err=_add_source(request.form)
        return redirect('/settings'+('?source_error='+urllib.parse.quote(err) if err else ''))

    @app.post('/settings/remove-source')
    def rem_source():
        _remove_source(request.form)
        return redirect('/settings')

    def _phone():
        try:
            from .inbox_web import phone_card
            return phone_card(e)
        except Exception:
            return ''

    def _look_card():
        cur,size=ui_theme(),ui_scale()
        def swatch(cols):
            return ''.join("<i style='background:"+c+"'></i>" for c in cols)
        cards=''.join(f"<label><input type='radio' name='theme' value='{k}' {'checked' if k==cur else ''} onchange='this.form.submit()'>"
                      f"<b>{e(t)}</b><div class='muted' style='font-size:13px;margin-top:4px'>{e(d)}</div>"
                      f"<div class='look-sw'>{swatch(sw)}</div></label>"
                      for k,t,d,sw in THEME_INFO)
        sizes=''.join(f"<label style='margin-right:14px'><input type='radio' name='scale' value='{k}' {'checked' if k==size else ''} "
                      f"onchange='this.form.submit()'> {e(v)}</label>"
                      for k,v in (('auto','By the screen (bigger on a wide one)'),('100','100%'),('115','115%'),('130','130%'),('150','150%')))
        return (f"<div class='section-title'>Look</div><form method='post' action='/settings/look' class='card'>"
                f"<div class='row' style='margin-bottom:10px'><b>Size</b>{sizes}</div>"
                f"<div class='look-pick'>{cards}</div><noscript><button style='margin-top:8px'>Save</button></noscript></form>")

    @app.post('/settings/look')
    def save_look():
        t,z=str(request.form.get('theme') or ''),str(request.form.get('scale') or '')
        def change(cfg):
            ui=cfg.setdefault('ui',{})
            if t in THEMES:
                ui['theme']=t
            if z in SCALES:
                ui['scale']=z
        if t in THEMES or z in SCALES:
            update_config(change)
        return redirect('/settings')

    @app.post('/settings/save')
    def save_settings():
        ar=request.form.get('archive_root','').strip()
        err=''
        if ar:
            try:
                arp=Path(os.path.expandvars(ar)).expanduser()   # stored as the full folder: every part of the app reads it the same way
                if not arp.is_absolute():     # (an unknown %VAR% / $VAR stays in the text: not a full path)
                    raise ValueError
                ar=str(arp.resolve())
            except (OSError,ValueError):
                ar,err='','The archive folder must be a full folder path, such as D:\\Video Archive'
        def change(cfg):
            if ar:cfg['archive_root']=ar
            try:
                gb=int(str(request.form.get('min_free_gb','10')).strip())
                cfg.setdefault('ingest',{})['min_free_gb']=max(1,min(100000,gb))
            except ValueError:
                pass
            cfg.setdefault('privacy',{})['enabled']='privacy' in request.form
            cfg.setdefault('analysis',{})['technical_quality']='quality' in request.form
            cfg.setdefault('auto_edit',{})['notify']='notify' in request.form
        update_config(change)
        if SIDE_BY_SIDE and os.name=='nt' and request.form.get('autostart_shown')=='1':   # (only where the box was shown)
            try:
                from .platform_adapter import set_autostart
                set_autostart(INSTALL,'autostart' in request.form)
            except Exception:
                err=err or 'Start at sign-in could not be changed.'
        return redirect('/settings'+('?source_error='+urllib.parse.quote(err) if err else '?saved=1'))

    register_auto_edit(app, layout, e, human_bytes)
    return app
