"""The page "Cartoon Studio" (Auto Edit -> Cartoon Studio): a 2D cartoon made by MediaEngine from a script - its own
characters, scenes, schemes of money, voices and captions (cartoon/). Make one, watch it, change a line, a background
or a feeling and make it again."""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

from flask import jsonify, redirect, request, send_file

from . import voice as vo
from .cartoon import bgs, chars as ch, film as F, jobs as cj, library as L, reference as R, stories, textscript as T, writer as W
from .cartoon.draw import STYLES

CSS = """<style>
.ct-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.ct-row select,.ct-row input,.ct-choices select{max-width:100%;min-width:0}
.ct-choices label{display:inline-flex;gap:6px;align-items:center;margin:3px 14px 3px 0}
.ct-film{border-top:1px solid var(--line);padding:12px 0}
.ct-film video{max-width:240px;max-height:320px;border-radius:10px;background:#000}
.ct-scene{border:1px solid var(--line2);border-radius:12px;padding:10px 12px;margin:10px 0}
.ct-line{display:grid;grid-template-columns:130px minmax(0,1fr) 118px 118px auto;gap:8px;margin:6px 0}
.ct-line.gone input:not([type=hidden]),.ct-line.gone select{opacity:.4;text-decoration:line-through}
.ct-ops{display:inline-flex;gap:4px;align-items:center}.ct-ops .btn2{padding:3px 10px;min-width:0;margin:0}
.ct-scene{display:grid;grid-template-columns:200px minmax(0,1fr);gap:12px;align-items:start}
.ct-thumb{width:200px;aspect-ratio:16/9;border-radius:8px;object-fit:cover;background:#0003;display:block}
.ct-thumb.tall{width:120px;aspect-ratio:9/16;justify-self:center}
.ct-scene.gone{opacity:.45}.ct-scene.gone [data-lines],.ct-scene.gone [data-addend]{display:none}
.ct-lang{border:1px solid var(--line2);border-radius:12px;padding:10px 12px;margin:6px 0 4px}
@media(max-width:700px){.ct-scene{grid-template-columns:1fr}.ct-thumb{width:100%;max-width:320px}.ct-thumb.tall{width:140px}}
@media(max-width:900px){.ct-line{grid-template-columns:repeat(3,minmax(0,1fr)) auto;gap:6px;padding-bottom:8px;border-bottom:1px solid var(--line)}
.ct-line>input:not([type=hidden]){grid-column:1/-1;order:-1}}
.ct-line input{width:100%}
.ct-big video{max-width:100%;max-height:calc(70vh / var(--z,1));border-radius:12px;background:#000}
.ct-cast{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.ct-who{border:1px solid var(--line2);border-radius:12px;padding:10px;display:flex;gap:10px;align-items:flex-start}
.ct-who img{width:96px;height:120px;border-radius:8px;background:#eef3f8;flex:none}
.ct-look{display:grid;grid-template-columns:140px minmax(0,1fr);gap:6px 10px;align-items:center}
.ct-sw{display:inline-block;width:16px;height:16px;border-radius:4px;border:1px solid #0003;vertical-align:middle}
.ct-board{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px}
.ct-shot{border:1px solid var(--line2);border-radius:10px;padding:6px;font-size:13px}
.ct-shot img{width:100%;max-height:260px;object-fit:contain;border-radius:6px;background:#000;display:block}
.ct-vids{width:100%;border-collapse:collapse;font-size:14px}.ct-vids td,.ct-vids th{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}.ct-vids .n{white-space:nowrap;text-align:right}
.ct-nums{display:grid;grid-template-columns:minmax(120px,max-content) minmax(0,1fr);gap:4px 14px}
.ct-chip{display:inline-flex;align-items:center;gap:6px;margin:3px 12px 3px 0;font-size:13px}
.ct-chip i{display:inline-block;width:28px;height:20px;border-radius:5px;border:1px solid #0003}
.ct-strip{display:flex;height:34px;border-radius:8px;overflow:hidden;border:1px solid var(--line2);margin-top:6px}
.ct-strip a{display:block;min-width:0;border-right:2px solid var(--bg,#111)}
.ct-strip.dense a{border-right:0}
.ct-draw{display:flex;flex-wrap:wrap;gap:10px;margin-top:4px}
.ct-draw label{display:flex;flex-direction:column;gap:4px;cursor:pointer;font-size:13px;width:164px}
.ct-draw img{width:160px;height:90px;border-radius:8px;border:2px solid var(--line2);background:#0003;object-fit:cover;display:block}
.ct-draw label:has(input:checked) img{border-color:var(--acc,#7aa2ff);box-shadow:0 0 0 2px var(--acc,#7aa2ff)}
.ct-draw span{display:inline-flex;gap:6px;align-items:center}
</style>"""
_EDIT_JS = """;(()=>{const box=document.getElementById('ctScenes');if(!box)return;
const order=document.getElementById('ctOrder');let n=0;
const changed=()=>box.closest('form').dispatchEvent(new Event('input',{bubbles:true}));
const renum=()=>{const ss=[...box.querySelectorAll('.ct-scene:not(.gone)')];order.value=ss.map(x=>x.dataset.scene).join(',');
let k=0;box.querySelectorAll('.ct-scene').forEach(x=>{const m=x.querySelector('[data-num]');if(m)m.textContent=x.classList.contains('gone')?'-':++k;});changed();};
const newRow=(i,at)=>{const t=document.getElementById('ctNew').content.firstElementChild.cloneNode(true);const k=n++;
t.querySelectorAll('[data-f]').forEach(el=>el.name='n_'+i+'_'+k+'_'+el.dataset.f);t.querySelector('[data-f=at]').value=at;return t;};
box.addEventListener('click',ev=>{const b=ev.target.closest('button');if(!b||!box.contains(b))return;
const sc=b.closest('.ct-scene');const i=sc.dataset.scene;const row=b.closest('.ct-line');
if(b.hasAttribute('data-del')){const x=row.querySelector('input[name^=x_]');if(x){x.value=x.value?'':'1';row.classList.toggle('gone',!!x.value);}else row.remove();changed();}
else if(b.hasAttribute('data-add')){const at=row.dataset.at!==undefined?row.dataset.at:row.querySelector('[data-f=at]').value;
const r=newRow(i,at);row.after(r);r.querySelector('[data-f=t]').focus();changed();}
else if(b.hasAttribute('data-addend')){const ls=sc.querySelector('[data-lines]');const r=newRow(i,ls.dataset.last);ls.appendChild(r);
r.querySelector('[data-f=t]').focus();changed();}
else if(b.hasAttribute('data-up')){const p=sc.previousElementSibling;if(p)p.before(sc);renum();}
else if(b.hasAttribute('data-down')){const x=sc.nextElementSibling;if(x)x.after(sc);renum();}
else if(b.hasAttribute('data-drop')){sc.classList.toggle('gone');renum();}});})();"""
_JOB_ID = r"[0-9]{8}-[0-9]{6}-[0-9a-f]{6}"
_STEP = {"starting": "Starting…", "voices": "The characters are speaking…", "drawing": "Drawing the pictures…",
         "checking": "Checking the film…", "loading": "Starting the story writer…", "writing": "Writing the story…",
         "listening": "Listening to the video…", "notes": "Noting the video's facts…",
         "looking": "Finding where the shots change…", "pictures": "Taking a picture of each shot…"}
_WR_STEP = {"checking": "Checking the PC…", "program": "Downloading llama.cpp (the program that runs the model)…",
            "model": "Downloading the language model…", "checking_model": "Checking the downloaded model…",
            "testing": "Starting the story writer for a test…"}
LANG_LABELS = {"en": "English", "ru": "Русский", "ro": "Română"}
DRAW_LABELS = {"flat": "Flat (as before)", "hand": "Hand-drawn", "board": "Whiteboard", "paper": "Paper cut-out",
               "motion": "Motion graphics"}
BUSY = "The characters' file is held by another program a moment (a virus check, a sync). Try again."
BG_LABELS = {"city": "City street", "office": "Office", "city_hall": "City hall", "road": "Road", "bank": "Bank",
             "night": "Night street", "board": "Board (schemes, charts)", "paper": "Paper", "hospital": "Hospital",
             "school": "School", "shop": "Shop", "home": "Block of flats",
             "site": "Building site"}
EMO_LABELS = {"": "—", "neutral": "calm", "happy": "happy", "angry": "angry", "sad": "sad", "surprised": "surprised",
              "sly": "sly", "worried": "worried"}
POSE_LABELS = {"": "—", "talk": "talking", "explain": "explaining", "point": "pointing", "point_up": "finger up",
               "shrug": "shrugging", "cross": "arms crossed", "think": "thinking", "wave": "waving", "hands_up": "hands up",
               "count": "rubbing hands", "present": "presenting", "facepalm": "hand to face", "fist": "fist",
               "sneaky": "sneaky", "idle": "standing"}
LEN_LABELS = (("60", "about 1 minute"), ("75", "about 75 seconds"), ("90", "about 1.5 minutes"))
STORY_LABELS = {"road_contract": "How a City Loses Millions on a Simple Road Contract (example, 10 scenes)"}


HELP_EN = ("First lines: <code>Title:</code>, <code>Format: vertical</code> or <code>wide</code>, <code>Narrator: Name (woman)</code>, "
           "then the characters - <code>Name (man, mayor)</code>. A scene starts with <code>==</code> and its background "
           "(City street, Office, City hall, Road, Bank, Night, Board, Paper, Hospital, School, Shop, Home, Building site); after <code>|</code> what it shows: "
           "<code>title: …</code>, <code>road</code>, <code>contract: CONTRACT; price $4 800 000; stamp APPROVED</code>, "
           "<code>flow: City -&gt; Company $4.8M; Company -&gt; Officials kickback</code>, <code>bars: fair 1.2, paid 9.6 M</code>, "
           "<code>list: Red flags; one bidder; rushed deadlines</code>, <code>counter: $4 800 000 spent</code>, "
           "<code>percent: 30% kickback</code>, <code>timeline: 2021 contract; 2023 holes back</code>. "
           "A line: <code>Name (gesture, feeling): words</code>; <code>[bubble]</code> shows it in a speech bubble. "
           "Gestures: talk, explain, point, point up, shrug, cross, think, wave, hands up, rubs hands, present, facepalm, fist, "
           "sneaky. Feelings: calm, happy, angry, sad, surprised, sly, worried. English or Russian.")
HELP_RU = ("Первые строки: <code>Название:</code>, <code>Формат: вертикальный</code> или <code>широкий</code>, "
           "<code>Рассказчик: Имя (женщина)</code>, потом персонажи — <code>Имя (мужчина, мэр)</code>. Сцена начинается с "
           "<code>==</code> и фона (Улица, Офис, Мэрия, Дорога, Банк, Ночь, Доска, Бумага, Больница, Школа, Магазин, Дом, Стройка); после <code>|</code> — что в ней "
           "показано: <code>заголовок: …</code>, <code>дорога</code>, <code>договор: ДОГОВОР; цена 4 800 000 ₽; печать УТВЕРЖДЕНО</code>, "
           "<code>схема: Бюджет -&gt; Фирма 4,8 млн; Фирма -&gt; Чиновники откат</code>, <code>график: честно 1.2, заплатили 9.6 млн</code>, "
           "<code>список: Признаки; одна заявка; сжатые сроки</code>, <code>сумма: 4 800 000 ₽ потрачено</code>, "
           "<code>процент: 30% откат</code>, <code>хронология: 2021 договор; 2023 ямы снова</code>. Реплика: "
           "<code>Имя (жест, настроение): слова</code>; <code>[пузырь]</code> — показать её в облачке. Жесты: говорит, объясняет, "
           "показывает, палец вверх, пожимает плечами, руки скрещены, думает, машет, руки вверх, потирает руки, представляет, "
           "рука у лица, кулак, крадётся. Настроения: спокойно, радостно, сердито, грустно, удивлённо, хитро, тревожно. "
           "По-русски или по-английски.")


def _help() -> str:
    try:
        from .i18n import ui_language
        ru = ui_language() == "ru"
    except Exception:
        ru = False
    return ("<details style='margin:6px 0'><summary>How to write a story</summary><div class='muted' style='font-size:13px;"
            f"line-height:1.5' translate='no'>{HELP_RU if ru else HELP_EN}</div></details>")


def _label(j: dict) -> str:
    return _STEP.get(str(j.get("step") or "").split(" ")[0], "Working…")


def register(app, page, err_page, e, human_bytes):

    def _bar(j: dict) -> str:
        return (f"<div class='ae-bar' style='margin-top:6px'><i data-bar style='width:{int(100 * float(j.get('progress') or 0))}%'></i></div>"
                f"<div class='muted' style='font-size:13px' data-step>{e(_label(j))}</div>"
                f"<form method='post' action='/auto/cartoon/{j['id']}/stop' style='margin-top:6px'><button class='btn2'>Stop</button></form>")

    def _state_html(j: dict) -> str:
        st, res = j["state"], j.get("result") or {}
        if st == "working":
            return _bar(j)
        if st == "waiting":
            return ("<div class='muted'>Waiting (another voice-over, clip or cartoon job is being made first).</div>"
                    f"<form method='post' action='/auto/cartoon/{j['id']}/stop' style='margin-top:6px'><button class='btn2'>Don't make it</button></form>")
        if st in ("failed", "interrupted"):
            msg = res.get("error") or ("Interrupted (MediaEngine was closed)." if st == "interrupted" else "Failed")
            return (f"<div class='errbox' style='margin-top:6px'>{e(msg)}</div>"
                    f"<form method='post' action='/auto/cartoon/{j['id']}/retry' style='margin-top:6px'><button>Try again</button></form>")
        return ""

    def _block(j: dict, inner: str) -> str:
        return f"<div class='ct-film' data-job='{j['id']}' data-state='{j['state']}'>{inner}</div>"

    def _story_row(j: dict) -> str:
        res = j.get("result") or {}
        when = e(str(j.get("created_at") or "")[:16].replace("T", " "))
        head = (f"<div class='ct-row'><span>Story:</span> <a href='/auto/cartoon/{j['id']}'><b translate='no'>{e(j.get('title') or '')}</b></a>"
                f"<span class='muted' style='font-size:13px' translate='no'>{when} · {e(LANG_LABELS.get(j.get('lang'), ''))}</span></div>")
        if j["state"] == "done":
            body = (f"<div class='muted' style='font-size:13px;margin-top:4px'><span translate='no'>{int(res.get('scenes') or 0)}</span> "
                    f"<span>scenes</span> · <span translate='no'>{int(res.get('words') or 0)}</span> <span>words</span></div>"
                    + _film_of_story(res)
                    + f"<div class='ct-row' style='margin-top:8px'><a class='btn{' btn2' if res.get('film') else ''}' "
                    f"href='/auto/cartoon/{j['id']}'>{'Read the story' if res.get('film') else 'Read it and make the cartoon'}</a>"
                    + _delete(j) + "</div>")
        else:
            body = _state_html(j) + ("" if j["state"] in ("working", "waiting") else f"<div style='margin-top:6px'>{_delete(j)}</div>")
        return _block(j, head + body)

    def _film_of_story(res: dict) -> str:
        """The cartoon made at once from a story (or why it could not be)."""
        if res.get("film_error"):
            return f"<div class='errbox' style='margin-top:6px'>{e(res['film_error'])}</div>"
        if not res.get("film"):
            return ""
        fj = _job(str(res["film"]))
        if not fj:
            return "<div class='muted' style='font-size:13px;margin-top:4px'>Its cartoon was deleted.</div>"
        state = {"done": "ready", "working": "being made", "waiting": "waiting its turn"}.get(fj["state"], "not made")
        return (f"<div style='margin-top:6px'><span>Its cartoon:</span> <a href='/auto/cartoon/{fj['id']}'><b translate='no'>"
                f"{e(fj.get('title') or '')}</b></a> <span class='muted'>·</span> <span class='muted'>{e(state)}</span></div>")

    def _study_row(j: dict) -> str:
        res = j.get("result") or {}
        when = e(str(j.get("created_at") or "")[:16].replace("T", " "))
        head = (f"<div class='ct-row'><span>Study:</span> <a href='/auto/cartoon/{j['id']}'><b translate='no'>{e(j.get('title') or '')}</b></a>"
                f"<span class='muted' style='font-size:13px' translate='no'>{when}</span></div>")
        if j["state"] == "done":
            body = (f"<div class='muted' style='font-size:13px;margin-top:4px'><span translate='no'>{round(float(res.get('seconds') or 0))}</span> "
                    f"<span>s</span> · <span translate='no'>{int(res.get('shots') or 0)}</span> <span>shots</span> · "
                    f"<span>a shot lasts</span> <span translate='no'>{float(res.get('shot_avg') or 0):g}</span> <span>s</span></div>"
                    f"<div class='ct-row' style='margin-top:8px'><a class='btn' href='/auto/cartoon/{j['id']}'>See the storyboard</a>"
                    + _delete(j) + "</div>")
        else:
            body = _state_html(j) + ("" if j["state"] in ("working", "waiting") else f"<div style='margin-top:6px'>{_delete(j)}</div>")
        return _block(j, head + body)

    def _film_row(j: dict) -> str:
        if j.get("kind") == "cartoon_write":
            return _story_row(j)
        if j.get("kind") == "cartoon_study":
            return _study_row(j)
        res = j.get("result") or {}
        when = e(str(j.get("created_at") or "")[:16].replace("T", " "))
        head = (f"<div class='ct-row'><a href='/auto/cartoon/{j['id']}'><b translate='no'>{e(j.get('title') or '')}</b></a>"
                f"<span class='muted' style='font-size:13px' translate='no'>{when}</span>"
                + ("<span class='muted' style='font-size:13px'>without voices (a preview)</span>" if not j.get("voices") else "")
                + "</div>")
        body = ""
        if j["state"] == "done":
            body = (f"<div class='ct-row' style='margin-top:8px;align-items:flex-start'>"
                    f"<video controls preload='metadata' src='/auto/cartoon/{j['id']}/film.mp4'></video><div>"
                    f"<div class='muted' style='font-size:13px'><span translate='no'>{round(float(res.get('seconds') or 0))}</span> "
                    f"<span>s</span> · <span translate='no'>{int(res.get('scenes') or 0)}</span> <span>scenes</span></div>"
                    + (f"<div class='muted' style='font-size:13px'><span>Saved in</span> <span class='ae-path' translate='no'>"
                       f"{e(res.get('saved') or '')}</span></div>" if res.get("saved") else "")
                    + f"<div class='ct-row' style='margin-top:8px'><a class='btn' href='/auto/cartoon/{j['id']}'>Change and make again</a>"
                    + (f"<form method='post' action='/auto/cartoon/{j['id']}/reveal' style='margin:0'><button class='btn2'>Show in folder</button></form>"
                       if res.get("saved") else "")
                    + _delete(j) + "</div></div></div>")
        else:
            body = _state_html(j) + ("" if j["state"] in ("working", "waiting") else f"<div style='margin-top:6px'>{_delete(j)}</div>")
        return _block(j, head + body)

    def _delete(j: dict) -> str:
        if j["state"] in ("working", "waiting"):
            return ""
        q = ("Delete this story?" if j.get("kind") == "cartoon_write" else "Delete this study? The video stays." if
             j.get("kind") == "cartoon_study" else "Delete it? The film saved in the folder stays.")
        return (f"<form method='post' action='/auto/cartoon/{j['id']}/delete' style='margin:0' onsubmit=\"return confirm(window.ME_L?"
                f"ME_L('{q}'):'{q}')\">"
                f"<button class='btn2'>Delete</button></form>")

    def _format_choice(current: str) -> str:
        return "".join(f"<label><input type='radio' name='format' value='{k}' {'checked' if k == current else ''}> {e(v)}</label>"
                       for k, v in (("vertical", "Vertical 9:16 (TikTok, Reels, Shorts)"), ("horizontal", "Wide 16:9 (YouTube)")))

    def _drawing_choice(current: str = "flat") -> str:
        """How the cartoon is drawn: a little picture of each style (the example's road, drawn by the program)."""
        cur = current if current in DRAW_LABELS else "flat"
        cards = "".join(f"<label><img src='/auto/cartoon/drawing/{k}.jpg' alt='' loading='lazy' width='160' height='90'>"
                        f"<span><input type='radio' name='drawing' value='{k}' {'checked' if k == cur else ''}> {e(v)}</span></label>"
                        for k, v in DRAW_LABELS.items() if k in STYLES)
        return f"<div style='margin-top:8px'><b>Drawing style</b><div class='ct-draw'>{cards}</div></div>"

    def _drawing_select(current: str = "flat") -> str:
        return "".join(f"<option value='{k}' {'selected' if k == current else ''}>{e(v)}</option>"
                       for k, v in DRAW_LABELS.items() if k in STYLES)

    def _music_choice(current: dict | None | str = "") -> str:
        """current: the film's own music (None: it had none; "": a new film - the program's)."""
        cur = current if isinstance(current, dict) else {"kind": "none"} if current is None else {"kind": "made"}
        kind = cur.get("kind") if cur.get("kind") in ("made", "file") else "none"
        moods = "".join(f"<option value='{k}' {'selected' if k == cur.get('mood') else ''}>{e(v)}</option>" for k, v in
                        (("light", "light and lively"), ("suspense", "a little suspense"), ("calm", "calm and soft")))
        chk = lambda k: "checked" if k == kind else ""     # noqa: E731
        return (f"<div style='margin-top:8px'><b>Music</b><div class='ct-choices'>"
                f"<label><input type='radio' name='music' value='made' {chk('made')}> Made by the program</label>"
                f"<select name='mood'>{moods}</select>"
                f"<label><input type='radio' name='music' value='file' {chk('file')}> My music file</label>"
                f"<label><input type='radio' name='music' value='none' {chk('none')}> No music</label></div>"
                f"<div class='ct-row' style='margin-top:4px'><input name='music_path' value='{e(cur.get('path') or '')}' translate='no' "
                f"placeholder='A music file on this PC (for \"My music file\")' "
                f"style='flex:1;min-width:240px'><button type='button' class='btn2' data-pick-music>Choose…</button></div>"
                f"<div class='muted' style='font-size:13px'>Quiet under the voices; it goes softer while someone speaks.</div></div>")

    def _captions_choice() -> str:
        styles = "".join(f"<option value='{k}'>{e(v)}</option>" for k, v in
                         (("pop", "Bold capitals, the word said in color"), ("box", "On a dark box"), ("classic", "Classic"),
                          ("minimal", "Calm (business)"), ("single", "One word at a time, big"), ("block", "The word on a color block")))
        return (f"<label style='display:block;margin-top:8px'><input type='checkbox' name='captions' value='1' checked> Captions</label>"
                f"<div class='ct-row' style='margin-top:4px'><span>Look</span><select name='style'>{styles}</select></div>")

    def _camera_choice(close: bool = True, pace: str = "") -> str:
        paces = "".join(f"<option value='{k}' {'selected' if k == pace else ''}>{e(v)}</option>" for k, v in
                        (("", "usual"), ("quick", "short (quick)"), ("calm", "long (calm)")))
        return (f"<input type='hidden' name='camera_form' value='1'><label style='display:block;margin-top:8px'>"
                f"<input type='checkbox' name='camera' value='1' {'checked' if close else ''}> Close-ups of the one speaking "
                f"(in scenes without a picture to read)</label>"
                f"<div class='ct-row' style='margin-top:4px'><span>Pauses between lines</span><select name='pace'>{paces}</select></div>")

    def _voices_choice() -> str:
        have = vo.installed()
        return (f"<label style='display:block;margin-top:8px'><input type='checkbox' name='voices' value='1' {'checked' if have else 'disabled'}> "
                f"The characters speak (the voice add-on; a few minutes)</label>"
                + ("" if have else "<div class='muted' style='font-size:13px'>Without the voice add-on: a quick preview without "
                                   "voices. <a href='/auto/voice'>Install the voice add-on</a></div>"))

    def _lang_select(current: str = "en") -> str:
        return "".join(f"<option value='{k}' {'selected' if k == current else ''} translate='no'>{e(v)}</option>"
                       for k, v in LANG_LABELS.items())

    def _adapt_form(source: str, fmt: str, title: str, lang: str = "") -> str:
        """Retell a story for viewers of another country (and language): a story written by the model."""
        other = next((k for k in ("ru", "en", "ro") if k != lang), "en")
        return (f"<form method='post' action='/auto/cartoon/write' style='margin-top:8px' "
                f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<input type='hidden' name='mode' value='adapt'><input type='hidden' name='format' value='{e(fmt)}'>"
                f"<input type='hidden' name='title' value='{e(title)}'><textarea name='source' hidden>{e(source)}</textarea>"
                f"<div class='ct-row'><span>Language</span><select name='lang'>{_lang_select(other)}</select>"
                f"<span>Viewers in</span><input name='country' maxlength='60' placeholder='(a country)' style='width:180px'>"
                f"<button>Retell the story</button></div>"
                f"<div class='muted' style='font-size:13px;margin-top:4px'>The model translates it and changes the names, the money "
                f"and the offices to the country's own; the scenes and pictures stay. The new story opens to read before the cartoon.</div></form>")

    def _writer_card() -> str:
        s = W.status()
        if s["state"] == "running":
            pct = int(100 * s["done"] / s["total"]) if s.get("total") else 3
            return (f"<div class='card' id='wrInstall'><h2 style='margin-top:0'>Installing the story writer</h2>"
                    f"<div class='ae-bar'><i id='wrBar' style='width:{max(3, pct)}%'></i></div>"
                    f"<div style='margin-top:8px'><span id='wrStep'>{e(_WR_STEP.get(s.get('step'), ''))}</span></div>"
                    f"<div class='muted ae-path' id='wrDetail' translate='no'>{e(s.get('detail') or '')}</div>"
                    f"<div class='muted' style='font-size:13px;margin-top:6px'>From a few minutes to half an hour, depending on the "
                    f"internet. You can use MediaEngine meanwhile; closing it stops the download (it continues where it stopped "
                    f"when you press Install again).</div>"
                    f"<form method='post' action='/auto/cartoon/writer/cancel' style='margin-top:10px'><button class='btn2'>Cancel</button></form></div>")
        if s["installed"]:
            m = s.get("manifest") or {}
            where = (f"<span>the graphics card</span> <span translate='no'>{e(m.get('gpu') or '')}</span>" if m.get("gpu")
                     else "<span>the processor</span>")
            if m.get("gpu") and W.gpu_failed():
                where = ("<span>the processor</span> <span>(the graphics card stopped while writing a story on this PC)</span>"
                         "<form method='post' action='/auto/cartoon/writer/gpu-again' style='display:inline;margin-left:6px'>"
                         "<button class='btn2'>Try the graphics card again</button></form>")
            secs = "".join(f"<option value='{k}' {'selected' if k == '75' else ''}>{e(v)}</option>" for k, v in LEN_LABELS)
            return (f"<div class='card' id='writer'><h2 style='margin-top:0'>Write a story</h2>"
                    f"<form method='post' action='/auto/cartoon/write' onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                    f"<b>What is it about?</b><div class='muted' style='font-size:13px'>A topic in a few words - or paste a text (an "
                    f"article, notes, what is said in a video): the story retells it with its own characters. In any language, even "
                    f"in translit; the story's language is chosen below.</div>"
                    f"<textarea name='about' rows='4' maxlength='5000' style='width:100%' "
                    f"placeholder='Why a city hospital pays three times more for the same medicine'>"
                    f"{e(str(request.args.get('about') or '')[:5000])}</textarea>"
                    f"<details style='margin-top:6px'><summary>Or a video on this PC</summary>"
                    f"<div class='ct-row' style='margin-top:6px'><input name='video' placeholder='A video whose story to retell (its full path)' "
                    f"style='flex:1;min-width:260px'><button type='button' class='btn2' data-pick='video'>Choose…</button></div>"
                    f"<div class='muted' style='font-size:13px;margin-top:4px'>The program listens to it (the voice add-on), notes its "
                    f"facts and numbers and writes a new story with its own characters - not a copy. Listening takes a few minutes "
                    f"for an hour of video.</div><div class='muted' style='font-size:13px' data-msg></div></details>"
                    f"<div class='ct-row' style='margin-top:8px'><span>Language</span><select name='lang'>{_lang_select()}</select>"
                    f"<span>Viewers in</span><input name='country' maxlength='60' placeholder='(a country, if it matters)' style='width:200px'>"
                    f"<span>Length</span><select name='secs'>{secs}</select></div>"
                    f"{_rhythm_choice()}"
                    f"<details style='margin-top:8px'><summary>A series: several topics at once</summary>"
                    f"<textarea name='topics' rows='4' maxlength='3000' style='width:100%;margin-top:6px' "
                    f"placeholder='One topic per line (up to 10)'></textarea>"
                    f"<div class='muted' style='font-size:13px'>A story for every line, one after another - with the cartoon "
                    f"made at once (below), the whole series is ready when you come back.</div></details>"
                    f"<label style='display:block;margin-top:8px'><input type='checkbox' name='make' value='1'> Make the cartoon "
                    f"at once, without reading the story first (voices, captions, the program's music)</label>"
                    f"<div class='ct-row' style='margin:4px 0 0 24px'><span>Drawing style</span><select name='drawing'>{_drawing_select()}</select></div>"
                    f"<div class='ct-choices' style='margin-top:8px'><b>Format</b><br>{_format_choice('vertical')}</div>"
                    f"<div style='margin-top:12px'><button class='ae-big'>Write the story</button></div></form>"
                    f"<div class='muted' style='font-size:13px;margin-top:8px'><span>The free model on this PC</span> "
                    f"<span translate='no'>({e(s['labels'][s['which']])})</span> <span>writes it on</span> "
                    f"{where}<span>: about a minute on a graphics card, several minutes on the processor. Then read it, change what you "
                    f"like and make the cartoon.</span></div>"
                    f"<details style='margin-top:8px'><summary class='muted'>Another model</summary>{_model_choice(s, switch=True)}</details>"
                    f"<details style='margin-top:8px'><summary class='muted'>Remove the story writer</summary>"
                    f"<form method='post' action='/auto/cartoon/writer/remove' style='margin-top:8px' "
                    f"onsubmit=\"return confirm(window.ME_L?ME_L('Remove the story writer?'):'Remove the story writer?')\">"
                    f"<button class='btn2'>Remove</button> <span class='muted' style='font-size:13px'><span>Frees about</span> "
                    f"<span translate='no'>{s['sizes'][s['which']] / 1e9:.1f}</span> <span>GB. The stories and cartoons stay.</span>"
                    f"</span></form></details></div>")
        err = f"<div class='errbox' style='margin-bottom:10px'>{e(s.get('error') or '')}</div>" if s["state"] == "failed" else ""
        return (f"<div class='card' id='writer'>{err}<h2 style='margin-top:0'>Write a story with a free model on this PC</h2>"
                f"<div>The program can write the story itself: from a topic, from a text or a video, or retold for another country - "
                f"in English, Russian or Romanian. It needs a free language model (Qwen, Apache-2.0) and llama.cpp (MIT), "
                f"downloaded once into the data folder:</div>"
                f"<div class='ae-path' translate='no'>{e(str(W.ROOT))}</div>"
                f"<div class='muted' style='font-size:13px;margin-top:6px'>MediaEngine goes online for it only when you press a "
                f"button (github.com, huggingface.co). It runs on this PC; nothing is sent anywhere.</div>{_model_choice(s)}</div>")

    def _style_html(name: str, n: int) -> str:
        """An author style's name on a page: 'Style: <name> (3 videos)' (the name never translated)."""
        return ((f"<span>Style:</span> <span translate='no'>{e(name)}</span>" if name else "<span>A common style</span>")
                + f" (<span translate='no'>{int(n)}</span> <span>videos</span>)")

    def _style_option(x: dict) -> str:
        """An author style in a list of rhythms (an <option>: its name, never translated; or 'A common style (3 videos)')."""
        n = len(x.get("refs") or [])
        if x.get("name"):
            return f"<option value='{x['id']}' translate='no'>{e(x['name'])} · {n}</option>"
        return f"<option value='{x['id']}'>A common style ({n} videos)</option>"

    def _style_for_writer(ref) -> dict | None:
        """The style the story writer is given for a study's or an author style's id (without its colours)."""
        ref = str(ref or "")
        if not R.is_ref(ref):
            return None
        st = R.style_of(ref)
        return {k: v for k, v in st.items() if k not in ("palette", "spread")} or None

    def _rhythm_link(st) -> str:
        """' · rhythm like <the study or the author style>' on a story's page."""
        if not isinstance(st, dict) or not st.get("ref"):
            return ""
        ref = str(st["ref"])
        if R.STYLE_ID.fullmatch(ref):
            return (f" · <span>rhythm like</span> <a href='/auto/cartoon/style/{e(ref)}'>"
                    f"{_style_html(st.get('title') or '', st.get('videos') or 0)}</a>")
        return f" · <span>rhythm like</span> <a href='/auto/cartoon/{e(ref)}' translate='no'>{e(st.get('title') or '')}</a>"

    def _rhythm_choice() -> str:
        """The rhythm of a video studied (Reference Lab) or of an author (several videos), for the story writer: none
        when nothing is studied."""
        done = R.studies()[:20]
        sts = R.styles()[:20]
        if not done and not sts:
            return ""
        one = "".join(f"<option value='{j['id']}' translate='no'>{e(j.get('title') or '')} · "
                      f"{round(float((j.get('result') or {}).get('seconds') or 0))} s</option>" for j in done)
        opts = ((f"<optgroup label='Authors&#x27; styles (several videos)'>{''.join(_style_option(x) for x in sts)}</optgroup>"
                 + (f"<optgroup label='Videos studied'>{one}</optgroup>" if one else "")) if sts else one)
        return (f"<div class='ct-row' style='margin-top:8px'><span>Rhythm</span><select name='ref'>"
                f"<option value=''>The usual</option>{opts}</select>"
                f"<span class='muted' style='font-size:13px'>like a video you studied: its number of scenes, pace of words and opening</span></div>")

    def _study_card() -> str:
        have = vo.installed()
        return (f"<div class='card' id='study' style='margin-top:14px'><h2 style='margin-top:0'>Study a cartoon you like</h2>"
                f"<div class='muted' style='font-size:13px'>A video on this PC - a cartoon or a short whose rhythm you like. The "
                f"program finds where its shots change and how long they last, takes a picture of each (a storyboard), its main "
                f"colours and - with the voice add-on - what is said in each shot, how fast and how soon. Then the story writer "
                f"can write a new story with the same rhythm. Nothing is copied and nothing is sent anywhere.</div>"
                f"<form method='post' action='/auto/cartoon/study' style='margin-top:8px' "
                f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<div class='ct-row'><input name='video' placeholder='A video on this PC (its full path)' "
                f"style='flex:1;min-width:260px'><button type='button' class='btn2' data-pick='video'>Choose…</button></div>"
                f"<div class='muted' style='font-size:13px' data-msg></div>"
                f"<label style='display:block;margin-top:6px'><input type='checkbox' name='listen' value='1' "
                f"{'checked' if have else 'disabled'}> Listen to what is said (the voice add-on)</label>"
                + ("" if have else "<div class='muted' style='font-size:13px'>Without the voice add-on: the shots, pictures and "
                                   "colours only. <a href='/auto/voice'>Install the voice add-on</a></div>")
                + "<div style='margin-top:10px'><button>Study it</button></div></form>" + _styles_block() + "</div>")

    def _styles_block() -> str:
        """The author styles made, and a form to make one from several studied videos (two at least)."""
        sts = R.styles()
        done = R.studies()[:R.MAX_STYLE_VIDEOS]
        links = "".join(f"<div><a href='/auto/cartoon/style/{x['id']}'>{_style_html(x.get('name') or '', len(x.get('refs') or []))}</a></div>"
                        for x in sts[:20])
        form = ""
        if len(done) >= 2:
            ticks = "".join(f"<label style='display:block'><input type='checkbox' name='ref' value='{j['id']}'> <span translate='no'>"
                            f"{e(j.get('title') or '')} · {round(float((j.get('result') or {}).get('seconds') or 0))}</span> <span>s</span></label>"
                            for j in done)
            form = (f"<details style='margin-top:8px'><summary>Make a common style of several videos</summary>"
                    f"<form method='post' action='/auto/cartoon/style/new' style='margin-top:6px' "
                    f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                    f"<div style='max-height:240px;overflow:auto'>{ticks}</div>"
                    f"<div class='ct-row' style='margin-top:6px'><input name='name' maxlength='80' placeholder='Whose style (a name, if you like)' "
                    f"style='width:240px'><button>Make the common style</button></div></form></details>")
        if not links and not form:
            return ""
        return (f"<div style='margin-top:14px'><b>An author's style</b><div class='muted' style='font-size:13px'>Several videos "
                f"you studied - say, a few of one author's - taken together: the middle of their rhythms and their colours. "
                f"A story can then be written in that style.</div>{links}{form}</div>")

    def _model_choice(s: dict, switch: bool = False) -> str:
        """A button per model (the one for this PC first); switch: only the model not installed."""
        keys = [s["recommend"]] + [k for k in s["sizes"] if k != s["recommend"]]
        if switch:
            keys = [k for k in keys if k != s["which"]]
        why = {"big": "Writes better - Russian and Romanian too, and keeps the length. For a graphics card with 12 GB "
                      "(slow on a processor).",
               "small": "Smaller and quicker, any PC. English good, Russian and Romanian weaker."}
        out = ""
        for k in keys:
            gb = (s["sizes"][k] - (sum(int(b["size"]) for b in W.LLAMA["builds"].values()) if switch else 0)) / 1e9
            low = s.get("free", 0) < (s.get("needed") or {}).get(k, gb * 1e9) + 1_500_000_000
            label = ("Use" if switch else ("Try again with" if s["state"] == "failed" else "Install with"))
            out += (f"<form method='post' action='/auto/cartoon/writer/install' style='margin-top:12px' "
                    f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                    f"<input type='hidden' name='which' value='{k}'>"
                    f"<button class='{'ae-big' if k == s['recommend'] and not switch else 'btn2'}'><span>{label}</span> "
                    f"<span translate='no'>{e(s['labels'][k])}</span> <span translate='no'>({gb:.1f}</span> <span>GB)</span></button>"
                    f"<div class='muted' style='font-size:13px;margin-top:4px'>{e(why[k])}"
                    + (f" <span>This PC's graphics card has</span> <span translate='no'>{s['vram_gb']:g}</span> <span>GB.</span>"
                       if k == "big" and s.get("vram_gb") else "")
                    + (" <span>The model in use now is deleted after.</span>" if switch else "")
                    + "</div>"
                    + ("<div class='errbox' style='margin-top:6px'>Not enough free space on the disk of the data folder.</div>" if low else "")
                    + "</form>")
        return out

    @app.get("/auto/cartoon")
    def cartoon_home():
        mine = cj.films()
        rows = "".join(_film_row(j) for j in mine[:6])     # (the newest first; the rest folded away)
        if len(mine) > 6:
            rows += (f"<details style='margin-top:8px'><summary><span>All cartoons and stories</span> <span translate='no'>"
                     f"({len(mine)})</span></summary>{''.join(_film_row(j) for j in mine[6:])}</details>")
        help_ = _help()
        body = (f"{CSS}<div class='pagehead'><div class='eyebrow'>Create</div><h1>Cartoon Studio</h1>"
                f"<div class='lead'>A short 2D cartoon made by MediaEngine: its own characters (the same in every episode), "
                f"scenes, schemes of money and charts, the characters' voices and captions - one MP4. Change any line, "
                f"background or feeling and make it again.</div>"
                + f"</div>{_READY}{_writer_card()}"
                + (f"<div class='card' id='films' style='margin-top:14px'><h2 style='margin-top:0'>My cartoons and stories</h2>{rows}</div>" if rows else "")
                + f"{_study_card()}"
                f"<div class='card' id='new' style='margin-top:14px'><h2 style='margin-top:0'>New cartoon</h2>"
                f"<form method='post' action='/auto/cartoon/new' onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<b>Story</b><div class='muted' style='font-size:13px'>The example below - change it or write your own.</div>{help_}"
                f"<textarea name='text' rows='16' style='width:100%;font-family:Consolas,monospace;font-size:13px' translate='no'>"
                f"{e(T.ROAD_TEXT)}</textarea>"
                f"<details style='margin-top:6px'><summary>A script as JSON instead</summary>"
                f"<textarea name='script' rows='6' style='width:100%' placeholder='Paste a script here (only for \"My script\")'></textarea></details>"
                f"<div class='ct-choices' style='margin-top:8px'><b>Format</b><br>{_format_choice('vertical')}</div>"
                f"{_drawing_choice()}{_voices_choice()}{_captions_choice()}{_camera_choice()}{_music_choice()}"
                f"<div style='margin-top:12px'><button class='ae-big'>Make the cartoon</button></div></form></div>")
        return page("Cartoon Studio", body, _POLL_JS + _PICK_JS + _MUSIC_JS)

    def _make(script: dict, f, keep: dict | None = None) -> str:
        """keep: the music of the film made again (used when the form says nothing about music)."""
        script = dict(script)
        if f.get("format") in F.FORMATS:
            script["format"] = f.get("format")
        cap = {"style": f.get("style") or "pop"} if f.get("captions") == "1" else None
        if f.get("camera_form") == "1":                    # (a form without the choice keeps the film's camera)
            script["camera"] = "close" if f.get("camera") == "1" else "still"
        if f.get("pace") in F.PACES:
            script["pace"] = f.get("pace")
        if f.get("drawing") in STYLES:
            script["drawing"] = f.get("drawing")
        if f.get("music") in ("made", "file", "none"):
            kind = f.get("music")
            music = {"kind": kind, "mood": f.get("mood") or "light", "path": f.get("music_path") or ""} if kind != "none" else None
        else:
            music = dict(keep) if isinstance(keep, dict) else None
        return cj.new_make(script, f.get("voices") == "1", cap, music=music)

    @app.post("/auto/cartoon/new")
    def cartoon_new():
        f = request.form
        try:
            if f.get("story") == "own" or str(f.get("script") or "").strip():
                try:
                    script = json.loads(f.get("script") or "")
                except ValueError:
                    raise F.FilmError("The script is not valid JSON.")
                if not isinstance(script, dict):
                    raise F.FilmError("The script is not valid JSON.")
            elif str(f.get("text") or "").strip():
                script = T.parse(f.get("text") or "")
                if not script["scenes"]:
                    raise F.FilmError("The story has no scenes: start each scene with == and its background.")
                sj = _job(str(f.get("story_job") or ""))
                if sj and sj.get("kind") == "cartoon_write" and sj.get("mode") in ("adapt", "translate"):
                    script["language"] = sj.get("lang") or script.get("language") or "en"   # (a film in another language:
                    if isinstance(sj.get("cast"), dict):                                   # its own people and voices)
                        script = F.keep_cast(script, sj["cast"])
                    if (sj.get("make") or {}).get("pace") and not f.get("pace"):
                        script["pace"] = sj["make"]["pace"]
            else:
                script = copy.deepcopy(stories.STORIES.get(f.get("story") or "", stories.ROAD_CONTRACT))
            jid = _make(script, f)
        except (F.FilmError, vo.VoiceError) as exc:
            return err_page(str(exc), "/auto/cartoon")
        return redirect("/auto/cartoon#films" if jid else "/auto/cartoon")

    @app.get("/auto/cartoon/<jid>")
    def cartoon_one(jid):
        if not re.fullmatch(_JOB_ID, jid):
            return err_page("No such job.", "/auto/cartoon")
        try:
            j = vo.read_job(jid)
        except vo.VoiceError:
            return err_page("No such job.", "/auto/cartoon")
        if not str(j.get("kind") or "").startswith("cartoon_"):
            return err_page("No such job.", "/auto/cartoon")
        if j.get("kind") == "cartoon_write":
            return _story_page(j)
        if j.get("kind") == "cartoon_study":
            return _study_page(j)
        try:
            film = F.check_script(cj.script_of(jid))
        except F.FilmError as exc:
            return err_page(str(exc), "/auto/cartoon")
        who = "".join(f"<option value='{k}' translate='no'>{e(c.get('name') or k)}</option>" for k, c in film["cast"].items())
        tall = film["format"] == "vertical"
        scenes = ""
        for i, s in enumerate(film["scenes"]):
            bgsel = "".join(f"<option value='{k}' {'selected' if k == s['bg'] else ''}>{e(v)}</option>" for k, v in BG_LABELS.items())
            lines = ""
            for jn, ln in enumerate(s["lines"]):
                wsel = who.replace(f"value='{ln['who']}'", f"value='{ln['who']}' selected")
                esel = "".join(f"<option value='{k}' {'selected' if k == (ln.get('emotion') or '') else ''}>{e(v)}</option>"
                               for k, v in EMO_LABELS.items())
                psel = "".join(f"<option value='{k}' {'selected' if k == (ln.get('pose') or '') else ''}>{e(v)}</option>"
                               for k, v in POSE_LABELS.items())
                lines += (f"<div class='ct-line' data-at='{jn}'><select name='w_{i}_{jn}'>{wsel}</select>"
                          f"<input name='t_{i}_{jn}' value='{e(ln['text'])}' maxlength='400' translate='no'>"
                          f"<select name='e_{i}_{jn}' title='Feeling'>{esel}</select><select name='p_{i}_{jn}' title='Gesture'>{psel}</select>"
                          f"<span class='ct-ops'><button type='button' class='btn2' data-add title='Add a line after this one'>+</button>"
                          f"<button type='button' class='btn2' data-del title='Remove this line (press again to keep it)'>✕</button>"
                          f"<input type='hidden' name='x_{i}_{jn}' value=''></span></div>")
            scenes += (f"<div class='ct-scene' data-scene='{i}'>"
                       f"<img class='ct-thumb{' tall' if tall else ''}' src='/auto/cartoon/{jid}/scene/{i}.jpg' alt='' loading='lazy'>"
                       f"<div style='min-width:0'><div class='ct-row'><b><span>Scene</span> <span translate='no' data-num>{i + 1}</span></b>"
                       f"<select name='bg_{i}' title='Background'>{bgsel}</select>"
                       f"<span class='ct-ops' style='margin-left:auto'>"
                       f"<button type='button' class='btn2' data-up title='Move the scene up'>↑</button>"
                       f"<button type='button' class='btn2' data-down title='Move the scene down'>↓</button>"
                       f"<button type='button' class='btn2' data-drop title='Remove the scene (press again to keep it)'>✕</button></span></div>"
                       f"<div data-lines data-last='{len(s['lines']) - 1}'>{lines}</div>"
                       f"<button type='button' class='btn2' data-addend style='margin-top:4px'>+ Line</button></div></div>")
        new_line = (f"<template id='ctNew'><div class='ct-line ct-new'><select data-f='w'>{who}</select>"
                    f"<input data-f='t' maxlength='400' placeholder='What is said' translate='no'>"
                    f"<select data-f='e' title='Feeling'>{''.join(f'<option value={chr(39)}{k}{chr(39)}>{e(v)}</option>' for k, v in EMO_LABELS.items())}</select>"
                    f"<select data-f='p' title='Gesture'>{''.join(f'<option value={chr(39)}{k}{chr(39)}>{e(v)}</option>' for k, v in POSE_LABELS.items())}</select>"
                    f"<span class='ct-ops'><button type='button' class='btn2' data-add title='Add a line after this one'>+</button>"
                    f"<button type='button' class='btn2' data-del title='Remove this line'>✕</button>"
                    f"<input type='hidden' data-f='at' value='-1'></span></div></template>")
        cur_lang = film.get("language") if film.get("language") in LANG_LABELS else "en"
        if W.installed():
            others = "".join(f"<option value='{k}' translate='no'>{e(v)}</option>" for k, v in LANG_LABELS.items() if k != cur_lang)
            lang_box = (f"<form method='post' action='/auto/cartoon/{jid}/language' class='ct-lang' "
                        f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                        f"<div class='ct-row'><b>Language</b><span class='muted'>now</span> <span translate='no'>{e(LANG_LABELS[cur_lang])}</span>"
                        f"<span>→</span><select name='lang'>{others}</select></div>"
                        f"<div class='ct-choices' style='margin-top:4px'>"
                        f"<label><input type='radio' name='how' value='translate' checked> Translate: the same people and story</label>"
                        f"<label><input type='radio' name='how' value='adapt'> Retell for viewers in a country (their names, money, offices)</label>"
                        f"<input name='country' maxlength='60' placeholder='(a country)' style='width:170px'></div>"
                        f"<label style='display:block;margin-top:4px'><input type='checkbox' name='read' value='1'> Let me read the "
                        f"story before the cartoon is made</label>"
                        f"<div style='margin-top:8px'><button>Make it in this language</button></div>"
                        f"<div class='muted' style='font-size:13px;margin-top:4px'>The free model on this PC translates it (a minute or "
                        f"two), then the cartoon is made with the same people, voices and look. This version stays.</div></form>")
        else:
            lang_box = ("<div class='ct-lang'><b>Language</b> <span class='muted'>To make this cartoon in another language, "
                        "install the story writer (a free model on this PC):</span> <a href='/auto/cartoon#writer'>Write a story</a></div>")
        res = j.get("result") or {}
        video = (f"<div class='ct-big'><video controls preload='metadata' src='/auto/cartoon/{jid}/film.mp4'></video></div>"
                 if j["state"] == "done" else _block(j, _state_html(j)))
        body = (f"{CSS}<div class='pagehead'><div class='eyebrow'><a href='/auto/cartoon'>Cartoon Studio</a></div>"
                f"<h1 translate='no'>{e(j.get('title') or film['title'])}</h1></div>{_READY}"
                f"<div class='card'>{video}"
                + (f"<div class='muted' style='font-size:13px;margin-top:6px'><span>Saved in</span> <span class='ae-path' translate='no'>"
                   f"{e(res.get('saved') or '')}</span></div>" if res.get("saved") else "")
                + f"</div><div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Change and make again</h2>{lang_box}"
                f"<form method='post' action='/auto/cartoon/{jid}/again' data-dirty-watch "
                f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<div class='ct-row' style='margin-top:10px'><b>Title</b><input name='title' value='{e(film['title'])}' maxlength='120' "
                f"translate='no' style='flex:1;min-width:200px'></div>"
                f"<input type='hidden' name='order' id='ctOrder' value='{','.join(str(i) for i in range(len(film['scenes'])))}'>"
                f"<div id='ctScenes'>{scenes}</div>{new_line}"
                f"<div class='ct-choices' style='margin-top:8px'><b>Format</b><br>{_format_choice(film['format'])}</div>"
                f"{_drawing_choice(film.get('drawing') or 'flat')}"
                f"{_voices_choice()}{_captions_choice()}{_camera_choice(film.get('camera') != 'still', film.get('pace') or '')}{_music_choice(j.get('music'))}"
                f"<div style='margin-top:12px'><button class='ae-big'>Make it again</button></div></form>"
                f"<details style='margin-top:12px'><summary>The whole story as text</summary>"
                f"<form method='post' action='/auto/cartoon/{jid}/again' onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<textarea name='text' rows='18' style='width:100%;font-family:Consolas,monospace;font-size:13px' translate='no'>"
                f"{e(T.to_text(cj.script_of(jid)))}</textarea>"
                f"<input type='hidden' name='format' value='{e(film['format'])}'><input type='hidden' name='captions' value='1'>"
                f"<input type='hidden' name='drawing' value='{e(film.get('drawing') or 'flat')}'>"
                f"<input type='hidden' name='camera_form' value='1'>"
                + ("<input type='hidden' name='camera' value='1'>" if film.get("camera") != "still" else "")
                + f"<input type='hidden' name='pace' value='{e(film.get('pace') or '')}'>"
                + ("<input type='hidden' name='voices' value='1'>" if j.get("voices") else "")
                + f"<div style='margin-top:8px'><button>Make it again from this text</button></div></form></details>"
                + f"<details style='margin-top:8px'><summary>The whole script (JSON)</summary>"
                f"<textarea readonly rows='12' style='width:100%' translate='no'>{e(json.dumps(cj.script_of(jid), ensure_ascii=False, indent=1))}</textarea>"
                f"</details></div>")
        return page("Cartoon Studio", body, _POLL_JS + _MUSIC_JS + _EDIT_JS)

    def _story_page(j: dict):
        jid, res = j["id"], j.get("result") or {}
        asked = {"topic": "Topic", "text": "Retelling a text", "adapt": "Retelling a story for another country",
                 "translate": "A cartoon in another language", "video": "Retelling a video"}.get(j.get("mode"), "")
        what = str(j.get("topic") or j.get("source") or "")
        if j.get("mode") == "video":
            heard = vo._job_dir(jid) / "heard.txt"
            what = str(j.get("video") or "") + ("\n\n" + heard.read_text("utf-8")[:3000] if heard.is_file() else "")
        head = (f"{CSS}<div class='pagehead'><div class='eyebrow'><a href='/auto/cartoon'>Cartoon Studio</a></div>"
                f"<h1><span>Story:</span> <span translate='no'>{e(j.get('title') or '')}</span></h1>"
                f"<div class='muted' style='font-size:13px'><span>{e(asked)}</span> · <span translate='no'>"
                f"{e(LANG_LABELS.get(j.get('lang'), ''))}</span>" + (f" · <span translate='no'>{e(j['country'])}</span>" if j.get("country") else "")
                + _rhythm_link(j.get("style"))
                + f"</div></div>{_READY}")
        if j["state"] != "done":
            body = (f"<div class='card'>{_block(j, _state_html(j) or '')}"
                    f"<details style='margin-top:8px'><summary class='muted'>What was asked</summary><div class='muted' "
                    f"style='white-space:pre-wrap;font-size:13px' translate='no'>{e(what[:1500])}</div></details></div>")
            return page("Cartoon Studio", head + body, _POLL_JS + _MUSIC_JS)
        story = W.story_of(jid)
        try:
            notes = (vo._job_dir(jid) / "notes.txt").read_text("utf-8") if j.get("mode") == "video" else ""
        except OSError:
            notes = ""
        fmt = j.get("format") or "vertical"
        note = (f"<div class='callout card' style='margin:8px 0'>The model's story is shorter or simpler than asked: read it and "
                f"add what is missing before making the cartoon.</div>" if res.get("note") else "")
        body = (f"<div class='card'><h2 style='margin-top:0'>The story</h2>{note}{_film_of_story(res)}"
                f"<div class='muted' style='font-size:13px'>Read it, change what you like (the words, the people, the scenes), then "
                f"make the cartoon. How the text is written: see the help below.</div>{_help()}"
                f"<form method='post' action='/auto/cartoon/new' onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<textarea name='text' rows='22' style='width:100%;font-family:Consolas,monospace;font-size:13px' translate='no'>{e(story)}</textarea>"
                f"<input type='hidden' name='story_job' value='{e(jid)}'>"
                f"<div class='ct-choices' style='margin-top:8px'><b>Format</b><br>{_format_choice(fmt)}</div>"
                f"{_drawing_choice((j.get('make') or {}).get('drawing') or 'flat')}"
                f"{_voices_choice()}{_captions_choice()}{_camera_choice(True, R.pace_of(j.get('style')))}{_music_choice()}"
                f"<div style='margin-top:12px'><button class='ae-big'>Make the cartoon</button></div></form></div>"
                f"<div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Not quite right?</h2>"
                f"<div class='ct-row'><form method='post' action='/auto/cartoon/{jid}/rewrite' style='margin:0' "
                f"onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<button>Write another version</button></form>{_delete(j)}</div>"
                f"<details style='margin-top:10px'><summary>Another language or country</summary>"
                f"{_adapt_form(story, fmt, j.get('title') or '', j.get('lang') or 'en')}</details>"
                + (f"<details style='margin-top:8px'><summary>The facts noted from the video</summary><div class='muted' "
                   f"style='white-space:pre-wrap;font-size:13px' translate='no'>{e(notes[:4000])}</div>"
                   f"<div class='muted' style='font-size:13px;margin-top:4px'>Noted by the model from what Whisper heard: "
                   f"check them before you publish.</div></details>" if notes else "")
                + f"<details style='margin-top:8px'><summary class='muted'>What was asked</summary><div class='muted' "
                f"style='white-space:pre-wrap;font-size:13px' translate='no'>{e(what[:1500])}</div></details></div>")
        return page("Cartoon Studio", head + body, _POLL_JS + _MUSIC_JS)

    def _clock(t) -> str:
        t = max(0.0, float(t or 0))
        return f"{int(t // 60)}:{t % 60:04.1f}"

    def _write_with(ref: str, st: dict, button: str) -> str:
        """The form that writes a story with a study's or an author style's rhythm."""
        if not W.installed():
            return ("<div class='muted'>To write a story with this rhythm, install the story writer: "
                    "<a href='/auto/cartoon#writer'>Cartoon Studio</a>.</div>")
        lens = dict(LEN_LABELS)
        near = str(st.get("secs") or 75)
        opts = (f"<option value='{near}' selected translate='no'>{near} s</option>" if near not in lens else "") + "".join(
            f"<option value='{k}' {'selected' if k == near else ''}>{e(v)}</option>" for k, v in LEN_LABELS)
        return (f"<form method='post' action='/auto/cartoon/write' onsubmit=\"setTimeout(()=>this.querySelectorAll('button').forEach(x=>x.disabled=true),0)\">"
                f"<input type='hidden' name='ref' value='{e(ref)}'>"
                f"<b>What is the new story about?</b><textarea name='about' rows='3' maxlength='5000' style='width:100%' "
                f"placeholder='Why a city hospital pays three times more for the same medicine'></textarea>"
                f"<div class='ct-row' style='margin-top:8px'><span>Language</span><select name='lang'>{_lang_select()}</select>"
                f"<span>Viewers in</span><input name='country' maxlength='60' placeholder='(a country, if it matters)' style='width:200px'>"
                f"<span>Length</span><select name='secs'>{opts}</select></div>"
                f"<div class='ct-choices' style='margin-top:8px'><b>Format</b><br>{_format_choice(st.get('format') or 'vertical')}</div>"
                f"<div style='margin-top:10px'><button class='ae-big'>{e(button)}</button></div>"
                f"<div class='muted' style='font-size:13px;margin-top:6px'><span>The story is new: only the rhythm is taken -</span> "
                f"<span translate='no'>{int(st.get('scenes') or 0)}</span> <span>scenes, the pace of the words and how soon it speaks.</span></div></form>")

    def _study_page(j: dict):
        jid, ref = j["id"], R.reference_of(j["id"])
        head = (f"{CSS}<div class='pagehead'><div class='eyebrow'><a href='/auto/cartoon'>Cartoon Studio</a></div>"
                f"<h1><span>Study:</span> <span translate='no'>{e(j.get('title') or '')}</span></h1>"
                f"<div class='muted ae-path' style='font-size:13px' translate='no'>{e(j.get('video') or '')}</div></div>{_READY}")
        if j["state"] != "done" or not ref:
            body = f"<div class='card'>{_block(j, _state_html(j) or '')}<div style='margin-top:8px'>{_delete(j)}</div></div>"
            return page("Cartoon Studio", head + body, _POLL_JS)

        def row(label: str, value: str) -> str:
            return f"<div class='muted'>{e(label)}</div><div>{value}</div>"

        def num(x) -> str:
            return f"<span translate='no'>{e(str(x))}</span>"
        nums = (row("Length", num(f"{float(ref['duration']):g}") + " <span>s</span> · " + num(f"{ref['width']}×{ref['height']}")
                    + " · <span>" + e("vertical" if ref.get("format") == "vertical" else "wide") + "</span>")
                + row("Shots", num(len(ref.get("shots") or [])) + " · " + num(f"{float(ref['cuts_per_min']):g}") + " <span>cuts a minute</span>")
                + row("A shot lasts", "<span>on average</span> " + num(f"{float(ref['shot_avg']):g}") + " <span>s</span> · "
                      "<span>from</span> " + num(f"{float(ref['shot_min']):g}") + " <span>to</span> " + num(f"{float(ref['shot_max']):g}")
                      + " <span>s</span>"))
        if ref.get("listened"):
            between = {"music": "music or sounds", "quiet": "silence"}.get(ref.get("between") or "", "")
            nums += (row("Speech", num(f"{float(ref['wps']):g}") + " <span>words a second</span> · " + num(f"{round(100 * float(ref['talk_share']))}%")
                         + " <span>of the time someone speaks</span>")
                     + row("The first words", "<span>after</span> " + num(f"{float(ref['first_words_at'] or 0):g}") + " <span>s</span>"
                           + (f" · <span translate='no'>«{e(ref.get('opening') or '')}»</span>" if ref.get("opening") else ""))
                     + (row("Between the words", f"<span>{e(between)}</span>") if between else ""))
        else:
            why = ref.get("listen_error") or ("This video has no sound." if j.get("sound") is False else
                                              "The words were not listened to (the voice add-on was not chosen)."
                                              if not j.get("listen") else "")
            nums += row("Speech", f"<span>{e(why or 'Nothing is said in it.')}</span>")
        chips = "".join(f"<span class='ct-chip'><i style='background:{e(c['hex'])}'></i><span translate='no'>{e(c['hex'])} · "
                        f"{round(100 * float(c['share']))}%</span></span>" for c in ref.get("palette") or [])
        write = _write_with(jid, R.style_of(jid), "Write a story with this rhythm")
        shots = ""
        for i, s in enumerate(ref.get("shots") or []):
            img = (f"<img loading='lazy' src='/auto/cartoon/{jid}/frame/{e(s['frame'])}' alt=''>" if s.get("frame") else "")
            shots += (f"<div class='ct-shot' id='shot{i + 1}'>{img}<div style='margin-top:4px'><b translate='no'>{i + 1}</b> · <span translate='no'>"
                      f"{_clock(s['s'])}–{_clock(s['e'])} ({float(s['e']) - float(s['s']):.1f} s)</span></div>"
                      + (f"<div class='muted' translate='no'>{e(s['text'])}</div>" if s.get("text") else "") + "</div>")
        strip = "".join(f"<a href='#shot{i + 1}' style='flex:{max(0.05, float(s['e']) - float(s['s'])):.2f};"
                        f"background:{e(s.get('color') or '#888888')}' title='{i + 1}: {float(s['e']) - float(s['s']):.1f} s'></a>"
                        for i, s in enumerate(ref.get("shots") or []))
        body = (f"<div class='card'><h2 style='margin-top:0'>The rhythm</h2>"
                f"<div class='muted' style='font-size:13px'>The shots one after another, as long as they last:</div>"
                f"<div class='ct-strip{' dense' if len(ref.get('shots') or []) > 120 else ''}'>{strip}</div>"
                f"<div class='ct-nums' style='margin-top:10px'>{nums}</div>"
                + (f"<div style='margin-top:10px'><b>The main colours</b><div>{chips}</div></div>" if chips else "")
                + f"</div><div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Write a story with this rhythm</h2>{write}</div>"
                f"<div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Storyboard</h2>"
                f"<div class='muted' style='font-size:13px;margin-bottom:8px'>A picture from the middle of each shot"
                + (", with what is said in it" if ref.get("listened") else "") + f".</div><div class='ct-board'>{shots}</div>"
                f"<div class='ct-row' style='margin-top:12px'>{_delete(j)}</div></div>")
        return page("Cartoon Studio", head + body, _POLL_JS + _PICK_JS)

    SKIN_L = dict(zip(ch.SKINS, ("very light", "light", "light tan", "tan", "brown", "dark brown", "very dark")))
    HAIR_L = dict(zip(ch.HAIRS, ("black", "dark brown", "brown", "light brown", "blond", "grey", "white", "red", "jet black")))
    CLOTH_L = dict(zip(ch.CLOTHES, ("navy", "green", "wine", "grey", "purple", "teal", "mustard", "forest green", "brown", "dark blue")))
    STYLE_L = {"short": "short", "side": "side parting", "spiky": "spiky", "bob": "bob", "curly": "curly", "ponytail": "ponytail",
               "bald": "bald", "long": "long", "buzz": "very short"}
    OUTFIT_L = {"suit": "suit and tie", "blazer": "jacket", "shirt": "shirt", "hoodie": "hoodie", "vest": "work vest",
                "dress": "dress", "sweater": "sweater", "coat": "doctor's white coat"}
    BEARD_L = {"none": "none", "mustache": "mustache", "stubble": "stubble", "full": "beard"}

    def _sel(name: str, options: dict, current, swatch: bool = False) -> str:
        return (f"<select name='{name}'>" + "".join(
            f"<option value='{e(k)}' {'selected' if k == current else ''}>{e(v)}</option>" for k, v in options.items()) + "</select>"
            + (f" <span class='ct-sw' style='background:{e(str(current))}'></span>" if swatch and current else ""))

    def _who(key: str, en: dict) -> dict:
        c = ch.make(en.get("name") or key, en.get("role") or "")
        c.update(en.get("look") or {})
        return c

    @app.get("/auto/cartoon/characters")
    def cartoon_characters():
        lib = L.load()
        rows = ""
        for key, en in sorted(lib.items(), key=lambda kv: (-int(kv[1].get("films") or 0), kv[1].get("name") or "")):
            c = _who(key, en)
            rows += (f"<div class='ct-who'><img src='/auto/cartoon/characters/{e(key)}.png' alt=''><div>"
                     f"<b translate='no'>{e(en.get('name') or key)}</b>"
                     f"<div class='muted' style='font-size:13px' translate='no'>{e(en.get('role') or '')}</div>"
                     f"<div class='muted' style='font-size:13px'><span>Films:</span> <span translate='no'>{int(en.get('films') or 0)}</span>"
                     + (" · <span>narrator</span>" if en.get("narrator") and not en.get("host") else "")
                     + (" · <b>the host</b>" if en.get("host") else "") + "</div>"
                     f"<a class='btn btn2' style='margin-top:6px' href='/auto/cartoon/characters/{e(key)}'>Change</a></div></div>")
        body = (f"{CSS}<div class='pagehead'><div class='eyebrow'><a href='/auto/cartoon'>Cartoon Studio</a></div><h1>Characters</h1>"
                f"<div class='lead'>Everyone your cartoons have used. A character keeps its look and its voice in every new "
                f"film whose story names it - change them here.</div></div>"
                + (f"<div class='card'><div class='ct-cast'>{rows}</div></div>" if rows else
                   "<div class='card'><div class='muted'>No characters yet: they are added when a cartoon is made - or "
                   "add one below.</div></div>")
                + "<div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Add a character</h2>"
                  "<form method='post' action='/auto/cartoon/characters/add-one' class='ct-row'>"
                  "<input name='name' maxlength='40' placeholder='Name (as stories will call it)' style='width:220px' required>"
                  "<input name='role' maxlength='60' placeholder='Role (journalist, mayor …)' style='width:200px'>"
                  "<select name='female'><option value=''>a man or a woman (from the name)</option>"
                  "<option value='1'>a woman</option><option value='0'>a man</option></select>"
                  "<button>Add</button></form><div class='muted' style='font-size:13px;margin-top:6px'>Its look is drawn "
                  "from its name; change it on its page. A story that names it uses this look and voice.</div></div>")
        return page("Cartoon Studio", body)

    @app.post("/auto/cartoon/characters/add-one")
    def cartoon_character_new():
        f = request.form
        try:
            key = L.add(f.get("name") or "", f.get("role") or "", f.get("female") == "1" if f.get("female") in ("0", "1") else None)
        except ValueError as exc:
            return err_page(str(exc), "/auto/cartoon/characters")
        except OSError:
            return err_page(BUSY, "/auto/cartoon/characters")
        return redirect(f"/auto/cartoon/characters/{key}")

    @app.get("/auto/cartoon/characters/<key>.png")
    def cartoon_character_png(key):
        en = L.load().get(key)
        if not en:
            return ("", 404)
        from flask import Response
        return Response(L.portrait(_who(key, en)), mimetype="image/png", headers={"Cache-Control": "no-store"})

    @app.get("/auto/cartoon/drawing/<name>.jpg")
    def cartoon_drawing_jpg(name):
        if name not in STYLES:
            return ("", 404)
        from flask import Response
        return Response(F.style_sample(name), mimetype="image/jpeg", headers={"Cache-Control": "max-age=3600"})

    @app.get("/auto/cartoon/characters/<key>")
    def cartoon_character(key):
        en = L.load().get(key)
        if not en:
            return err_page("No such character.", "/auto/cartoon/characters")
        c = _who(key, en)
        look = (f"<div class='ct-look'>"
                f"<span>Who</span>{_sel('female', {'0': 'a man', '1': 'a woman'}, '1' if c.get('female') else '0')}"
                f"<span>Skin</span>{_sel('skin', SKIN_L, c.get('skin'), True)}"
                f"<span>Hair</span>{_sel('hair', HAIR_L, c.get('hair'), True)}"
                f"<span>Hairstyle</span>{_sel('hair_style', STYLE_L, c.get('hair_style'))}"
                f"<span>Beard</span>{_sel('beard', BEARD_L, c.get('beard') or 'none')}"
                f"<span>Clothes</span>{_sel('outfit', OUTFIT_L, c.get('outfit'))}"
                f"<span>Colour of the clothes</span>{_sel('cloth', {**CLOTH_L, '#f4f6f8': 'white'}, c.get('cloth'), True)}"
                f"<span>Glasses</span><label><input type='checkbox' name='glasses' value='1' {'checked' if c.get('glasses') else ''}> glasses</label>"
                f"<span>Hard hat</span><label><input type='checkbox' name='hardhat' value='1' {'checked' if c.get('hat') == 'hardhat' else ''}> a builder's hard hat</label>"
                f"</div>")
        body = (f"{CSS}<div class='pagehead'><div class='eyebrow'><a href='/auto/cartoon/characters'>Characters</a></div>"
                f"<h1 translate='no'>{e(en.get('name') or key)}</h1></div>"
                f"<div class='card'><div class='ct-row' style='align-items:flex-start;gap:18px'>"
                f"<img src='/auto/cartoon/characters/{e(key)}.png' alt='' style='width:192px;height:240px;border-radius:10px'>"
                f"<form method='post' action='/auto/cartoon/characters/{e(key)}' style='flex:1;min-width:280px'>"
                f"<div class='ct-look'><span>Role</span><input name='role' maxlength='60' value='{e(en.get('role') or '')}' translate='no'></div>"
                f"<h3>Appearance</h3>{look}<h3>Voice</h3>"
                f"<textarea name='voice' rows='2' maxlength='300' style='width:100%' translate='no' placeholder="
                f"'A man in his forties, low and calm, a little sly (empty: the program’s own voice for the narrator)'>"
                f"{e(en.get('voice') or '')}</textarea>"
                f"<div class='muted' style='font-size:13px'>A voice from a description is made once with the voice add-on and kept: "
                f"the character sounds the same in every film. A new description makes a new voice.</div>"
                f"<input type='hidden' name='host_form' value='1'><label style='display:block;margin-top:10px'>"
                f"<input type='checkbox' name='host' value='1' {'checked' if en.get('host') else ''}> The host of my films: "
                f"the story writer gives every new story this narrator</label>"
                f"<div style='margin-top:12px' class='ct-row'><button class='ae-big'>Save</button>"
                f"<a class='btn btn2' href='/auto/cartoon/characters'>Back</a></div></form></div>"
                f"<form method='post' action='/auto/cartoon/characters/{e(key)}/forget' style='margin-top:12px' "
                f"onsubmit=\"return confirm(window.ME_L?ME_L('Forget this character? Films made stay as they are.'):"
                f"'Forget this character? Films made stay as they are.')\"><button class='btn2'>Forget the character</button></form></div>")
        return page("Cartoon Studio", body)

    @app.post("/auto/cartoon/characters/<key>")
    def cartoon_character_save(key):
        f = request.form
        if key not in L.load():
            return err_page("No such character.", "/auto/cartoon/characters")
        look = {"female": f.get("female") == "1", "glasses": f.get("glasses") == "1",
                "hat": "hardhat" if f.get("hardhat") == "1" else "none"}
        for name, allowed in (("skin", ch.SKINS), ("hair", ch.HAIRS), ("hair_style", list(STYLE_L)), ("beard", list(BEARD_L)),
                              ("outfit", list(OUTFIT_L)), ("cloth", ch.CLOTHES + ["#f4f6f8"])):
            if f.get(name) in allowed:
                look[name] = f.get(name)
        if look.get("female"):
            look["beard"] = "none"
        try:
            L.update(key, role=f.get("role") if f.get("role") is not None else None, look=look,
                     voice=f.get("voice") if f.get("voice") is not None else None)
            if f.get("host_form") == "1":
                L.set_host(key, f.get("host") == "1")
        except KeyError:
            return err_page("No such character.", "/auto/cartoon/characters")
        except OSError:
            return err_page(BUSY, f"/auto/cartoon/characters/{key}")
        return redirect(f"/auto/cartoon/characters/{key}")

    @app.post("/auto/cartoon/characters/<key>/forget")
    def cartoon_character_forget(key):
        try:
            L.forget(key)
        except OSError:
            return err_page(BUSY, "/auto/cartoon/characters")
        return redirect("/auto/cartoon/characters")

    @app.post("/auto/cartoon/study")
    def cartoon_study():
        try:
            jid = R.new_study(request.form.get("video") or "", request.form.get("listen") == "1")
        except (R.StudyError, vo.VoiceError) as exc:
            return err_page(str(exc), "/auto/cartoon")
        return redirect(f"/auto/cartoon/{jid}")

    @app.post("/auto/cartoon/style/new")
    def cartoon_style_new():
        f = request.form
        src = str(f.get("source") or "")
        if not re.fullmatch("download:" + _JOB_ID, src):
            src = ""
        if src and R.style_of_download(src.split(":", 1)[1]):      # (pressed twice: the one made)
            return redirect(f"/auto/cartoon/style/{R.style_of_download(src.split(':', 1)[1])['id']}")
        try:
            sid = R.new_style(f.getlist("ref")[:R.MAX_STYLE_VIDEOS + 1], f.get("name") or "", src)
        except R.StudyError as exc:
            return err_page(str(exc), "/auto/cartoon#study")
        except OSError:
            return err_page("The style could not be saved (the data folder). Try again.", "/auto/cartoon#study")
        return redirect(f"/auto/cartoon/style/{sid}")

    @app.post("/auto/cartoon/style/<sid>/delete")
    def cartoon_style_delete(sid):
        try:
            R.delete_style(sid)
        except OSError:
            return err_page("The style could not be removed (the data folder). Try again.", f"/auto/cartoon/style/{sid}")
        return redirect("/auto/cartoon#study")

    @app.get("/auto/cartoon/style/<sid>")
    def cartoon_style_page(sid):
        ent = R.style_entry(sid)
        if not ent:
            return err_page("This style is not there any more.", "/auto/cartoon#study")
        st = R.author_style(sid)
        name = ent.get("name") or ""
        head = (f"{CSS}<div class='pagehead'><div class='eyebrow'><a href='/auto/cartoon'>Cartoon Studio</a></div>"
                + (f"<h1><span>Style:</span> <span translate='no'>{e(name)}</span></h1>" if name else "<h1>A common style</h1>")
                + f"<div class='lead'><span>Studied videos taken together:</span> <span translate='no'>{len(ent.get('refs') or [])}</span>"
                f". <span>Their middle is taken - one video that is different does not change it much.</span></div></div>")
        forget = (f"<form method='post' action='/auto/cartoon/style/{e(sid)}/delete' class='ct-row' style='margin-top:12px'>"
                  f"<button class='btn2'>Forget this style</button><span class='muted' style='font-size:13px'>(the videos and "
                  f"their studies stay)</span></form>")
        if not st:
            return page("Cartoon Studio", head + "<div class='card'><div class='muted'>Its videos are not studied any more (their "
                                                 f"studies were removed).</div>{forget}</div>")

        def row(label: str, value: str) -> str:
            return f"<div class='muted'>{e(label)}</div><div>{value}</div>"

        def num(x) -> str:
            return f"<span translate='no'>{e(str(x))}</span>"

        def span(a, b) -> str:
            return "" if a == b else f" · <span>from</span> {num(f'{a:g}')} <span>to</span> {num(f'{b:g}')}"
        sp = st.get("spread") or {}
        nums = row("A shot lasts", "<span>on average</span> " + num(f"{st['shot_avg']:g}") + " <span>s</span>"
                   + (span(*sp["shot_avg"]) + " <span>s</span>" if span(*sp["shot_avg"]) else ""))
        if sp.get("wps"):
            nums += row("Speech", num(f"{st['wps']:g}") + " <span>words a second</span>" + span(*sp["wps"]))
            if sp.get("first_at"):
                nums += row("The first words", "<span>after</span> " + num(f"{st['first_at']:g}") + " <span>s</span>"
                            + (span(*sp["first_at"]) + " <span>s</span>" if span(*sp["first_at"]) else ""))
            if sp.get("openings"):
                nums += row("It opens with", f"<span>{'a question' if st.get('opens') == 'question' else 'a statement'}</span>"
                            f" · <span translate='no'>{int(sp.get('asks') or 0)}/{int(sp['openings'])}</span> <span>open with a question</span>")
        else:
            nums += row("Speech", "<span>Not listened to (studied without the voice add-on).</span>")
        nums += row("Format", f"<span>{e('vertical' if st.get('format') == 'vertical' else 'wide')}</span>")
        chips = "".join(f"<span class='ct-chip'><i style='background:{e(c['hex'])}'></i><span translate='no'>{e(c['hex'])} · "
                        f"{round(100 * float(c['share']))}%</span></span>" for c in st.get("palette") or [])
        vids = ""
        for r in ent.get("refs") or []:
            x = R.reference_of(r)
            if not x:
                continue
            j = _job(r) or {}
            vids += (f"<tr><td><a href='/auto/cartoon/{e(r)}' translate='no'>{e(j.get('title') or r)}</a></td>"
                     f"<td class='n'><span translate='no'>{float(x.get('duration') or 0):.0f}</span> <span>s</span></td>"
                     f"<td class='n'><span translate='no'>{float(x.get('shot_avg') or 0):g}</span> <span>s</span></td>"
                     f"<td class='n' translate='no'>{(str(round(float(x['wps']), 2)) if x.get('listened') else '–')}</td></tr>")
        body = (f"<div class='card'><h2 style='margin-top:0'>The rhythm</h2><div class='ct-nums'>{nums}</div>"
                + (f"<div style='margin-top:10px'><b>The main colours</b><div>{chips}</div></div>" if chips else "")
                + f"</div><div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Write a story in this style</h2>"
                f"{_write_with(sid, st, 'Write a story in this style')}</div>"
                f"<div class='card' style='margin-top:14px'><h2 style='margin-top:0'>Its videos</h2><div style='overflow-x:auto'>"
                f"<table class='ct-vids'><tr><th>Video</th><th class='n'>Length</th><th class='n'>A shot</th>"
                f"<th class='n'>Words a second</th></tr>{vids}</table></div>{forget}</div>")
        return page("Cartoon Studio", head + body, _PICK_JS)

    @app.get("/auto/cartoon/<jid>/frame/<name>")
    def cartoon_frame(jid, name):
        j = _job(jid)
        if not j or j.get("kind") != "cartoon_study" or not re.fullmatch(r"[0-9]{3,5}\.jpg", name):
            return ("", 404)
        p = vo._job_dir(jid) / "frames" / name
        if not p.is_file():
            return ("", 404)
        return send_file(p, mimetype="image/jpeg", max_age=3600)

    @app.post("/auto/cartoon/write")
    def cartoon_write():
        f = request.form
        about = str(f.get("about") or "").strip()
        mode = (f.get("mode") if f.get("mode") == "adapt" else "video" if str(f.get("video") or "").strip()
                else "text" if len(about) > 280 or about.count("\n") >= 2 else "topic")
        try:
            secs = int(f.get("secs") or 75)
        except ValueError:
            secs = 75
        make = ({"voices": True, "captions": f.get("style") or "pop", "music": "made", "mood": f.get("mood") or "light",
                 "camera": "close", "drawing": f.get("drawing") or "flat"} if f.get("make") == "1" else None)
        topics = [x.strip() for x in str(f.get("topics") or "").splitlines() if len(x.strip()) >= 3][:10]
        if topics and mode != "adapt" and (about or str(f.get("video") or "").strip()):
            return err_page("Write either one story's topic (or a text, or a video) or a series of topics - not both.", "/auto/cartoon")
        if topics and mode != "adapt":                     # a series: a story (and its cartoon) for every topic
            style = _style_for_writer(f.get("ref"))
            try:
                for tp in topics:
                    W.new_write("topic", f.get("lang") or "en", f.get("format") or "vertical", secs, topic=tp,
                                country=f.get("country") or "", style=style or None, make=make)
            except (W.WriterError, vo.VoiceError) as exc:
                return err_page(str(exc), "/auto/cartoon")
            return redirect("/auto/cartoon#films")
        try:
            if mode == "adapt":
                lang = f.get("lang") or "en"
                title = str(f.get("title") or "").strip()[:50]
                jid = W.new_write("adapt", lang, f.get("format") or "vertical", secs, source=f.get("source") or "",
                                  country=f.get("country") or "", title=(f"{title} ({LANG_LABELS.get(lang, lang)})" if title else ""))
            else:
                style = _style_for_writer(f.get("ref"))
                jid = W.new_write(mode, f.get("lang") or "en", f.get("format") or "vertical", secs,
                                  topic=about if mode == "topic" else "", source=about if mode == "text" else "",
                                  country=f.get("country") or "", video=f.get("video") or "", style=style or None,
                                  make=make)
        except (W.WriterError, vo.VoiceError) as exc:
            return err_page(str(exc), "/auto/cartoon")
        return redirect(f"/auto/cartoon/{jid}")

    @app.post("/auto/cartoon/<jid>/rewrite")
    def cartoon_rewrite(jid):
        j = _job(jid)
        if not j or j.get("kind") != "cartoon_write":
            return redirect("/auto/cartoon")
        try:
            mode = j.get("mode") or "topic"
            heard = vo._job_dir(jid) / "heard.txt"
            if mode == "video" and heard.is_file():            # (the video is not listened to again)
                mode, j = "text", dict(j, source=heard.read_text("utf-8")[:W.MAX_SOURCE])
                notes = vo._job_dir(jid) / "notes.txt"
                if notes.is_file():
                    j["source"] = notes.read_text("utf-8")
            new = W.new_write(mode, j.get("lang") or "en", j.get("format") or "vertical", j.get("secs") or 75,
                              topic=j.get("topic") or "", source=j.get("source") or "", country=j.get("country") or "",
                              title=j.get("title") or "", video=j.get("video") or "", style=j.get("style"),
                              cast=j.get("cast"), make=dict(j["make"], hold=True) if isinstance(j.get("make"), dict) else None)
        except (W.WriterError, vo.VoiceError) as exc:
            return err_page(str(exc), f"/auto/cartoon/{jid}")
        return redirect(f"/auto/cartoon/{new}")

    @app.post("/auto/cartoon/writer/install")
    def cartoon_writer_install():
        try:
            W.start_install(request.form.get("which") or "")
        except W.WriterError as exc:
            return err_page(str(exc), "/auto/cartoon")
        return redirect("/auto/cartoon")

    @app.post("/auto/cartoon/writer/gpu-again")
    def cartoon_writer_gpu_again():
        W._remember_gpu(None)
        return redirect("/auto/cartoon#writer")

    @app.post("/auto/cartoon/writer/cancel")
    def cartoon_writer_cancel():
        W.cancel_install()
        return redirect("/auto/cartoon")

    @app.post("/auto/cartoon/writer/remove")
    def cartoon_writer_remove():
        try:
            W.remove()
        except W.WriterError as exc:
            return err_page(str(exc), "/auto/cartoon")
        return redirect("/auto/cartoon")

    @app.get("/api/cartoon/writer")
    def cartoon_writer_status():
        s = W.status()
        step = _WR_STEP.get(s.get("step"), "")
        try:
            from .i18n import ui_language
            if ui_language() == "ru":
                from .auto_edit_ru import PHRASES
                step = PHRASES.get(step, step)
        except Exception:
            pass
        return jsonify({k: s.get(k) for k in ("state", "done", "total", "detail", "error", "installed")} | {"step": step})

    @app.post("/auto/cartoon/<jid>/again")
    def cartoon_again(jid):
        if not re.fullmatch(_JOB_ID, jid):
            return err_page("No such job.", "/auto/cartoon")
        f = request.form
        try:
            script = F.check_script(copy.deepcopy(cj.script_of(jid)))   # (numbered as the page shows it)
            if str(f.get("text") or "").strip():           # the story as text, changed
                new = T.parse(f.get("text") or "")
                if not new["scenes"]:
                    raise F.FilmError("The story has no scenes: start each scene with == and its background.")
                old_cast = {(c.get("name") or "").lower(): c for c in (script.get("cast") or {}).values()}
                for k, c in new["cast"].items():           # (the characters keep their looks and voices)
                    prev = old_cast.get((c.get("name") or "").lower())
                    if prev:
                        new["cast"][k] = dict(prev)
                new["format"] = script.get("format") or new["format"]
                new["drawing"] = script.get("drawing") or "flat"
                script = new
            for i, s in enumerate(script.get("scenes") or []):
                if f.get(f"bg_{i}") in bgs.BACKGROUNDS:
                    s["bg"] = f.get(f"bg_{i}")
                kept = [ln for ln in (s.get("lines") or []) if isinstance(ln, dict) and str(ln.get("text") or "").strip()]
                for jn, ln in enumerate(kept):
                    if f.get(f"t_{i}_{jn}") is not None:
                        ln["text"] = str(f.get(f"t_{i}_{jn}"))[:400]
                    if f.get(f"w_{i}_{jn}") in (script.get("cast") or {}):
                        ln["who"] = f.get(f"w_{i}_{jn}")
                    if f.get(f"e_{i}_{jn}") is not None:
                        ln["emotion"] = f.get(f"e_{i}_{jn}") if f.get(f"e_{i}_{jn}") in ch.EMOTIONS else None
                    if f.get(f"p_{i}_{jn}") is not None:
                        ln["pose"] = f.get(f"p_{i}_{jn}") if f.get(f"p_{i}_{jn}") in ch.POSES else None
                s["lines"] = _edited_lines(f, i, kept, script)
            if str(f.get("title") or "").strip():
                script["title"] = re.sub(r"\s+", " ", str(f.get("title"))).strip()[:120]
            if f.get("order") is not None:                 # scenes moved or removed (the page's arrows and crosses)
                old = script.get("scenes") or []
                picked = [int(x) for x in str(f.get("order") or "").split(",") if x.strip().isdigit() and int(x) < len(old)]
                if not picked:
                    raise F.FilmError("A cartoon needs at least one scene.")
                script["scenes"] = [old[k] for k in dict.fromkeys(picked)]
            if not any(s_.get("lines") for s_ in script.get("scenes") or []):
                raise F.FilmError("Nothing is said in the cartoon: write at least one line.")
            new = _make(script, f, keep=(_job(jid) or {}).get("music"))
        except (F.FilmError, vo.VoiceError) as exc:
            return err_page(str(exc), f"/auto/cartoon/{jid}")
        return redirect(f"/auto/cartoon/{new}")

    def _edited_lines(f, i: int, kept: list, script: dict) -> list:
        """A scene's lines after the page's crosses (x_<scene>_<line>) and new lines (n_<scene>_<k>_w/t/e/p/at: put
        after line "at", -1 = first), in the page's order."""
        cast = script.get("cast") or {}
        new: dict = {}
        for key in f.keys():                               # (the order the page sends them in: as they are on it)
            m = re.fullmatch(rf"n_{i}_(\d+)_t", key)
            text = re.sub(r"\s+", " ", str(f.get(key) or "")).strip()[:400] if m else ""
            if not text:
                continue
            k = m.group(1)
            try:
                at = int(f.get(f"n_{i}_{k}_at") or -1)
            except ValueError:
                at = -1
            w_, e_, p_ = f.get(f"n_{i}_{k}_w"), f.get(f"n_{i}_{k}_e"), f.get(f"n_{i}_{k}_p")
            new.setdefault(max(-1, min(at, len(kept) - 1)), []).append(
                {"who": w_ if w_ in cast else script.get("narrator"), "text": text, "emotion": e_ if e_ in ch.EMOTIONS else None,
                 "pose": p_ if p_ in ch.POSES else None, "bubble": False})
        out = list(new.get(-1, []))
        for jn, ln in enumerate(kept):
            if f.get(f"x_{i}_{jn}") != "1":
                out.append(ln)
            out += new.get(jn, [])
        return out

    def _job(jid: str) -> dict | None:
        if not re.fullmatch(_JOB_ID, jid):
            return None
        try:
            j = vo.read_job(jid)
        except vo.VoiceError:
            return None
        return j if str(j.get("kind") or "").startswith("cartoon_") else None

    _THUMBS: dict = {}

    @app.get("/auto/cartoon/<jid>/scene/<int:i>.jpg")
    def cartoon_scene_jpg(jid, i):
        """A picture of a film's scene (a little after it starts), drawn as the film draws it."""
        j = _job(jid)
        if not j or j.get("kind") != "cartoon_make":
            return ("", 404)
        key = (jid, i)
        if key not in _THUMBS:
            try:
                _THUMBS[key] = F.scene_picture(cj.script_of(jid), i)
            except (F.FilmError, IndexError, KeyError, ValueError):
                return ("", 404)
            if len(_THUMBS) > 400:
                _THUMBS.pop(next(iter(_THUMBS)))
        from flask import Response
        return Response(_THUMBS[key], mimetype="image/jpeg", headers={"Cache-Control": "max-age=600"})

    @app.post("/auto/cartoon/<jid>/language")
    def cartoon_language(jid):
        """The film in another language: its story translated (or retold for a country) by the story writer, then
        made at once with the same people, voices and look (or opened to read first)."""
        j = _job(jid)
        if not j or j.get("kind") != "cartoon_make":
            return redirect("/auto/cartoon")
        f = request.form
        try:
            film = F.check_script(copy.deepcopy(cj.script_of(jid)))
            lang = f.get("lang") if f.get("lang") in LANG_LABELS else "en"
            how = "adapt" if f.get("how") == "adapt" else "translate"
            cap = j.get("captions") if isinstance(j.get("captions"), dict) else None
            mus = j.get("music") if isinstance(j.get("music"), dict) else None
            make = {
                "voices": bool(j.get("voices")), "captions": (cap or {}).get("style"),
                "caption_look": {k: (cap or {}).get(k) for k in ("color", "size", "position") if (cap or {}).get(k)},
                "music": (mus or {}).get("kind") or "none", "mood": (mus or {}).get("mood") or "light",
                "music_path": (mus or {}).get("path") or "", "camera": film.get("camera") or "close",
                "drawing": film.get("drawing") or "flat", "pace": film.get("pace") or ""}
            if not cap:
                make["captions"] = None
            if f.get("read") == "1":                       # (the story opens to read; the film's look kept for it)
                make["hold"] = True
            title, tail = re.sub(r"\s*\((English|Русский|Română)\)$", "", film["title"]).strip(), f" ({LANG_LABELS[lang]})"
            if len(title) > 60 - len(tail):                # (the job's name holds 60: cut at a word, the language kept)
                title = title[:59 - len(tail)].rsplit(" ", 1)[0].rstrip(" ,.;:-") + "…"
            new = W.new_write(how, lang, film["format"], 75, source=T.to_text(film), country=f.get("country") or "",
                              title=title + tail, make=make,
                              cast={"cast": film["cast"], "narrator": film["narrator"]})
        except (W.WriterError, F.FilmError, vo.VoiceError) as exc:
            return err_page(str(exc), f"/auto/cartoon/{jid}")
        return redirect(f"/auto/cartoon/{new}")

    @app.get("/auto/cartoon/<jid>/film.mp4")
    def cartoon_file(jid):
        j = _job(jid)
        p = vo._job_dir(jid) / "film.mp4" if j else None
        if not p or not p.is_file():
            return ("", 404)
        return send_file(p, mimetype="video/mp4", conditional=True, max_age=0)

    @app.post("/auto/cartoon/<jid>/stop")
    def cartoon_stop(jid):
        if _job(jid):
            vo.cancel_job(jid)
        return redirect("/auto/cartoon")

    @app.post("/auto/cartoon/<jid>/retry")
    def cartoon_retry(jid):
        if _job(jid):
            try:
                vo.retry_job(jid)
            except vo.VoiceError as exc:
                return err_page(str(exc), "/auto/cartoon")
        return redirect("/auto/cartoon")

    @app.post("/auto/cartoon/<jid>/delete")
    def cartoon_delete(jid):
        j = _job(jid)
        if j and j["state"] not in ("working", "waiting"):
            try:
                vo.delete_job(jid)
            except vo.VoiceError as exc:
                return err_page(str(exc), "/auto/cartoon")
        return redirect("/auto/cartoon")

    @app.post("/auto/cartoon/<jid>/reveal")
    def cartoon_reveal(jid):
        j = _job(jid)
        saved = Path(str(((j or {}).get("result") or {}).get("saved") or "")) if j else None
        if saved and saved.is_file():
            from . import auto_edit as ae
            ae.open_path(saved, reveal=True)
        return redirect(f"/auto/cartoon/{jid}" if j else "/auto/cartoon")

    @app.get("/api/cartoon/status")
    def cartoon_status():
        out = {}
        for jid in str(request.args.get("ids") or "").split(",")[:50]:
            j = _job(jid)
            if not j:
                out[jid] = {"state": "gone"}
                continue
            lab = _label(j)
            try:
                from .i18n import ui_language
                if ui_language() == "ru":
                    from .auto_edit_ru import PHRASES
                    lab = PHRASES.get(lab, lab)
            except Exception:
                pass
            out[jid] = {"state": j["state"], "progress": float(j.get("progress") or 0), "step": lab}
        return jsonify(out)


_PICK_JS = ("document.querySelectorAll('[data-pick]').forEach(b=>b.onclick=async()=>{const f=b.closest('form'),"
            "m=f.querySelector('[data-msg]');if(m)m.textContent=(window.ME_L?ME_L('A Windows window is open — it may be behind this window.'):"
            "'A Windows window is open — it may be behind this window.');try{const r=await fetch('/api/auto/pick-voice-file',{method:'POST',"
            "headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'video'})});const x=await r.json();"
            "if(x.path){f.querySelector('input[name=video]').value=x.path;if(m)m.textContent=''}else if(m)m.textContent=x.error||''}"
            "catch(e){if(m)m.textContent=String(e)}});")
_MUSIC_JS = ("document.querySelectorAll('[data-pick-music]').forEach(b=>b.onclick=async()=>{const f=b.closest('form');"
             "try{const r=await fetch('/api/auto/pick-voice-file',{method:'POST',headers:{'Content-Type':'application/json'},"
             "body:JSON.stringify({kind:'music'})});const x=await r.json();if(x.path){f.querySelector('input[name=music_path]').value=x.path;"
             "const m=f.querySelector('input[name=music][value=file]');if(m)m.checked=true}}catch(e){}});")
_READY = ("<div class='callout card cl-ready' data-ready hidden><b>Ready.</b> <span>Refresh the page to see it.</span> "
          "<a class='btn btn2' href='javascript:location.reload()'>Refresh</a></div>")
_POLL_JS = ("(()=>{let dirty=false;document.querySelectorAll('form').forEach(f=>{f.addEventListener('input',()=>dirty=true);"
            "f.addEventListener('change',()=>dirty=true)});const live=()=>[...document.querySelectorAll('[data-job]')]"
            ".filter(x=>['working','waiting'].includes(x.dataset.state));if(!live().length)return;"
            "const tick=async()=>{const js=live();if(!js.length)return;let r;try{r=await (await fetch('/api/cartoon/status?ids='+"
            "js.map(x=>x.dataset.job).join(','))).json()}catch(e){setTimeout(tick,5000);return}let changed=false;"
            "js.forEach(x=>{const s=r[x.dataset.job];if(!s)return;if(s.state!==x.dataset.state){changed=true;x.dataset.state=s.state;return}"
            "const b=x.querySelector('[data-bar]');if(b)b.style.width=Math.round(100*(s.progress||0))+'%';"
            "const t=x.querySelector('[data-step]');if(t&&s.step)t.textContent=s.step});"
            "if(changed){if(!dirty&&![...document.querySelectorAll('video')].some(v=>!v.paused)){location.reload();return}"
            "const n=document.querySelector('[data-ready]');if(n)n.hidden=false}setTimeout(tick,3000)};setTimeout(tick,3000)})();"
            "(()=>{if(!document.getElementById('wrInstall'))return;const t=async()=>{let x;try{x=await (await fetch('/api/cartoon/writer',"
            "{cache:'no-store'})).json()}catch(e){setTimeout(t,4000);return}if(x.state!=='running'){location.reload();return}"
            "const b=document.getElementById('wrBar');if(b&&x.total)b.style.width=Math.max(3,Math.round(100*x.done/x.total))+'%';"
            "const s=document.getElementById('wrStep');if(s)s.textContent=x.step||'';const d=document.getElementById('wrDetail');"
            "if(d)d.textContent=x.detail||'';setTimeout(t,1500)};setTimeout(t,1500)})();")
