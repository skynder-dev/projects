MediaEngine 3.13.0-rc1 (release candidate)

Installer: run "MediaEngine-3.13.0-rc1-b274-Setup.exe" (if Windows SmartScreen warns: "More info" -> "Run anyway"). It installs for
this Windows user only (no administrator rights) into D:\projects\medeng (if D:\projects exists) or your user folder,
adds "MediaEngine" to the Start menu. Settings -> Apps -> MediaEngine removes all builds installed by Setup
(your projects and exports stay).

ZIP instead: before extracting, right-click the downloaded ZIP -> Properties -> tick "Unblock" -> OK (otherwise
Windows asks about every start). Start: double-click "Start MediaEngine.vbs". A MediaEngine window opens; a desktop shortcut
"MediaEngine RC" is created for next time. No console, no Python install needed. The first start
can take a minute (Windows checks the new files). Closing the window leaves MediaEngine running (a reel being
made goes on): its icon is in the notification area next to the clock - click it to open the window again,
right-click -> Quit to stop MediaEngine ("Quit" in the top bar does the same). Settings can start it in the background
when you sign in to Windows (off unless you turn it on).

Your projects, settings and exports are kept OUTSIDE this folder, in "MediaEngine Data" next to it
(the exact place is shown under Settings). Newer build: press "Update" at the top - MediaEngine looks on GitHub
(only when you press it), downloads the new build (a few MB: the Python runtime of this one is reused), puts it into a
new folder next to this one and switches to it. Or run its Setup (or extract it next to this one, a new
folder) and start it; it opens the same projects, and if this one still runs in the background the new one closes
it and opens instead (unless it is building a reel right then). If the new build has a problem, start the old folder
again. Old builds next to this one can be removed on "Check this PC"
(only a folder that holds nothing but the program is listed). The build number
(e.g. b21) is shown next to the version at the top.

Auto Edit: choose a folder with your videos (or single videos), pick Length / Format / Sound, press
"Create reel". Review the result, then press "Save MP4" on the version you want (it goes to the folder shown
under the button: "MediaEngine Data\Exports" until you use "Save to another folder...", which is then remembered).
Phone and camera files work: MP4/MOV (also HEVC and HDR), camcorder
MTS/M2TS/MOD/TOD, HDV/DV tape captures, DVD VOB/MPG, older WMV/FLV/3GP, screen and browser recordings
(WebM/MKV, also without a length written in the file). "Check this PC" (button on Home, in
Settings and on Auto Edit) shows what is installed and builds a test reel (also with the AI model).
Language: the "Русский" / "English" button at the top right of every page switches the whole program (also under
Settings -> Interface language). It starts in the language chosen in Setup.
A folder with more than 64 videos (a whole phone) shows its shooting days ("Use this day") and a tick list;
a camera card chosen at its root lists the video folders inside (DCIM, AVCHD ...).

AI model: "Download the AI model" on the Auto Edit page or on "Check this PC" (once, 30 MB, free; kept in
"MediaEngine Data", every file checked). Without the model the app offers the clearly labelled "Technical only" mode.

MediaEngine runs on port 8775 and keeps its own data in "MediaEngine Data" (by default also the archive and the
exports; Settings shows both folders); it uses no other program's folders. To remove it: installed with Setup -> Settings -> Apps ->
MediaEngine (all Setup builds; keeps "MediaEngine Data"); from the ZIP -> Quit, delete this folder, the "MediaEngine Data" folder
(your exported videos are inside it unless you saved them elsewhere) and the "MediaEngine RC" desktop shortcut.
