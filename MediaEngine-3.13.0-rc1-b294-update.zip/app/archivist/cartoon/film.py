"""A cartoon film from a script: the scenes one after another (a background, the characters, a visual - a scheme of
money, a contract, a chart, a road ...), the lines said by the characters' voices with their mouths moving, captions
of the words, short sounds, one MP4.

A script is plain data (JSON) - what a person or a language model writes:
  {"title": ..., "language": "en", "format": "vertical" | "horizontal", "drawing": "flat" (draw.STYLES),
   "cast": {"kate": {"name": "Kate", "role": "narrator", "female": true, ...}, ...},
   "narrator": "kate",
   "scenes": [{"bg": "office", "cast": ["ed"], "visual": {"kind": "contract", ...},
               "lines": [{"who": "kate", "text": "...", "pose": "explain", "emotion": "happy"}, ...]}, ...]}
A character not in a scene's cast speaks off screen (the narrator's usual place).
"""
from __future__ import annotations

import json
import math
import re
import subprocess
import wave
from pathlib import Path

import numpy as np

from . import art, bgs, chars as ch, props as P
from .draw import INK, STYLES, Canvas, back, ease, lerp, rounded

FPS = 30
FORMATS = {"vertical": (1080, 1920), "horizontal": (1920, 1080)}
SR = 48000
GAP = 0.35                    # silence after each line (s)
SCENE_PAD = 0.5               # a little air at the end of every scene (s)
PACES = {"": (GAP, SCENE_PAD), "quick": (0.2, 0.3), "calm": (0.55, 0.8)}   # (after a line, at a scene's end)


class FilmError(Exception):
    pass


# ------------------------------------------------------------------------------------------------- the script

def check_script(sc: dict) -> dict:
    """The script made safe and complete: known backgrounds, poses, emotions; every speaker in the cast."""
    if not isinstance(sc, dict) or not isinstance(sc.get("scenes"), list) or not sc["scenes"]:
        raise FilmError("The script has no scenes.")
    out = dict(sc)
    out["format"] = sc.get("format") if isinstance(sc.get("format"), str) and sc.get("format") in FORMATS else "vertical"
    cast = {}
    for key, spec in (sc.get("cast") if isinstance(sc.get("cast"), dict) else {}).items():
        if not isinstance(spec, dict):
            continue
        key = re.sub(r"[^a-z0-9_]", "", str(key).lower())[:30] or f"c{len(cast)}"
        base = ch.make(str(spec.get("name") or key), str(spec.get("role") or ""), seed=str(spec.get("seed") or spec.get("name") or key),
                       **{k: v for k, v in spec.items() if k in ("female", "build", "skin", "hair", "hair_style", "face", "beard",
                                                                  "glasses", "outfit", "cloth", "tie", "pants", "shoes", "hat",
                                                                  "height")})
        base["voice"] = spec.get("voice") or {}
        if not spec.get("keep_look"):                      # the library's look and voice for this name (Characters page)
            from . import library
            base.update(library.look_of(base["name"]))
            lv = library.voice_of(base["name"])
            if lv:                                         # (the narrator too, when a voice was written for it)
                base["voice"] = {"kind": "describe", "text": lv}
        cast[key] = base
    if not cast:
        raise FilmError("The script has no characters.")
    out["cast"] = cast
    out["narrator"] = sc.get("narrator") if isinstance(sc.get("narrator"), str) and sc.get("narrator") in cast else next(iter(cast))
    scenes = []
    for s in sc["scenes"][:40]:
        if not isinstance(s, dict):
            continue
        lines = []
        for ln in (s.get("lines") if isinstance(s.get("lines"), list) else [])[:30]:
            if not isinstance(ln, dict) or not str(ln.get("text") or "").strip():
                continue
            who = ln.get("who") if isinstance(ln.get("who"), str) and ln.get("who") in cast else out["narrator"]
            lines.append({"who": who, "text": re.sub(r"\s+", " ", str(ln["text"])).strip()[:400],
                          "pose": ln.get("pose") if isinstance(ln.get("pose"), str) and ln.get("pose") in ch.POSES else None,
                          "emotion": ln.get("emotion") if ln.get("emotion") in ch.EMOTIONS else None,
                          "bubble": bool(ln.get("bubble"))})
        try:
            min_s = max(1.0, min(30.0, float(s.get("min") or 3.0)))
        except (TypeError, ValueError):
            min_s = 3.0
        mood = s.get("mood") if isinstance(s.get("mood"), dict) else {}
        pose = s.get("pose") if isinstance(s.get("pose"), dict) else {}
        scenes.append({"bg": s.get("bg") if s.get("bg") in bgs.BACKGROUNDS else "city",
                       "cast": [k for k in (s.get("cast") if isinstance(s.get("cast"), list) else []) if isinstance(k, str) and k in cast][:4],
                       "visual": s.get("visual") if isinstance(s.get("visual"), dict) else None,
                       "lines": lines, "min": min_s,
                       "mood": {k: v for k, v in mood.items() if k in cast and v in ch.EMOTIONS},
                       "pose": {k: v for k, v in pose.items() if k in cast and v in ch.POSES}})
    if not scenes:
        raise FilmError("The script has no scenes.")
    out["scenes"] = scenes
    out["title"] = str(sc.get("title") or "Cartoon")[:120]
    out["pace"] = sc.get("pace") if isinstance(sc.get("pace"), str) and sc.get("pace") in PACES else ""
    out["drawing"] = sc.get("drawing") if isinstance(sc.get("drawing"), str) and sc.get("drawing") in STYLES else "flat"
    out["language"] = str(sc.get("language") or "en")[:5]
    out["pictures"] = sc.get("pictures") is not False         # (pictures drawn once, when there are: art.py)
    wear = []                                              # (a shirt print on a character, a short zoom on it at a line:
    for it in (sc.get("wardrobe") if isinstance(sc.get("wardrobe"), list) else [])[:4]:   # Forge's wardrobe.json)
        if (isinstance(it, dict) and it.get("wearer") in cast and str(it.get("print") or "").lower().endswith(".png")
                and Path(str(it["print"])).is_file()):
            wear.append({"print": str(it["print"]), "wearer": it["wearer"], "line": str(it.get("line") or "")[:300],
                         "zoom": bool(it.get("zoom"))})
    if wear:
        out["wardrobe"] = wear
        for w in wear:                                     # (the wearer in a plain T-shirt: the print on it, not on a vest)
            cast[w["wearer"]] = dict(cast[w["wearer"]], outfit="tee", hat="none")
    site = sc.get("site") if isinstance(sc.get("site"), dict) else {}
    if re.match(r"(?i)^https?://\S+$", str(site.get("url") or "")):
        out["site"] = {"url": str(site["url"])[:500]}     # (a web page shown in the scenes without a visual: site.py)
        free = [s for s in scenes if not s.get("visual")]
        if len(free) < len(scenes) // 2:                  # (a writer gives every scene a picture: every second one shows
            free = [s for i, s in enumerate(scenes) if not s.get("visual") or i % 2 == 1]   # the page instead)
        for k, s in enumerate(free):
            s["site_part"] = [k, len(free)]
    return out


ZOOM_S = 1.6                   # seconds the camera stays on a shirt


def shirt_of(film: dict, key: str) -> str:
    return next((w["print"] for w in film.get("wardrobe") or [] if w["wearer"] == key), "")


def shirt_zoom(film: dict, scene: dict, t: float) -> str | None:
    """Who the camera is close to the chest of now: the wearer saying the shirt's line (or, without a line, the wearer's
    first line in the film), for ZOOM_S seconds from its start."""
    for w in film.get("wardrobe") or []:
        if not w.get("zoom"):
            continue
        want = re.sub(r"\W+", " ", w["line"].lower()).strip()
        for ln in scene["lines"]:
            said = re.sub(r"\W+", " ", str(ln.get("text") or "").lower()).strip()
            if ln["who"] == w["wearer"] and (want and (want in said or said in want)) and ln["s"] <= t < ln["s"] + ZOOM_S:
                return w["wearer"]
    return None


def site_image(film: dict) -> str:
    """The picture of the film's web page (fetched by render; a page already fetched otherwise), "" without one."""
    if not film.get("site"):
        return ""
    if film.get("_site_img"):
        return film["_site_img"]
    from . import site as S
    p = S.folder(film["site"]["url"]) / "page.png"
    return str(p) if p.is_file() else ""


def pictures(film: dict) -> dict:
    """The film's picture backgrounds and characters (art.py): {"bg": {name: path}, "cast": {key: folder}}, found once."""
    got = film.get("_pictures")
    if got is None:
        got = {"bg": {}, "cast": {}}
        if film.get("pictures", True):
            for s in film.get("scenes") or []:
                b = art.background(s.get("bg") or "", wide=film.get("format") == "horizontal")
                if b:
                    got["bg"][s["bg"]] = str(b)
            for key, c in (film.get("cast") or {}).items():
                f = art.character(c.get("name") or key)
                if f:
                    got["cast"][key] = str(f)
        film["_pictures"] = got
    return got


def keep_cast(new: dict, old: dict) -> dict:
    """A film's story in another language (or retold for another country) played by the film's own people: the new
    story's people in order get the old ones' looks, voices and keys (a woman stays a woman); only the names change.
    old: {"cast": {key: spec}, "narrator": key} of the film (checked: with the looks)."""
    o_cast = old.get("cast") if isinstance(old.get("cast"), dict) else {}
    n_cast = new.get("cast") if isinstance(new.get("cast"), dict) else {}
    if not o_cast or not n_cast:
        return new
    o_keys, used, ren = list(o_cast), set(), {}
    nar_o = old.get("narrator") if old.get("narrator") in o_cast else o_keys[0]
    nar_n = new.get("narrator") if new.get("narrator") in n_cast else next(iter(n_cast))
    for pos, nk in enumerate(n_cast):
        spec = n_cast[nk] if isinstance(n_cast[nk], dict) else {}
        want = nar_o if nk == nar_n else (o_keys[pos] if pos < len(o_keys) else None)
        if want in used or want is None or (want != nar_o and bool(o_cast[want].get("female")) != bool(spec.get("female"))):
            want = next((k for k in o_keys if k not in used and k != nar_o
                         and bool(o_cast[k].get("female")) == bool(spec.get("female"))), None)
        if want is None or want in used:
            continue
        used.add(want)
        ren[nk] = want
    if not ren:
        return new
    out = dict(new)
    cast = {}
    for nk, spec in n_cast.items():
        if nk in ren:
            ok = ren[nk]
            cast[ok] = dict(o_cast[ok], name=str((spec or {}).get("name") or o_cast[ok].get("name") or ok), keep_look=True)
        elif nk not in o_cast:
            cast[nk] = spec
    out["cast"] = cast
    out["narrator"] = ren.get(nar_n, nar_n)
    scenes = []
    for sc_ in new.get("scenes") or []:
        if not isinstance(sc_, dict):
            continue
        sc2 = dict(sc_)
        if isinstance(sc_.get("cast"), list):
            sc2["cast"] = [ren.get(k, k) for k in sc_["cast"]]
        for field in ("mood", "pose"):
            if isinstance(sc_.get(field), dict):
                sc2[field] = {ren.get(k, k): v for k, v in sc_[field].items()}
        sc2["lines"] = [dict(ln, who=ren.get(ln.get("who"), ln.get("who"))) if isinstance(ln, dict) else ln
                        for ln in (sc_.get("lines") or [])]
        scenes.append(sc2)
    out["scenes"] = scenes
    return out


def estimate_words(text: str, start: float, rate: float = 2.6) -> tuple[list, float]:
    """Word times for a line without a voice (a preview): about 2.6 words a second, longer words longer."""
    ws = text.split()
    if not ws:
        return [], 0.0
    per = [0.18 + 0.055 * len(re.sub(r"\W", "", w)) + (0.12 if re.search(r"[.,!?;:]$", w) else 0) for w in ws]
    k = (len(ws) / rate) / max(1e-6, sum(per))
    out, t = [], start
    for w, d in zip(ws, per):
        out.append({"w": w, "s": round(t, 3), "e": round(t + d * k * 0.9, 3)})
        t += d * k
    return out, t - start


def timeline(sc: dict, voices: dict | None = None) -> dict:
    """When every scene and line is: voices = {"<scene>.<line>": {"wav": path, "seconds": s, "words": [...]}}
    (word times from the line's start); without one, the line's length is estimated."""
    t = 0.0
    scenes = []
    pace = sc.get("pace") if isinstance(sc.get("pace"), str) else ""
    gap, pad = PACES.get(pace, PACES[""])                  # (quick like a reference that cuts often, or calm)
    for i, s in enumerate(sc["scenes"]):
        start = t
        lines = []
        t += 0.25                                          # (a breath before the first line)
        for j, ln in enumerate(s["lines"]):
            v = (voices or {}).get(f"{i}.{j}")
            if v and v.get("seconds"):
                words = [dict(w, s=round(float(w["s"]) + t, 3), e=round(float(w["e"]) + t, 3)) for w in v.get("words") or []]
                dur = float(v["seconds"])
            else:
                words, dur = estimate_words(ln["text"], t)
            lines.append(dict(ln, s=round(t, 3), e=round(t + dur, 3), words=words, wav=(v or {}).get("wav")))
            t += dur + gap
        t = max(t + pad, start + s["min"])
        scenes.append(dict(s, s=round(start, 3), e=round(t, 3), lines=lines))
    prev: list = []
    for s in scenes:                                       # who walks in: not in the picture of the scene before
        shown = _shown(sc, s)
        s["enter"] = [k for k in shown if k not in prev] if prev else []
        prev = shown
    return {"scenes": scenes, "seconds": round(t, 3)}


def _shown(sc: dict, scene: dict) -> list:
    """The characters in a scene's picture: its cast, or the narrator presenting a scene nobody else is in."""
    names = list(scene.get("cast") or [])
    if not names and any(x["who"] == sc.get("narrator") for x in scene.get("lines") or []):
        names = [sc["narrator"]]
    return names


WALK_IN = 0.9                  # seconds a character takes to walk in


# ------------------------------------------------------------------------------------------------- the picture

def _layout(cv: Canvas, n: int, visual: bool) -> tuple[list, float, tuple | None]:
    """Where the characters stand (x of each), their size, and the visual's box (cx, cy, w, h)."""
    gy = bgs.ground_y(cv)
    if cv.SW >= cv.SH:                                    # wide: the characters left / around, the visual on the right
        sc = 0.92 if n <= 2 else 0.8
        if visual:
            xs = [cv.SW * (0.2 + 0.18 * k) for k in range(n)] if n > 1 else [cv.SW * 0.22]
            box = (cv.SW * (0.68 if n <= 1 else 0.72), cv.SH * 0.42, cv.SW * 0.5, cv.SH * 0.66)
        else:
            xs = [cv.SW * (k + 1) / (n + 1) for k in range(n)]
            box = None
    else:                                                  # tall: the visual on top, captions, the characters below
        sc = (1.05 if n <= 2 else 0.84) if visual else (1.25 if n <= 2 else 0.95)
        xs = [cv.SW * (k + 1) / (n + 1) for k in range(n)] if n > 1 else [cv.SW * 0.5]
        if n == 2:
            xs = [cv.SW * 0.3, cv.SW * 0.7]
        box = (cv.SW * 0.5, cv.SH * 0.255, cv.SW * 0.98, cv.SH * 0.4) if visual else None
    del gy
    return xs, sc, box


def _speaking(scene: dict, t: float) -> tuple[dict | None, int]:
    for j, ln in enumerate(scene["lines"]):
        if ln["s"] - 0.05 <= t <= ln["e"] + 0.05:
            return ln, j
    return None, -1


def _line_at(scene: dict, t: float) -> int:
    """The index of the line said now or last (-1 before the first)."""
    k = -1
    for j, ln in enumerate(scene["lines"]):
        if t >= ln["s"] - 0.05:
            k = j
    return k


SWAY = {"talk": "explain", "explain": "talk", "idle": "talk", "present": "explain", "point": "explain", "sit": "talk"}
OUTDOOR = {"city", "road", "night", "site", "home"}   # (sitting there: on a bench; elsewhere on a chair)
SIT_DOWN = 0.45                # seconds a character takes to sit down after walking in


def seated(scene: dict) -> set:
    """Who sits in a scene: the scene's gesture for them, or any of their lines, is "sit" (they sit through it)."""
    out = {k for k, v in (scene.get("pose") or {}).items() if v == "sit"}
    return out | {ln["who"] for ln in scene.get("lines") or [] if ln.get("pose") == "sit"}
BLEND = 0.35                   # seconds a gesture takes to become the next one


def _pose_at(scene: dict, key: str, t: float) -> str:
    """The gesture a character holds at time t: its line's (said now or last), else the scene's, else talking / standing."""
    j = _line_at(scene, t)
    last = scene["lines"][j] if j >= 0 else None
    ln, _ = _speaking(scene, t)
    mine = last if last and last["who"] == key else None
    return (mine or {}).get("pose") or scene["pose"].get(key) or ("talk" if ln and ln["who"] == key else "idle")


def _pose_mix(scene: dict, key: str, t: float, k: int) -> tuple[str, str | None, float]:
    """(pose, pose2, mix): a new gesture grows out of the one before (BLEND s); a speaker's arms move a little."""
    pose = _pose_at(scene, key, t)
    edges = [x for ln in scene["lines"] for x in (ln["s"] - 0.05, ln["e"] + 0.05) if x <= t]
    if edges:
        b = max(edges)
        if t - b < BLEND:
            before = _pose_at(scene, key, b - 0.011)
            if before != pose:
                return before, pose, (t - b) / BLEND
    ln, _ = _speaking(scene, t)
    if ln and ln["who"] == key and pose in SWAY:
        return pose, SWAY[pose], 0.32 * (0.5 + 0.5 * math.sin(t * 3.3 + k * 1.7))
    return pose, None, 0.0


def _appear(scene: dict, at, t: float, dur: float = 0.6) -> float:
    """How far something that appears with line "at" (an index; None = at once) has come (0..1)."""
    if at is None:
        return min(1.0, max(0.0, (t - scene["s"] - 0.15) / dur))
    j = int(at)
    if j < 0 or j >= len(scene["lines"]):
        return 1.0 if j < 0 else 0.0
    return min(1.0, max(0.0, (t - scene["lines"][j]["s"]) / dur))


DARK = {"board", "night"}
INDOOR = {"office", "bank", "hospital", "school", "shop", "paper"}     # (a title there gets a card under it)


def draw_visual(cv: Canvas, v: dict, scene: dict, t: float, box: tuple, cast: dict):
    """The scene's visual in its box: drawn in a 1000 x 760 panel of its own, scaled into the box."""
    cx, cy, bw, bh = box
    ink = "#ffffff" if scene.get("bg") in DARK else INK
    k = min(bw / 1000.0, bh / 760.0)
    kind = v.get("kind")
    st = t - scene["s"]
    with cv.at(cx, cy, 0, k):
        if kind == "title":
            a = back(_appear(scene, None, t, 0.8))
            with cv.at(0, -120, 0, max(0.01, a)):
                cv.text(v.get("title") or "", 0, 0, 96, "#ffffff", "black", outline=INK, stroke=8, width=960)
            if v.get("sub"):
                cv.text(v["sub"], 0, 150, 52, ink, "black", width=900, alpha=ease(_appear(scene, None, t - 0.5, 0.6)))
            P.money_bag(cv, -300 + math.sin(st * 2) * 10, 300, 1.0)
            for i in range(3):
                P.coin(cv, 220 + i * 90, 300 - abs(math.sin(st * 3 + i)) * 60, 1.0, st * 4 + i)
        elif kind == "flow":
            nodes = v.get("nodes") or []
            pos = {}
            n = len(nodes)
            for i, nd in enumerate(nodes):                 # a row, or two rows for more than three
                if n <= 3:
                    pos[nd["id"]] = (-330 + i * 660 / max(1, n - 1) if n > 1 else 0, 0)
                else:                                      # (a square: the first at the top left, round the clock)
                    pos[nd["id"]] = [(-270, -200), (270, -200), (270, 220), (-270, 220), (0, 10)][i % 5]
            for e in v.get("edges") or []:
                if e.get("from") not in pos or e.get("to") not in pos:
                    continue
                a_, b_ = pos[e["from"]], pos[e["to"]]
                path = P.curve((a_[0] + (60 if b_[0] > a_[0] else -60 if b_[0] < a_[0] else 0), a_[1] + (0 if b_[0] != a_[0] else 80)),
                               (b_[0] - (60 if b_[0] > a_[0] else -60 if b_[0] < a_[0] else 0), b_[1] - (0 if b_[0] != a_[0] else 80)),
                               0.22 if e.get("bend", 1) > 0 else -0.22)
                g = _appear(scene, e.get("at"), t, 0.8)
                P.arrow(cv, path, g, e.get("color") or INK, 9, 24)
                if g >= 1 and e.get("label"):
                    mid = P.along(path, 0.5)
                    P.price_tag(cv, mid[0], mid[1] - 64, e["label"], 0.85, e.get("tag", P.GOLD), _appear(scene, e.get("at"), t - 0.4, 0.5), 0)
                if g >= 1 and e.get("money", True):
                    for m in range(2):
                        ph = ((t * 0.55 + m * 0.5) % 1.0)
                        px, py = P.along(path, ph)
                        P.banknote(cv, px, py, 0.5, math.sin(t * 5 + m) * 12)
            for nd in nodes:
                x, y = pos[nd["id"]]
                P.node(cv, x, y, nd.get("label") or "", nd.get("icon") or "", nd.get("color") or P.BLUE,
                       _appear(scene, nd.get("at"), t, 0.5), 300, 170, nd.get("sub") or "")
        elif kind == "contract":
            w_ = _appear(scene, v.get("at"), t, 2.2)
            P.document(cv, -160, 0, 1.25, v.get("title") or "CONTRACT", 7, w_,
                       v.get("price") if _appear(scene, v.get("price_at"), t, 0.4) > 0 else "",
                       _appear(scene, v.get("at"), t, 0.5), -4)
            if v.get("stamp"):
                P.stamp(cv, 60, 250, 1.0, v["stamp"], _appear(scene, v.get("stamp_at"), t, 0.5))
            for i, note in enumerate(v.get("notes") or []):
                a = _appear(scene, note.get("at"), t, 0.4)
                if a > 0:
                    P.tick(cv, 160, -230 + i * 170, 0.9, bool(note.get("ok")), a)
                    cv.text(note.get("text") or "", 370, -230 + i * 170, 40, ink, "black", width=320, alpha=min(1, a * 1.5))
        elif kind == "bars":
            P.bars(cv, 0, 300, [float(x) for x in v.get("values") or [1]], v.get("labels") or [], v.get("colors") or [P.GREEN, P.RED],
                   ease(_appear(scene, v.get("at"), t, 1.6)), 760, 520, v.get("unit") or "", ink=ink)
            if v.get("title"):
                cv.text(v["title"], 0, -330, 56, ink, "black", width=900)
        elif kind == "road":
            holes = _appear(scene, v.get("holes_at"), t, 1.5) if v.get("holes_at") is not None else (0.0 if v.get("fresh") else 1.0)
            patch = _appear(scene, v.get("patch_at"), t, 1.5) if v.get("patch_at") is not None else 0.0
            P.road(cv, 0, 200, 960, holes, patch, t)
            for i, x in enumerate((-430, 430)):
                P.cone(cv, x, 300, 0.8)
            if v.get("truck"):
                tx = lerp(-700, -150, ease(_appear(scene, v.get("truck_at"), t, 2.0)))
                P.truck(cv, tx, 140, 0.6, 1, P.GOLD, t)
            cal = v.get("calendar") or []
            shown = None
            for c in cal:
                if _appear(scene, c[2] if len(c) > 2 else None, t, 0.3) > 0:
                    shown = c
            if shown:
                P.calendar(cv, 330, -180, 0.9, str(shown[0]), str(shown[1]))
        elif kind == "counter":
            g = ease(_appear(scene, v.get("at"), t, 2.0))
            val = lerp(float(v.get("from") or 0), float(v.get("to") or 0), g)
            P.counter(cv, 0, -40, val, 110, v.get("prefix", "$"), v.get("suffix", ""), v.get("color") or P.RED)
            if v.get("label"):
                cv.text(v["label"], 0, 90, 48, ink, "black", width=900)
            P.cash_stack(cv, -260, 300, 1.0, 2 + int(6 * g))
            P.cash_stack(cv, 260, 300, 1.0, 2 + int(5 * g))
        elif kind == "list":
            if v.get("title"):
                cv.text(v["title"], 0, -320, 60, ink, "black", width=900)
            warn = bool(re.search(r"(?i)red flag|warning|risk|scam|avoid|mistake|\bnot\b|don.?t|флаж|опасн|ошибк|осторожн|не делай|"
                                  r"semnal|avertiz|risc", str(v.get("title") or "")))
            for i, it in enumerate(v.get("items") or []):
                a = _appear(scene, it.get("at"), t, 0.4)
                if a <= 0:
                    continue
                y = -190 + i * 140                         # (a cross only in a list of warnings: "Who can get it" ticks)
                P.tick(cv, -400, y, 0.85, bool(it.get("ok")) or not warn, a)
                cv.text(it.get("text") or "", -320, y, 50, ink, "black", width=780, anchor="lm", alpha=min(1, a * 1.5))
        elif kind == "percent":                            # a share of a whole: the slice grows to its size
            a = ease(_appear(scene, v.get("at"), t, 1.4))
            share = max(0.0, min(1.0, float(v.get("value") or 0) / 100.0))
            cv.shadow(0, 250, 300, 30, 0.18)
            cv.circle(0, -20, 250, "#d9dee6", INK, 6)
            if share * a > 0.002:
                cv.ellipse(0, -20, 250, 250, P.RED, INK, 6, -90, -90 + 360 * share * a)
            cv.circle(0, -20, 128, "#ffffff", INK, 5)
            cv.text(f"{int(round(float(v.get('value') or 0) * a))}%", 0, -20, 74, INK, "black")
            if v.get("label"):
                cv.text(v["label"], 0, 320, 54, ink, "black", width=900, alpha=min(1.0, a * 1.5))
        elif kind == "timeline":                           # dates along a line, one by one
            steps = v.get("steps") or []
            n = max(1, len(steps))
            cv.line([(-430, 0), (430, 0)], ink, 8)
            for i, stp in enumerate(steps):
                a = _appear(scene, stp.get("at"), t, 0.5)
                if a <= 0:
                    continue
                x = -430 + 860 * (i + 0.5) / n
                up = i % 2 == 0
                cv.circle(x, 0, 26 * back(a), P.RED if stp.get("bad") else P.GOLD, INK, 5)
                cv.text(stp.get("when") or "", x, -70 if up else 70, 50, ink, "black", width=860 / n + 40, alpha=min(1, a * 1.5))
                cv.text(stp.get("what") or "", x, -150 if up else 150, 38, ink, "extrabold", width=860 / n + 60,
                        alpha=min(1, a * 1.5))
        elif kind == "compare":
            for i, side in enumerate(v.get("sides") or []):
                a = _appear(scene, side.get("at"), t, 0.5)
                x = -260 + i * 520
                if a > 0:
                    P.price_tag(cv, x, -40, side.get("price") or "", 1.5, side.get("color") or (P.GREEN if i == 0 else P.RED), a, 0)
                    cv.text(side.get("label") or "", x, 110, 46, ink, "black", width=440, alpha=min(1, a * 1.5))
            if len(v.get("sides") or []) == 2:
                cv.text("vs", 0, -40, 60, ink, "black")
        elif kind == "bag":
            P.money_bag(cv, 0, 60, 1.8, v.get("label") or "$")
            if v.get("text"):
                cv.text(v["text"], 0, -300, 56, ink, "black", width=900)
        elif kind == "magnifier":
            P.document(cv, -60, 20, 1.1, v.get("title") or "TENDER", 7, 1.0, v.get("price") or "", 1.0, 3)
            ph = st * 0.9
            P.magnifier(cv, -60 + math.cos(ph) * 110, -40 + math.sin(ph * 1.3) * 120, 1.2)


def _bubble_for(cv: Canvas, ln: dict, x: float, top_y: float, t: float):
    a = min(1.0, max(0.0, (t - ln["s"]) / 0.3)) * min(1.0, max(0.0, (ln["e"] + 0.6 - t) / 0.3))
    if a > 0:
        w = min(cv.SW * 0.42 if cv.SW >= cv.SH else cv.SW * 0.8, 620)
        bx = min(max(x, w / 2 + 20), cv.SW - w / 2 - 20)
        P.bubble(cv, bx, top_y - 130, ln["text"], w, (-1 if bx > x else 1, 1), a, 34)


CLOSE = {"vertical": 2.6, "horizontal": 2.2}     # how near a close-up comes (the head and the chest)
CLOSE_EMO = {"angry", "surprised", "sad"}           # (a strong feeling: a close-up on it)


def close_up(film: dict, scene: dict, t: float) -> str | None:
    """Who the camera is close to at film time t (None: the whole scene). A cut to a close-up of the speaker on every
    second line of a scene - and on a line said with a strong feeling - as cartoons do; never while a picture is to be
    read (a scene with a visual), in a scene's first moments (its transition, someone walking in), on a short line or a
    line in a bubble. film["camera"] == "still": never."""
    if film.get("camera") == "still" or scene.get("visual") or scene.get("site_part"):  # (a page shown: no close-up)
        return None
    j = _line_at(scene, t)
    if j < 0:
        return None
    ln = scene["lines"][j]
    if ln.get("bubble") or ln["who"] not in _shown(film, scene) or ln["e"] - ln["s"] < 1.2:
        return None
    if ln["s"] - scene["s"] < (WALK_IN + 0.3 if scene.get("enter") else 0.8):
        return None
    if not (j % 2 == 1 or (ln.get("emotion") in CLOSE_EMO and j > 0)):
        return None
    nxt = scene["lines"][j + 1]["s"] if j + 1 < len(scene["lines"]) else scene["e"]
    return ln["who"] if t < min(nxt, ln["e"] + GAP) else None


def _camera(cv: Canvas, film: dict, scene: dict, t: float, names: list, xs: list, sc: float) -> tuple[float, float, float]:
    """(x, y, zoom) the camera looks at: a slow push-in through the scene, or a close-up of the one speaking."""
    st = t - scene["s"]
    z = 1.0 + 0.045 * min(1.0, st / max(1.0, scene["e"] - scene["s"]))
    pics = pictures(film)
    if pics["cast"] or scene["bg"] in pics["bg"]:
        z = 1.0                                            # (pictures: no slow push-in - resized a pixel at a time they shivered)
    shirt = shirt_zoom(film, scene, t)
    if shirt and shirt in names and shirt not in pics["cast"]:
        b = ch._body(film["cast"][shirt])
        zz = CLOSE["vertical" if cv.SH > cv.SW else "horizontal"] * 1.35
        x, y = xs[names.index(shirt)], bgs.ground_y(cv) - (b["leg_h"] + b["torso_h"] * 0.52) * sc
        hw, hh = cv.SW / (2 * zz), cv.SH / (2 * zz)
        return min(max(x, hw), cv.SW - hw), min(max(y, hh), cv.SH - hh), zz
    who = close_up(film, scene, t)
    if not who or who not in names:
        return cv.SW / 2, cv.SH / 2, z
    tall = cv.SH > cv.SW
    z = CLOSE["vertical" if tall else "horizontal"] + (0.0 if pics["cast"] else 0.02 * min(1.0, st / 4.0))
    where = film.get("caption_at") or ""                   # (the face kept clear of the captions' band)
    f = ({"middle": 0.18, "bottom": 0.25, "top": 0.32} if tall else {"middle": 0.12, "bottom": 0.2, "top": 0.3}).get(
        where, 0.25 if tall else 0.2)                      # where the top of the head comes, a share of the height
    if who in pictures(film)["cast"]:                       # (a picture character: as tall as its pictures are drawn)
        top = bgs.ground_y(cv) - art.HEIGHT * float(film["cast"][who].get("height") or 1.0) * sc * 0.97
    else:
        top = bgs.ground_y(cv) - 530 * sc + (ch.sit_drop(film["cast"][who]) * sc if who in seated(scene) else 0.0)
    x, y = xs[names.index(who)], top - (f - 0.5) * cv.SH / z
    hw, hh = cv.SW / (2 * z), cv.SH / (2 * z)
    return min(max(x, hw), cv.SW - hw), min(max(y, hh), cv.SH - hh), z


def draw_frame(cv: Canvas, film: dict, scene: dict, t: float, mouths: dict):
    """One picture of a scene at film time t. mouths: who -> mouth opening now."""
    st = t - scene["s"]
    cast = film["cast"]
    ln, j = _speaking(scene, t)
    speaker = ln["who"] if ln else None
    names = _shown(film, scene)                            # (nobody else there: the narrator presents it)
    page = site_image(film) if scene.get("site_part") else ""
    xs, sc, box = _layout(cv, len(names), bool(scene.get("visual")) or bool(page))
    cam_x, cam_y, zoom = _camera(cv, film, scene, t, names, xs, sc)
    cv.lens = zoom
    pics = pictures(film)
    with cv.at(cv.SW / 2, cv.SH / 2, 0, zoom):
        with cv.at(-cam_x, -cam_y):
            if scene["bg"] in pics["bg"]:
                art.draw_background(cv, Path(pics["bg"][scene["bg"]]))
                gy = bgs.ground_y(cv)
            else:
                gy = bgs.draw(cv, scene["bg"], t)
            if scene.get("visual") and box and not page:
                if scene["bg"] not in DARK and (scene["visual"].get("kind") not in ("road", "title")
                                                 or (scene["visual"].get("kind") == "title" and scene["bg"] in INDOOR)):
                    bx, by, bw_, bh_ = box                 # (a light card under a scheme or a paper: it reads on any background)
                    a = ease(min(1.0, (t - scene["s"]) / 0.4))
                    cv.blend("#ffffff", 0.78 * a, rounded(bx - bw_ / 2 + 10, by - bh_ / 2 + 10, bw_ - 20, bh_ - 20, 36))
                draw_visual(cv, scene["visual"], scene, t, box, cast)
            elif page and box:                             # (the web page, scrolled a part further in every scene)
                from . import site as S
                k, n = scene["site_part"]
                span = 0.3                                 # (only the page's first part: what it is for is near its top;
                S.draw(cv, page, box, span * k / max(1, n), span * (k + 1) / max(1, n),   # further down came prisons)
                       min(1.0, max(0.0, (t - scene["s"]) / max(0.5, scene["e"] - scene["s"]))))
            last = scene["lines"][_line_at(scene, t)] if _line_at(scene, t) >= 0 else None
            sitting = seated(scene)
            for k, key in enumerate(names):
                c = cast[key]
                x = xs[k]
                look = _facing(cv, scene, names, xs, box, key, t)
                turn = look                                # (turning round: the body narrows and comes back the other way)
                edge = max((ln_["s"] - 0.05 for ln_ in scene["lines"] if ln_["s"] - 0.05 <= t), default=None)
                if edge is not None and t - edge < TURN_S:
                    before = _facing(cv, scene, names, xs, box, key, edge - 0.01)
                    if before != look:
                        f_ = (t - edge) / TURN_S
                        turn = (before if f_ < 0.5 else look) * max(0.15, abs(math.cos(math.pi * f_)))
                mine = last if last and last["who"] == key else None
                pose, pose2, mix = _pose_mix(scene, key, t, k)
                snap = bool(pose2) and pose2 == _pose_at(scene, key, t)          # (a new gesture, not the speaker's sway)
                emo = (mine or {}).get("emotion") or scene["mood"].get(key) or ("happy" if speaker == key else "neutral")
                blink = _blink(t, k)
                gzx, gzy = 0.6 * look, (-0.25 if box else 0.0)                # (eyes: to the one looked at, up to a picture)
                gzx += 0.18 * (_hash01(k, math.floor(t * 1.1 + k * 0.3)) - 0.5)  # (and small glances, now and then)
                gzy += 0.14 * (_hash01(k, math.floor(t * 0.9 + k * 0.7), 3) - 0.5)
                nod = brow = 0.0
                hop = 0.0
                if speaker == key:
                    nod = brow = _beat(ln, t)
                    if ln and str(ln.get("text") or "").rstrip().endswith("!") and 0 <= t - ln["s"] < 0.32:
                        hop = math.sin(math.pi * (t - ln["s"]) / 0.32) * 14 * sc     # (an exclamation: a little jump)
                elif speaker in names:                     # (the others listen: a slow nod now and then; startled by a
                    nod = 0.5 * max(0.0, math.sin(2 * math.pi * (t * 0.31 + k * 0.37))) ** 8      # shout or a surprise)
                    if ln and ln.get("emotion") in ("angry", "surprised") and 0 <= t - ln["s"] < 0.45:
                        f_ = math.sin(math.pi * (t - ln["s"]) / 0.45)
                        nod, brow = -0.7 * f_, 0.9 * f_
                walk = None
                sit = 0.0
                if key in sitting and key not in pics["cast"]:     # (on a chair or a bench; one who walks in sits down)
                    ch.seat(cv, c, xs[k], gy, sc, "bench" if scene["bg"] in OUTDOOR else "chair")
                    sit = ease(min(1.0, max(0.0, (st - WALK_IN) / SIT_DOWN))) if key in (scene.get("enter") or []) else 1.0
                    hop = 0.0
                if key in (scene.get("enter") or []) and st < WALK_IN:     # walking in from the nearer side
                    side = -1 if x < cv.SW / 2 else 1
                    x += side * (1 - ease(st / WALK_IN)) * (cv.SW * 0.55)
                    walk, look, pose, pose2, emo = st * 9.0, -side, "idle", None, emo
                    gzx, nod, brow, hop = 0.6 * look, 0.0, 0.0, 0.0
                if key in pics["cast"]:                    # (a picture character: its gesture's picture, the mouth)
                    art.draw_character(cv, Path(pics["cast"][key]), x, gy - hop, sc, turn if walk is None else look,
                                       pose2 if pose2 and mix >= 0.5 else pose, mouths.get(key, 0.0) if speaker == key else 0.0,
                                       t + k, walk, nod, float(c.get("height") or 1.0))
                else:
                    ch.draw(cv, c, x, gy - hop, sc, turn if walk is None else look, pose, pose2, mix, emo,
                            mouths.get(key, 0.0) if speaker == key else 0.0, blink, t + k, walk, (gzx, gzy), nod=nod, brow=brow,
                            snap=snap, sit=sit, shirt=shirt_of(film, key))
                if speaker == key and ln.get("bubble"):
                    _bubble_for(cv, ln, x, gy - 600 * sc + ch.sit_drop(c) * sc * sit, t)


# ------------------------------------------------------------------------------------------------- sound

def _read_wav(path: str) -> np.ndarray:
    with wave.open(path, "rb") as w:
        n, ch_, sw, sr = w.getnframes(), w.getnchannels(), w.getsampwidth(), w.getframerate()
        raw = w.readframes(n)
    a = np.frombuffer(raw, dtype=np.int16 if sw == 2 else np.int32).astype(np.float32)
    a /= 32768.0 if sw == 2 else 2147483648.0
    if ch_ > 1:
        a = a.reshape(-1, ch_).mean(axis=1)
    if sr != SR:                                          # (simple resampling: the voices are 48 kHz already)
        idx = np.arange(0, len(a), sr / SR)
        a = np.interp(idx, np.arange(len(a)), a).astype(np.float32)
    return a


def _sfx(kind: str) -> np.ndarray:
    """Short sounds made here (no files): a whoosh between scenes, a pop when something appears, a stamp, coins."""
    rng = np.random.default_rng(3)
    if kind == "whoosh":
        n = int(SR * 0.45)
        x = rng.standard_normal(n).astype(np.float32)
        env = np.sin(np.linspace(0, math.pi, n)) ** 2
        k = np.linspace(0.02, 0.2, n)                      # (a moving low-pass: one-pole filter, rising cutoff)
        y = np.zeros(n, np.float32)
        acc = 0.0
        for i in range(n):
            acc += k[i] * (x[i] - acc)
            y[i] = acc
        return y * env * 0.5
    if kind == "pop":
        n = int(SR * 0.12)
        tt = np.arange(n) / SR
        return (np.sin(2 * math.pi * (700 + 900 * tt / tt[-1]) * tt) * np.exp(-tt * 30) * 0.35).astype(np.float32)
    if kind == "stamp":
        n = int(SR * 0.25)
        tt = np.arange(n) / SR
        return ((np.sin(2 * math.pi * 90 * tt) * 0.8 + rng.standard_normal(n) * 0.15) * np.exp(-tt * 22) * 0.6).astype(np.float32)
    if kind == "ding":                                     # (a small bell: something found, a lesson)
        n = int(SR * 0.6)
        tt = np.arange(n) / SR
        return ((np.sin(2 * math.pi * 1568 * tt) + 0.4 * np.sin(2 * math.pi * 3136 * tt) + 0.15 * np.sin(2 * math.pi * 4704 * tt))
                * np.exp(-tt * 7) * 0.18).astype(np.float32)
    if kind == "coins":
        n = int(SR * 0.5)
        out = np.zeros(n, np.float32)
        for k in range(6):
            s0 = int(SR * 0.07 * k)
            tt = np.arange(n - s0) / SR
            out[s0:] += (np.sin(2 * math.pi * (2400 + 300 * k) * tt) * np.exp(-tt * 40) * 0.12).astype(np.float32)
        return out
    return np.zeros(1, np.float32)


def mix(tl: dict, sounds: bool = True) -> np.ndarray:
    total = int(SR * (tl["seconds"] + 0.5))
    out = np.zeros(total, np.float32)

    def put(a: np.ndarray, at: float, gain: float = 1.0):
        i = int(at * SR)
        if i >= total or len(a) == 0:
            return
        n = min(len(a), total - i)
        out[i:i + n] += a[:n] * gain
    for i, s in enumerate(tl["scenes"]):
        if sounds and i > 0:
            put(_sfx("whoosh"), max(0.0, s["s"] - 0.2), 0.6)
        v = s.get("visual") or {}
        if sounds and v.get("kind") == "contract" and v.get("stamp_at") is not None and int(v["stamp_at"]) < len(s["lines"]):
            put(_sfx("stamp"), s["lines"][int(v["stamp_at"])]["s"] + 0.2, 0.8)
        if sounds and v.get("kind") in ("flow", "counter", "bag", "title"):
            put(_sfx("coins"), s["s"] + 0.6, 0.5)
        if sounds and v.get("kind") in ("bars", "percent", "compare", "timeline", "list", "tender", "contract"):
            put(_sfx("pop"), s["s"] + 0.05, 0.45)          # (a picture appears - over before the first word, at 0.25 s)
        if sounds and v.get("kind") == "magnifier":
            put(_sfx("ding"), s["s"] + 0.8, 0.6)
        if sounds:
            for ln in s["lines"]:                          # (a speech bubble pops up)
                if ln.get("bubble"):                       # (just before its words, not on them)
                    put(_sfx("pop"), max(s["s"], ln["s"] - 0.15), 0.4)
        for ln in s["lines"]:
            if ln.get("wav") and Path(ln["wav"]).is_file():
                put(_read_wav(ln["wav"]), ln["s"], 1.0)
    peak = float(np.max(np.abs(out))) if len(out) else 0.0
    if peak > 0.98:
        out *= 0.98 / peak
    return out


def mouth_tracks(tl: dict) -> dict:
    """Per line: how open the mouth is in each picture (from the voice's loudness; without a voice, from the words)."""
    out = {}
    for i, s in enumerate(tl["scenes"]):
        for j, ln in enumerate(s["lines"]):
            n = max(1, int(math.ceil((ln["e"] - ln["s"]) * FPS)) + 2)
            if ln.get("wav") and Path(ln["wav"]).is_file():
                a = _read_wav(ln["wav"])
                hop = SR // FPS
                env = [float(np.sqrt(np.mean(a[k * hop:(k + 1) * hop] ** 2))) if k * hop < len(a) else 0.0 for k in range(n)]
                top = sorted(env)[int(len(env) * 0.95)] if env else 1.0
                env = [min(1.0, e_ / max(1e-4, top)) for e_ in env]
            else:                                          # syllables: open and close along the words
                env = []
                for k in range(n):
                    tt = ln["s"] + k / FPS
                    on = any(w["s"] <= tt <= w["e"] for w in ln["words"])
                    env.append((0.55 + 0.45 * math.sin(tt * 18.0)) if on else 0.0)
            out[f"{i}.{j}"] = ch.visemes(env, FPS)
    return out


def shape_tracks(tl: dict) -> dict:
    """Per line: the mouth's shape in each picture, from the sounds of its words (lip sync beyond open and closed)."""
    return {f"{i}.{j}": ch.sound_shapes(ln["words"], ln["s"], max(1, int(math.ceil((ln["e"] - ln["s"]) * FPS)) + 2), FPS)
            for i, s in enumerate(tl["scenes"]) for j, ln in enumerate(s["lines"])}


TURN_S = 0.22                  # seconds a character takes to turn round


def _facing(cv: Canvas, scene: dict, names: list, xs: list, box, key: str, t: float) -> int:
    """Where a character looks at time t (1 right, -1 left): to the one speaking or who spoke last (no turning back
    and forth in the pauses), else to the picture (a wide film), else to the middle."""
    j = max(0, _line_at(scene, t))                         # (before the first line: already to its speaker)
    talker = scene["lines"][j]["who"] if scene["lines"] else None
    x = xs[names.index(key)]
    if talker in names and talker != key:
        return 1 if xs[names.index(talker)] > x else -1
    if box and cv.SW >= cv.SH:
        return 1 if box[0] > x else -1
    return 1 if x < cv.SW / 2 else -1


def _hash01(*a) -> float:
    """A number 0..1 that looks random but is always the same for the same arguments."""
    x = math.sin(sum(float(v) * m for v, m in zip(a, (12.9898, 78.233, 37.719, 4.581)))) * 43758.5453
    return x - math.floor(x)


def _blink(t: float, k: int) -> float:
    """How shut the eyes are (0..1): a blink every 2-5 s at uneven times, now and then two in a row."""
    bt, n = _hash01(k, 1) * 2.0, 0
    while bt <= t and n < 4000:
        for b0 in ((bt, bt + 0.26) if _hash01(k, n, 7) > 0.85 else (bt,)):
            d = t - b0
            if 0 <= d < 0.15:
                return 0.35 if d < 0.03 or d >= 0.1 else 1.0
        bt += 2.0 + 3.0 * _hash01(k, n)
        n += 1
    return 0.0


def _stressed(w: dict) -> bool:
    """A word said with weight: a long one, a number, the end of a sentence."""
    word = str(w.get("w") or "")
    return len(re.sub(r"\W", "", word)) >= 7 or bool(re.search(r"\d", word)) or bool(re.search(r"[!?]$", word))


def _beat(ln: dict | None, t: float, dur: float = 0.38) -> float:
    """0..1: how far into a nod (and raised brows) the speaker is - on the words said with weight."""
    if not ln:
        return 0.0
    for w in ln.get("words") or []:
        d = t - float(w["s"])
        if 0 <= d <= dur and _stressed(w):
            return math.sin(math.pi * d / dur)
    return 0.0


# ------------------------------------------------------------------------------------------------- the film

TRANS_S = {"fade": 0.3, "slide": 0.4, "iris": 0.45}
_IRIS: dict = {}


def transition(prev: np.ndarray, cur: np.ndarray, st: float, same_place: bool, index: int) -> np.ndarray:
    """The first moments of a scene over the last picture of the one before: a cross-fade in the same place; to
    another place the new scene slides in, or opens as a circle (by turns)."""
    kind = "fade" if same_place else ("slide" if index % 2 else "iris")
    dur = TRANS_S[kind]
    if st >= dur:
        return cur
    a = max(0.0, st / dur)
    e = ease(a)
    if kind == "fade":
        return (cur.astype(np.float32) * a + prev.astype(np.float32) * (1 - a)).astype(np.uint8)
    h, w = cur.shape[:2]
    if kind == "slide":                                     # the old one out to the left, the new one in from the right
        off = int(round(w * e))
        if off <= 0:
            return prev
        return np.concatenate([prev[:, off:], cur[:, :off]], axis=1) if off < w else cur
    key = (h, w)
    if key not in _IRIS:                                    # each pixel's distance from the middle, 0..1
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        d = np.sqrt((xx - w / 2) ** 2 + (yy - h / 2) ** 2)
        _IRIS.clear()
        _IRIS[key] = d / float(d.max())
    m = np.clip((e * 1.08 - _IRIS[key]) / 0.04, 0, 1)[..., None]   # (a soft edge)
    return (cur.astype(np.float32) * m + prev.astype(np.float32) * (1 - m)).astype(np.uint8)


def captions_ass(tl: dict, width: int, height: int, opts: dict, work: Path, film: dict | None = None) -> Path | None:
    from .. import textfx as tf, voice as vo
    words = [w for s in tl["scenes"] for ln in s["lines"]                 # (a bubble shows its own words - when its speaker
             if not ln.get("bubble") or ln["who"] not in _shown(film or {}, s) for w in ln["words"]]   # is in the picture)
    if not words:
        return None
    o = tf.options(**opts)
    cs = vo.style_cues(words, o)
    p = work / "captions.ass"
    p.write_text(tf.document(width, height, cs, [], o, 0.0), "utf-8")
    return p


def scene_picture(script: dict, i: int, width: int = 400) -> bytes:
    """A small picture (JPEG) of scene i of a script, a little after it starts (its people and picture there)."""
    import cv2
    film = check_script(script)
    film["caption_at"] = ""
    scene = timeline(film)["scenes"][i]
    W, H = FORMATS[film["format"]]
    k = width / float(min(W, H)) if W < H else width / float(W)
    cv = Canvas(int(W * k * 2), int(H * k * 2), 1920 if W >= H else 1080, film.get("drawing") or "flat")
    t = min(scene["e"] - 0.05, scene["s"] + max(1.6, min(3.0, (scene["e"] - scene["s"]) / 2)))
    cv.push(0, 0)
    draw_frame(cv, film, scene, t, {})
    cv.pop()
    cv.finish()
    ok, buf = cv2.imencode(".jpg", cv2.resize(cv.img, (int(W * k), int(H * k)), interpolation=cv2.INTER_AREA),
                           [cv2.IMWRITE_JPEG_QUALITY, 85])
    return buf.tobytes() if ok else b""


_SAMPLES: dict = {}


def style_sample(style: str) -> bytes:
    """A small picture (JPEG) of a drawing style: a part of the example's road scene, drawn as the film draws it."""
    if style not in _SAMPLES:
        import cv2
        from . import textscript as T
        sc = dict(T.parse(T.ROAD_TEXT), format="horizontal")
        sc["cast"] = {k: dict(v, keep_look=True) for k, v in sc["cast"].items()}   # (the example's own people, always)
        film = check_script(sc)
        film["caption_at"] = ""
        scene = timeline(film)["scenes"][1]
        cv = Canvas(1920, 1080, 1920, style)
        cv.push(0, 0)
        draw_frame(cv, film, scene, scene["s"] + 1.6, {})
        cv.pop()
        cv.finish()
        part = cv.img[150:150 + 630, 20:20 + 1120]                      # (the one speaking and the road, closer)
        ok, buf = cv2.imencode(".jpg", cv2.resize(part, (320, 180), interpolation=cv2.INTER_AREA),
                               [cv2.IMWRITE_JPEG_QUALITY, 88])
        _SAMPLES[style] = buf.tobytes() if ok else b""
    return _SAMPLES[style]


def render(script: dict, out: Path, work: Path, voices: dict | None = None, captions: dict | None = None,
           progress=None, stop=None, sounds: bool = True, every: int = 1, music: dict | None = None) -> dict:
    """The film as an MP4. captions: the look of the captions (textfx options) or None for none. every: draw only
    every n-th picture (a quick preview); progress(share), stop() -> True ends it. music: {"kind": "made" (the
    program's own, "mood") or "file" ("path")} - quiet, lowered under the voices; None: none."""
    from .. import textfx as tf, voice as vo
    film = check_script(script)
    if film.get("site"):                                   # (the page's picture now: a page that cannot be read says so)
        from . import site as S
        try:
            film["_site_img"] = S.fetch(film["site"]["url"])["image"]
        except S.SiteError as exc:
            raise FilmError(str(exc))
    W, H = FORMATS[film["format"]]
    if captions is not None and H > W and pictures(film)["cast"] and (captions.get("position") or "middle") == "middle":
        captions = dict(captions, position="bottom")       # (picture characters are tall: the middle band is their face,
                                                           # the top one the scene's picture - over their legs is least in the way)
    film["caption_at"] = (((captions or {}).get("position") or ("middle" if H > W else "bottom")) if captions is not None
                          else "")                         # (close-ups keep the faces out of the captions)
    tl = timeline(film, voices)
    work.mkdir(parents=True, exist_ok=True)
    audio = mix(tl, sounds)
    if music and music.get("kind") in ("made", "file"):
        from . import music as M
        try:
            said = mix(tl, sounds=False)                    # (lowered for the voices, not for the whooshes)
            bed = M.bed(music["kind"], len(audio) / SR, said[:len(audio)], music.get("mood") or "light",
                        music.get("path") or "", vo._ffmpeg())
        except OSError:
            raise FilmError("The music file could not be read (or is not there any more).")
        if bed is not None:
            audio = audio + bed[:len(audio)]
            peak = float(np.max(np.abs(audio))) if len(audio) else 0.0
            if peak > 0.98:
                audio *= 0.98 / peak
    with wave.open(str(work / "sound.wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((np.clip(audio, -1, 1) * 32767).astype(np.int16).tobytes())
    vf = []
    if captions is not None:
        ass = captions_ass(tl, W, H, captions, work, film)
        if ass:
            fonts = tf.install_fonts(work)
            vf.append("ass=captions.ass" + (":fontsdir=fonts" if fonts else ""))
    vf.append("format=yuv420p")
    frames = int(math.ceil(tl["seconds"] * FPS))
    fps_out = FPS / max(1, every)
    enc = (["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0"] if vo.nvenc_ok() else
           ["-c:v", "libx264", "-preset", "medium" if every == 1 else "veryfast", "-crf", "19"])
    cmd = [vo._ffmpeg(), "-hide_banner", "-nostdin", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24",
           "-s", f"{W}x{H}", "-r", f"{fps_out:g}", "-i", "-", "-i", "sound.wav", "-vf", ",".join(vf), *enc,
           "-color_range", "tv", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
           "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", str(out.resolve())]
    from .. import auto_edit as ae
    from ..platform_adapter import process_kwargs
    errf = (work / "ffmpeg.log").open("wb")
    proc = subprocess.Popen(cmd, cwd=str(work), stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=errf,
                            **process_kwargs({}))
    ae._attach_job_object(proc)                            # (closed with the program; Stop and Quit end it)
    vo._track(proc)
    mouths = mouth_tracks(tl)
    shapes = shape_tracks(tl)
    cv = Canvas(W, H, 1920 if W >= H else 1080, film["drawing"])
    prev_last = None
    try:
        for f in range(0, frames, max(1, every)):
            if stop is not None and f % 30 == 0 and stop():
                raise FilmError("Stopped.")
            t = f / FPS
            si = next((i for i, s in enumerate(tl["scenes"]) if s["s"] <= t < s["e"]), len(tl["scenes"]) - 1)
            scene = tl["scenes"][si]
            m = {}
            for j, ln in enumerate(scene["lines"]):
                if ln["s"] <= t <= ln["e"]:
                    tr = mouths.get(f"{si}.{j}") or []
                    sh = shapes.get(f"{si}.{j}") or []
                    k = int((t - ln["s"]) * FPS)
                    m[ln["who"]] = (tr[k] if k < len(tr) else 0.0, sh[k] if k < len(sh) else "")
            cv.push(0, 0)
            draw_frame(cv, film, scene, t, m)
            cv.pop()
            cv.finish()
            st = t - scene["s"]
            if si > 0 and prev_last is not None:
                cv.img[:] = transition(prev_last, cv.img, st, tl["scenes"][si - 1].get("bg") == scene.get("bg"), si)
            if t + 1.0 / FPS * max(1, every) >= scene["e"]:
                prev_last = cv.img.copy()
            try:
                proc.stdin.write(cv.img.tobytes())
            except OSError:                                # (FFmpeg stopped: its own words say why)
                proc.wait(timeout=60)
                tail = (work / "ffmpeg.log").read_text("utf-8", errors="replace").strip().splitlines() or ["?"]
                raise FilmError("The film could not be encoded (" + tail[-1][:200] + ").")
            if progress is not None and f % 30 == 0:
                progress(f / max(1, frames))
        proc.stdin.close()
        rc = proc.wait()
    except BaseException:
        try:
            proc.kill()
            proc.wait(timeout=30)
        except Exception:
            pass
        raise
    finally:
        vo._untrack(proc)
        errf.close()
    err = (work / "ffmpeg.log").read_text("utf-8", errors="replace")
    if rc != 0 or not out.is_file():
        raise FilmError("The film could not be encoded (" + (err.strip().splitlines() or ["?"])[-1][:200] + ").")
    (work / "timeline.json").write_text(json.dumps(tl, ensure_ascii=False, indent=1), "utf-8")
    return {"seconds": tl["seconds"], "scenes": len(tl["scenes"]), "lines": sum(len(s["lines"]) for s in tl["scenes"]),
            "width": W, "height": H, "file": str(out)}
