MERCH FORGE · 050 NO-DISPATCH ARTWORK STAGING

PURPOSE
Prepare all 10 current finalists for real artwork creation/import without creating a paid provider job.

EVERY CONCEPT FOLDER CONTAINS
- GENERATION_BRIEF.json / .txt — same forge.local_generation_brief.v2 fields used by 050 manual bridge.
- PROMPT_APPAREL_V2.txt — compiled using the exact 050 forge.prompt.apparel.v2 logic.
- PROMPT_BINDING.json — exact revision/hash + prompt SHA + compiler/template provenance.
- IMPORT_TARGET.json — exact manual-import target and acceptance boundary.
- NO_DISPATCH_PROVIDER_PREVIEW.json — what the first paid Smoke action would require later, but dispatch=false.
- ARTWORK_DROP/README.txt — organizational slot only.

BOUNDARIES
- generation_job.v4 files created: 0
- provider requests: 0
- paid dispatch authorization: false
- artwork acceptance: 0
- external submission: false
- 050 core/UI/startup unchanged
- no 051 release

MANUAL PATH
Create artwork from the brief/prompt using any authorized workflow, then open the exact concept in Merch Forge 050 and click Import artwork.
Forge itself computes the actual file SHA-256 and exact revision binding. Import is not Acceptance.

PAID PATH LATER
Only after explicit owner configuration/credential/action.
The first live guard remains Smoke / one image / daily limit one.

GLOBAL PACKAGING RULE
Exactly one top-level folder.
