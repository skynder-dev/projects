Place candidate artwork here for organization only.
Do NOT treat this folder as an import. Use Merch Forge 050 → Import artwork on the exact current concept.
Import computes SHA-256 and binds the local file to the exact current revision. Acceptance is a separate explicit action.
