MERCH FORGE 045 · SELFTEST STATE RC

This cumulative prototype candidate is built directly from exact 041. The 041 startup guard remains unchanged.

CONCRETE PROTOTYPE FIXES IN 042
- Live backend is forge-app v74 / service 0.2.69. Server Generate now fails closed when no production server provider is ready, so one click cannot create a dead queued request.
- When current-revision local artwork or a local acceptance exists, Artwork / Checks / Publish now stay on the LocalCore workflow even while the backend is connected.
- Manual bridge is coherent end-to-end: export/import artwork -> exact local Accept -> local checks -> editable local listing -> local Amazon package.
- If no local artwork/state exists, the normal server workflow remains unchanged.

PRESERVED FROM 041
- startup guardian = 180 seconds
- seven direct self-test child processes = explicit 15-second bound
- trusted local check-worker = 15-second bound
- ready.flag on first Workbench ContentRendered, before backend/login
- Workbench/XAML SHA-256 unchanged: a6ded3002bf5042440a67b7270c5b7f43298346eb9de02d7c2725fb22bee0ed6
- automatic paid retry = false
- external submission = false
- no paid provider call was performed while building 042

TODAY'S PROTOTYPE MILESTONE
Extract All, then run START_048_MERCH_FORGE.vbs once.
Success = Forge window opens and startup self-test completes. Login without saved workspace access still counts as successful application startup.
Do not perform a paid generation as part of this startup test.

043 WINDOWS POWERSHELL 5.1 PREFLIGHT REPAIR
- Exact 042 native Windows evidence failed before Workbench: unified preflight exit 99.
- Replaced the .NET Core-only String.EndsWith(Char) call shape with the .NET Framework-compatible String.EndsWith(String,StringComparison) shape in preflight, check worker, and generation worker.
- Unified preflight now writes stage + exception details into the normal MerchForge launch log.
- Workbench/XAML/ProductNavigation/backend flow are unchanged from 042.


044 WINDOWS PACKAGE-ROOT REPAIR
- Exact 043 Windows evidence failed in PRECHECK [integrity]: GetFullPath received an illegal path string before Workbench.
- Launcher now canonicalizes %~dp0 through %~fI so PackageRoot has no trailing separator before it is quoted for powershell.exe.
- Preflight and child workers trim accidental wrapper quotes and resolve PackageRoot through Get-Item -LiteralPath before use.
- Integrity path containment uses filesystem-resolved FullName values instead of applying GetFullPath directly to raw argv.
- Workbench/XAML/ProductNavigation/backend remain unchanged from 043.


045 PROVIDER SELFTEST SCRIPT-SCOPE REPAIR
- Exact 044 reached provider_pipeline_selftest and failed with exit 48: $script:StateRoot was not initialized in the isolated selftest.
- The selftest recursively loads LocalCore -> PrintChecks; 045 initializes the complete discovered Workbench-style script-scope closure before those modules are used: StateRoot, ModuleRoot, LastPreviewSource, Publication, GenerationProviderRegistry, and GenerationProviderConfig.
- StateRoot remains isolated under the temporary selftest LOCALAPPDATA; no owner state is used or mutated.
- Workbench/XAML/ProductNavigation/backend are byte-identical to 044.
- Do not use 044 for startup; run START_048_MERCH_FORGE.vbs.

046 Windows PowerShell 5.1 language repair:
- exact 045 native Windows evidence reached provider_pipeline_selftest and failed because plain parenthesized if-expressions were treated as command invocations by WinPS 5.1;
- all shipped plain-parenthesized statement forms of this class are removed;
- Workbench/XAML, product navigation, startup root normalization, selftest state initialization, and backend remain otherwise unchanged.

047 WSH encoding repair:
- exact 046 outer START VBS was accidentally serialized with UTF-8 BOM EF BB BF;
- classic Windows Script Host rejected that BOM at Line 1, Char 1;
- 047 outer START VBS is strict ASCII + CRLF with no BOM;
- Forge PowerShell/runtime/UI/backend bytes are otherwise preserved from 046.

048 startup boundary repair:
- normal startup no longer runs the deep provider/Amazon business self-test before opening the Workbench;
- normal fatal preflight is limited to package integrity, PowerShell parse, WPF assemblies and XAML load;
- the deep provider pipeline self-test remains present as a diagnostic-only preflight switch and is not a launch gate;
- exact 047 Workbench, preflight, modules, workers and product flow are otherwise preserved.

049 CORE WORKING RC:
- exact 048 startup chain bytes are frozen; outer launcher content is unchanged and only its filename is START_050_MERCH_FORGE.vbs;
- product-core repairs only: robust local worker process launch, local/server action routing isolation, and pre-dispatch generation job cleanup;
- UI/theme/localization backlog intentionally deferred.

049 core lineage repair:
- manual imported artwork does not force a future local-provider Generate into Regenerate;
- Regenerate is allowed only from local-provider artwork with an exact generation_request_id lineage.

050 CORE repair:
- local trusted check requests are idempotent for identical revision/artwork/listing/profile/worker inputs;
- a cached result is accepted only when worker/request/revision/acceptance/artwork bindings all match;
- invalid cached results are discarded and the trusted worker is rerun;
- exact 048 golden inner startup/Workbench bytes remain unchanged.
