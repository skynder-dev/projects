# Merch Forge · Product navigation + global product surfaces
# Owns Home / Ideas / Artwork / Checks / Publish / Portfolio / Performance routing.
function Set-ProductNavSelected([string]$Section) {
    $buttons=@($NavHomeButton,$NavIdeasButton,$NavArtworkButton,$NavChecksButton,$NavPublishButton,$NavPortfolioButton,$NavPerformanceButton)
    foreach($b in $buttons){if($null -eq $b){continue};$active=([string]$b.Tag -eq $Section);$b.Background=if($active){$Window.FindResource('AccentSoft')}else{[Windows.Media.Brushes]::Transparent};$b.BorderBrush=if($active){$Window.FindResource('AccentStroke')}else{[Windows.Media.Brushes]::Transparent};$b.Foreground=if($active){$Window.FindResource('Text')}else{$Window.FindResource('Secondary')}}
}
function Hide-ProductSurfaces {
    foreach($surface in @($HomeLandingScroll,$SectionLandingScroll,$PortfolioLandingScroll,$PerformanceLandingScroll,$MainTabs)){if($null -ne $surface){$surface.Visibility='Collapsed'}}
}
function Test-CurrentLocalCoreActivity {
    if($null -eq $script:Current){return $false}
    try {
        $variants=@(Get-LocalCoreVariantsForCurrent)
        if($variants.Count -gt 0){return $true}
        $key=[string](Get-PropertyValue $script:Current.concept 'concept_key')
        if([string]::IsNullOrWhiteSpace($key)){return $false}
        $lc=Get-LocalCoreConcept $key
        if($null -eq $lc){return $false}
        $identity=Get-LocalCurrentRevisionIdentity $script:Current.concept
        $acc=Get-PropertyValue $lc 'active_acceptance'
        return ($null -ne $acc -and [string](Get-PropertyValue $acc 'concept_revision_id') -eq [string]$identity.id -and [string](Get-PropertyValue $acc 'revision_hash') -eq [string]$identity.hash)
    } catch { return $false }
}
function Set-SectionLanding([string]$Section) {
    $titleKey='section.ideas.title';$bodyKey='section.ideas.body';$fallbackTitle='Ideas';$fallbackBody='Choose an idea from the list to continue.'
    switch($Section){'artwork'{$titleKey='section.artwork.title';$bodyKey='section.artwork.body';$fallbackTitle='Artwork';$fallbackBody='Choose an idea to generate, compare and review artwork.'};'checks'{$titleKey='section.checks.title';$bodyKey='section.checks.body';$fallbackTitle='Checks';$fallbackBody='Choose an idea to review evidence.'};'publish'{$titleKey='section.publish.title';$bodyKey='section.publish.body';$fallbackTitle='Publish';$fallbackBody='Choose an accepted product to prepare listing metadata and delivery.'}}
    if($null -ne $SectionLandingTitle){$SectionLandingTitle.Text=Get-UiText $titleKey $fallbackTitle}; if($null -ne $SectionLandingBody){$SectionLandingBody.Text=Get-UiText $bodyKey $fallbackBody}
    if($null -ne $SectionLandingHint){$SectionLandingHint.Text=if($script:OfflineMode){Get-UiText 'backend.offline.body' 'Live workspace data is temporarily unavailable.'}else{Get-UiText 'home.ready.body' 'Live workspace data is available.'}}
}
function Update-GlobalBusinessSurfaces {
    # No synthetic commerce numbers. These stay em-dash until a live commerce adapter supplies verified values.
    foreach($v in @($HomeMetricPublishedValue,$HomeMetricSalesValue,$HomeMetricRoyaltiesValue,$HomeMetricAttentionValue)){if($null -ne $v){$v.Text='—'}}
    if($null -ne $HomeAlexBody){$HomeAlexBody.Text=if($script:OfflineMode){Get-UiText 'home.alex.offline' 'Reconnect to load decisions that need your attention.'}else{Get-UiText 'metric.waiting' 'Waiting for live data'}}
    if($null -ne $HomePerformanceBody){$HomePerformanceBody.Text=if($script:OfflineMode){Get-UiText 'home.performance.offline' 'Sales and royalties will appear here when live commerce data is connected.'}else{Get-UiText 'metric.waiting' 'Waiting for live data'}}
    try { Update-LocalCoreBusinessSurfaces } catch { Write-AppLog 'WARN' ('Local core business surface refresh failed: '+$_.Exception.Message) }
}
function Show-ProductSection([string]$Section) {
    if([string]::IsNullOrWhiteSpace($Section)){$Section='home'}
    $Section=$Section.ToLowerInvariant(); if(-not (@('home','ideas','artwork','checks','publish','portfolio','performance') -contains $Section)){$Section='home'}
    $script:ProductSection=$Section; Hide-ProductSurfaces; Set-ProductNavSelected $Section
    if($null -ne $ContextNav){$ContextNav.Visibility='Collapsed'}
    switch($Section){
        'home' { $HomeLandingScroll.Visibility='Visible'; if($null -ne $ConceptTitle){$ConceptTitle.Text=Get-UiText 'home.title' 'Business dashboard'}; if($null -ne $ConceptMeta){$ConceptMeta.Text=''} }
        'portfolio' { $PortfolioLandingScroll.Visibility='Visible'; if($null -ne $ConceptTitle){$ConceptTitle.Text=Get-UiText 'portfolio.title' 'Portfolio'}; if($null -ne $ConceptMeta){$ConceptMeta.Text=Get-UiText 'portfolio.body' 'Published products, channels and listing health.'} }
        'performance' { $PerformanceLandingScroll.Visibility='Visible'; if($null -ne $ConceptTitle){$ConceptTitle.Text=Get-UiText 'performance.title' 'Performance'}; if($null -ne $ConceptMeta){$ConceptMeta.Text=Get-UiText 'performance.body' 'Sales, royalties and product momentum.'} }
        default {
            if($null -eq $script:Current){
                $SectionLandingScroll.Visibility='Visible';Set-SectionLanding $Section
                if($null -ne $ConceptTitle){$ConceptTitle.Text=$SectionLandingTitle.Text}
                if($null -ne $ConceptMeta){$ConceptMeta.Text=if($script:OfflineMode){Get-UiText 'backend.offline.status' 'Workbench open · waiting for service'}else{''}}
            } elseif($script:OfflineMode -and $script:OfflineSnapshotMode) {
                if($Section -eq 'ideas'){
                    $MainTabs.Visibility='Visible';Enter-LocalCoreSection 'ideas'
                    if($null -ne $ContextNav){$ContextNav.Visibility='Collapsed'}
                } elseif($Section -in @('artwork','checks','publish')) {
                    Enter-LocalCoreSection $Section
                    if($null -ne $ConceptTitle){$ConceptTitle.Text=if($Section -eq 'artwork'){Get-UiText 'section.artwork.title' 'Artwork'}elseif($Section -eq 'checks'){Get-UiText 'section.checks.title' 'Checks'}else{Get-UiText 'section.publish.title' 'Publish'}}
                    if($null -ne $ConceptMeta){$ConceptMeta.Text=Get-UiText 'offline.snapshot.meta' 'Local snapshot · live service unavailable'}
                    if($null -ne $ContextNav){$ContextNav.Visibility='Collapsed'}
                } else {
                    $SectionLandingScroll.Visibility='Visible';Set-SectionLanding $Section
                }
            } else {
                $useLocalCore=(Test-CurrentLocalCoreActivity)
                if($useLocalCore -and $Section -in @('artwork','checks','publish')) {
                    Enter-LocalCoreSection $Section
                    if($null -ne $ContextNav){$ContextNav.Visibility='Collapsed'}
                } else {
                    $MainTabs.Visibility='Visible';Set-ConceptTabsEnabled $true
                    if($null -ne $ContextNav){$ContextNav.Visibility='Visible'}
                    switch($Section){'ideas'{Select-MainTab 'Overview'};'artwork'{Select-MainTab 'Visuals & Generate'};'checks'{Select-MainTab 'Evidence'};'publish'{Select-MainTab 'Publication'}}
                    Update-MainTabUi
                }
            }
        }
    }
    Update-GlobalBusinessSurfaces;Update-ResponsiveLayout
}
function Show-HomeLanding([bool]$Offline=$false) { $script:OfflineMode=$Offline;Show-ProductSection 'home' }
function Show-ConceptSurface { if($null -eq $script:Current){Show-ProductSection $script:ProductSection;return};if(@('home','portfolio','performance') -contains $script:ProductSection){$script:ProductSection='ideas'};Show-ProductSection $script:ProductSection }
function Go-Home { Show-ProductSection 'home' }
