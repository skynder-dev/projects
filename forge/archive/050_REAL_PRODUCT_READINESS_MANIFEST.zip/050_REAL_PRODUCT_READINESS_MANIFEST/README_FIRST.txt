MERCH FORGE · 050 REAL PRODUCT READINESS MANIFEST

This is the single consolidated pre-acceptance readiness pack for the current 10 finalists.

Included:
- READINESS_MANIFEST.json — canonical structured status and gate order.
- READINESS_MATRIX.csv — one row per finalist.
- NEXT_AFTER_REAL_ACCEPT.txt — exact operational order once a real artwork is accepted.
- prepared/050_REAL_PRODUCT_METADATA_DRAFT_PACK.zip
- prepared/050_REAL_PRODUCT_POLICY_PREFLIGHT_PREP.zip
- prepared/050_Amazon_Print_Profile_Capture_Helper.zip

Important:
- This does NOT create an acceptance, publication draft, policy PASS, IP PASS, or external submission.
- USPTO prescreen remains fail-closed because worker heartbeat is stale and daily coverage is partial.
- Exact Amazon product/template/color facts remain owner-attested from the current Amazon template.
- 050 core/UI/startup were not modified.
- No 051 release was created.

GLOBAL PACKAGING RULE:
The delivery ZIP contains exactly one top-level folder.
