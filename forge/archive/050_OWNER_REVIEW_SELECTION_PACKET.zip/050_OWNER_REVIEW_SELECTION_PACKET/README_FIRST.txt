MERCH FORGE · 050 OWNER REVIEW / SELECTION PACKET

START
Open OPEN_REVIEW.html.

WHAT IT IS
- 10 exact current finalist concept cards.
- Each card shows hook, audience, why the joke works, visual direction, listing draft,
  current revision/hash, prompt SHA, IP state and avoid-list.
- Choose KEEP / EDIT / REGEN / SKIP and add notes.
- Decisions save only in the browser's localStorage for this exact packet.
- Export decisions with the 'Export decisions JSON' button.

DECISION MEANING
KEEP  = keep the concept as-is for artwork creation/import.
EDIT  = revise concept/copy/visual direction before artwork.
REGEN = keep the idea but ask for a different visual/generation direction.
SKIP  = do not spend artwork effort on this concept now.

IMPORTANT
These are concept decisions, NOT artwork Accept.
This packet performs no network calls, provider calls, Supabase writes, acceptance,
publication, or external submission.

SOURCE/
Contains the exact prepared no-dispatch staging, metadata draft, and unified readiness packs.

GLOBAL PACKAGING RULE
This ZIP contains exactly one top-level folder.
