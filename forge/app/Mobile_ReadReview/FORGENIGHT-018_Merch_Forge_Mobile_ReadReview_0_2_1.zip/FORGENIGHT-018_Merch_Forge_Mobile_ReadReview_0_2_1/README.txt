MERCH FORGE MOBILE READ/REVIEW 0.2.1

Purpose
- Phone/tablet companion for the SAME Forge backend as desktop.
- Official client mode is read/review only.
- It can read concept cards/details, compare/load previews, read history/gates, and write only soft review_variant_v2 events when the token has review capability.
- Network actions are enforced by a positive allowlist: mobile_bootstrap, mobile_concept, review_variant_v2, asset_preview_ticket. Every other backend action is rejected locally before fetch.

Explicitly absent from this client
- save_revision
- create_generation_request / cancel_generation_request
- accept_visual_v2 / reopen_acceptance_v2 / start_review_iteration
- publication/package preparation or external Submit

Localization
- EN / RU / ES shell labels.
- Locale is sent to mobile_bootstrap/mobile_concept.
- The ten current owner explanations include the same exact-revision-bound RU/ES overlays as canonical 010R2H desktop Workbench.
- Creative hook/title/design copy remains source-language by design.

Backend contract
- Requires forge-app >= 0.2.68 and MOBILE_CONTRACT 1.2 official_client_mode=read_review_only.
- Fails closed on an older backend.

Pinned reconciliation lineage
- Reconciliation source outer package: 010R2H_Merch_Forge_OWNER_STARTUP_TEST.zip sha256 d07e8283449fd6d14fe7156e0b07764b110ba42d7daeb0514cb4d05fd1131c33
- Promotion target: 010R2I_Merch_Forge_OWNER_STARTUP_TEST.zip
- Canonical Desktop Workbench: sha256 9d87ba9322e0ca535bf5a2bc2c0d879eebddfea0f695f31849ab07730f88cc36
- forge-app: Edge v73 / app 0.2.68 / ezbr_sha256 63f41df58a53ceeffddbfa478f6a5126c673960f510bb6412e64d484226fa69d
- Mobile contract: 1.2 / official_client_mode=read_review_only
