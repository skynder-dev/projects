﻿MERCH FORGE 069 Merch Forge START FIX RC

ПО-РУССКИ
1. Распакуйте всю папку: правый клик по ZIP -> «Извлечь все».
2. Запустите START_069_MERCH_FORGE.vbs двойным щелчком.
3. Как пользоваться (1 страница): HOW_TO_USE_RU.txt

START
1. Extract the whole folder.
2. Run START_069_MERCH_FORGE.vbs.

WHAT IS NEW (069)
- FIX (old, since 054 or earlier): double-clicking START_0xx_MERCH_FORGE.vbs showed
  "Windows Script Host: Invalid character, line 1" and the app did not open. The file started with a
  UTF-8 marker that Windows Script Host cannot read. Removed; the build now refuses such .vbs files.
  (Install Merch Forge.vbs and the desktop shortcut were not affected.)
- Proven on Windows from the release ZIP: START opens the window and exits cleanly; fresh install;
  upgrade over the previous version keeps it as app.previous and the installed app starts;
  installing an older version over a newer one is refused.
- Includes 068 and earlier (055-067).
