MERCH FORGE 056 Merch Forge WINDOWS FIXES RC

START
1. Extract the whole folder.
2. Run START_056_MERCH_FORGE.vbs.

WHAT IS NEW (056 = 055 + fixes found by the first run on real Windows)
- Language switch no longer resets live screens: Discover keeps its numbers and the selected niche,
  an open research draft re-renders in the new language.
- Status bar no longer says "Working..." after Discover has finished loading.
- Windows PowerShell 5.1: generation spool cleanup no longer fails on an empty folder ("property 'Sum'").
- Everything from 055: Discover > select niche > "Create concept draft" makes a LOCAL draft bound to its research,
  shown in Ideas, with KEEP / EDIT / REGEN / SKIP, local revisions and a no-dispatch brief.

PROOF
- Every change is tested automatically on a real Windows machine by the GitHub workflow "forge-windows":
  startup preflight, PowerShell 5.1 self-test, and the real app window driven by clicks, with screenshots.

SAFETY
- No backend change, no paid provider call, no publishing, no Supabase mutation.
