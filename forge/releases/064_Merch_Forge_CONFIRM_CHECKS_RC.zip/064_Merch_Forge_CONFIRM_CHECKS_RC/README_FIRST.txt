MERCH FORGE 064 Merch Forge CONFIRM CHECKS RC

START
1. Extract the whole folder.
2. Run START_064_MERCH_FORGE.vbs.

WHAT IS NEW (064)
- Checks -> new "Confirm checks..." button: a form with a plain checklist for IP (trademarks/copyright),
  Amazon Merch content policy and listing text. For each one choose: all good / needs more checking /
  problem / leave as is. "All good" needs a link or a short note and the "I checked this myself" tick.
  The form writes the same evidence file as before and imports it through the same validation.
- A plain-language CHECKLIST.txt is written next to the JSON evidence template (in the app language).
- "Open checks folder" button.
- Clearer import errors: broken JSON, and "evidence is for another revision/artwork/listing" now say what to do.
- Error messages built from the app's own texts (any language) are shown as-is, not as a generic error.
- Includes 063 and earlier (055-062).
