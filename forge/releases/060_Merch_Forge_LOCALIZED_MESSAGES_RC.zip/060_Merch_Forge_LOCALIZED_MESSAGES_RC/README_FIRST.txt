MERCH FORGE 060 Merch Forge LOCALIZED MESSAGES RC

START
1. Extract the whole folder.
2. Run START_060_MERCH_FORGE.vbs.

WHAT IS NEW (060)
- Status bar, "working" banner, error and confirmation messages are now shown in Russian / Spanish when the UI
  language is RU / ES (154 messages; numbers, paths and statuses inside a message are kept as they are).
  Unknown messages fall back to English.
- Includes 059 (full local package path proven on Windows, local artwork selection fix, royalty amounts),
  058 (Portfolio pipeline board), 057, 056, 055.

SAFETY
- No backend change, no paid provider call, no publishing, no Supabase mutation.
