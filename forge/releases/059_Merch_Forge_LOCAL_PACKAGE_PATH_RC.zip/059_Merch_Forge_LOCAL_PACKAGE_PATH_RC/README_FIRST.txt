MERCH FORGE 059 Merch Forge LOCAL PACKAGE PATH RC

START
1. Extract the whole folder.
2. Run START_059_MERCH_FORGE.vbs.

WHAT IS NEW (059)
- The full local path from a research draft to a READY package, publication receipt and sales is now
  exercised end-to-end on a real Windows machine by CI (accepted artwork -> owner-attested Amazon profile ->
  listing -> trusted print check -> owner evidence -> READY_FOR_MANUAL_UPLOAD package -> receipt -> sales).
- Imports (check evidence, publication receipt, sales CSV) are split into "choose file" and "process file";
  behaviour in the app is unchanged.
- "Import Amazon Print Profile" accepts -SourcePath and -NonInteractive (used by CI; normal double-click unchanged).
- Draft provenance also stores source url / authority level / last checked (fields the live server sends).
- Includes 058 (Portfolio pipeline board), 057 (Amazon profile, PNG check, first trusted check), 056, 055.

SAFETY
- No backend change, no paid provider call, no publishing, no Supabase mutation. CI uses labelled fixtures only.
