MERCH FORGE 066 Merch Forge CRASH HUNT RC

START
1. Extract the whole folder.
2. Run START_066_MERCH_FORGE.vbs.

WHAT IS NEW (066)
- Checks list is readable: "IP · passed", "Artwork · passed", "Print file · passed"... in the app language,
  common check notes translated.
- Coming back to an idea from Portfolio/Performance/Home/Discover shows the idea's title again
  (before, the header could still say "Portfolio" while you were in Checks).
- Amazon profile days left are rounded up (30-day profile shows 30, not 29).
- New Windows test phase "backend down": every button in every section and tab is clicked with the server
  unavailable; any crash fails the build.
- Includes 065 and earlier (055-064).
