from __future__ import annotations

import base64, hashlib, json, os, shutil, subprocess, sys, tempfile, time, urllib.parse, urllib.request, webbrowser, zipfile
from datetime import datetime, timezone
from pathlib import Path

LAUNCHER_VERSION = "3.9.3"
HOME = Path(__file__).resolve().parent          # program folder of this release
SIDE_BY_SIDE = (HOME / "port.txt").exists()

def data_root():
    """Same rule as archivist.config.data_root_for (kept here so the launcher works even if app/ is broken):
    a side-by-side release keeps user data OUTSIDE its own folder, remembered in %LOCALAPPDATA%\\MediaEngine."""
    if not SIDE_BY_SIDE: return HOME
    env=os.environ.get('MEDIAENGINE_DATA')
    if env: return Path(env).resolve()
    ptr=Path(os.environ.get('LOCALAPPDATA') or str(Path.home()/'.local'/'share'))/'MediaEngine'/'data_root.txt'
    try:
        remembered=Path(ptr.read_text(encoding='utf-8-sig').strip())
        if remembered.is_absolute() and remembered.is_dir(): return remembered.resolve()
        if remembered.is_absolute(): return (HOME.parent/'MediaEngine Data').resolve()
    except Exception: pass
    root=(HOME.parent/'MediaEngine Data').resolve()
    try: root.mkdir(parents=True,exist_ok=True)
    except Exception:
        root=(ptr.parent/'Data').resolve()          # read-only release location: data in the user's profile
        try: root.mkdir(parents=True,exist_ok=True)
        except Exception: pass
    try: ptr.parent.mkdir(parents=True,exist_ok=True); ptr.write_text(str(root),encoding='utf-8')
    except Exception: pass
    return root

DATA = data_root() / "data"
VERSION_PATH = HOME / "version.txt"
CONFIG_PATH = HOME / "updater_config.json"
STATUS_PATH = DATA / "update_status.json"
START_WAIT_S = 420       # first start on a slow PC (antivirus scanning a fresh runtime) can take minutes

def _port():
    """8765 for the stable install. A side-by-side install ships port.txt; if that file is present but
    unreadable we stop (None) rather than fall back to 8765 and open/mix with the stable install."""
    f=HOME/"port.txt"
    if not f.exists(): return 8765
    try:
        p=int(f.read_text(encoding="utf-8-sig").strip())
        return p if 1024<=p<=65535 else None
    except Exception:
        return None

HOST, PORT = "127.0.0.1", _port()
_MUTEX = None
LAST_UPDATE_CHECK = "not_checked"

def single_instance():
    """True if this is the only launcher for this install/port right now (Windows named mutex). Per install: the
    launcher of ANOTHER build that is still finishing (it exits a moment after its app answers) must not make this one
    think "my own launcher is already starting it" and quietly do nothing - the switch to this build then never
    happened (seen in CI b101)."""
    global _MUTEX
    if os.name!='nt': return True
    try:
        import ctypes, hashlib
        k=ctypes.windll.kernel32
        tag=hashlib.sha256(os.path.normcase(str(HOME.resolve())).encode('utf-8')).hexdigest()[:12]
        _MUTEX=k.CreateMutexW(None,False,f"Local\\MediaEngineLauncher-{PORT}-{tag}")
        return k.GetLastError()!=183   # ERROR_ALREADY_EXISTS
    except Exception:
        return True


def version_tuple(v):
    out=[]
    for part in str(v).split('.'):
        n=''.join(c for c in part if c.isdigit()); out.append(int(n or 0))
    return tuple((out+[0,0,0])[:3])

def version_key(v):
    """Release ordering with pre-releases: 3.13.0-rc1 < 3.13.0-rc2 < 3.13.0 (version_tuple treats them as equal)."""
    import re
    m=re.match(r'\s*(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:[-.]?(alpha|beta|rc|a|b)(\d*))?',str(v or ''))
    if not m: return (0,0,0,0,0)
    pre={'a':0,'alpha':0,'b':1,'beta':1,'rc':2}.get((m.group(4) or '').lower(),3)
    return (int(m.group(1) or 0),int(m.group(2) or 0),int(m.group(3) or 0),pre,int(m.group(5) or 0))

def current_version():
    try: return VERSION_PATH.read_text(encoding='utf-8').strip() or '0.0.0'
    except Exception: return '0.0.0'

def write_status(**fields):
    try:
        DATA.mkdir(parents=True,exist_ok=True)
        p={"at":datetime.now(timezone.utc).isoformat(),**fields}; t=STATUS_PATH.with_suffix('.tmp'); t.write_text(json.dumps(p,indent=2),encoding='utf-8'); t.replace(STATUS_PATH)
    except Exception: pass

# calls to our own server never go through a system proxy (with a VPN / proxy tool on, Python sent 127.0.0.1 to the
# proxy: no answer, the launcher waited and gave up)
_LOCAL_HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def server_alive(timeout=.35):
    try:
        with _LOCAL_HTTP.open(f'http://{HOST}:{PORT}/api/ping',timeout=timeout) as r: return r.status==200
    except Exception: return False

def running_install(tries=1):
    """Program folder of the MediaEngine answering on our port ('' = an older build that does not say; None = no answer).
    tries>1: a MediaEngine that has just started can be slow to answer (seen in CI b91: the switch never happened)."""
    for k in range(max(1,int(tries))):
        try:
            with _LOCAL_HTTP.open(f'http://{HOST}:{PORT}/api/ping',timeout=2+2*k) as r:
                return str(json.loads(r.read().decode('utf-8','replace')).get('install') or '')
        except Exception:
            if k+1<tries: time.sleep(.5)
    return None


def launcher_log(msg):
    """What the launcher decided, for support (data folder: logs/launcher.log). Never fails."""
    try:
        logs=DATA/'logs'; logs.mkdir(parents=True,exist_ok=True); f=logs/'launcher.log'
        if f.is_file() and f.stat().st_size>1_000_000: os.replace(f,logs/'launcher.1.log')
        with open(f,'a',encoding='utf-8') as fh: fh.write(f"{datetime.now().isoformat(timespec='seconds')} {HOME.name}: {msg}\n")
    except Exception: pass

def same_folder(a,b):
    try: return os.path.normcase(str(Path(a).resolve()))==os.path.normcase(str(Path(b).resolve()))
    except Exception: return False

def build_order(folder):
    """Order of a release folder 'MediaEngine-3.13.0-rc1-b137' (version, then build); None when its name does not say."""
    import re
    m=re.match(r'MediaEngine-(.+)-b(\d+)$',re.split(r'[\\/]',str(folder or '').rstrip('\\/'))[-1])
    return (version_key(m.group(1)),int(m.group(2))) if m else None

def switch_question(here,there):
    """What starting this build does while another build runs: 'switch' without asking when this one is newer (the
    owner just installed it - closing the window leaves the old one running in the background, so the question came
    after every install), else 'ask_older' (this one is older) or 'ask' (cannot tell)."""
    mine,theirs=build_order(here),build_order(there)
    if mine and theirs and mine>theirs: return 'switch'
    if mine and theirs and mine<theirs: return 'ask_older'
    return 'ask'

def ui_ru():
    """Same choice as the app (i18n.ui_language): a new Setup run's language first, then the language chosen in the
    app (config.json in the data folder), then the Windows display language."""
    try:
        cfg=json.loads((data_root()/'config.json').read_text(encoding='utf-8'))
    except Exception: cfg={}
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,r'Software\MediaEngine') as k:
            lang=str(winreg.QueryValueEx(k,'Language')[0] or '').lower()
            try: build=str(winreg.QueryValueEx(k,'LanguageBuild')[0] or '')
            except OSError: build=''
        if lang in ('ru','en') and build and f'{lang}|{build}'!=str(cfg.get('setup_language_applied') or ''): return lang=='ru'
    except Exception: lang=''
    v=str(cfg.get('ui_language') or '').lower()
    if v in ('ru','en'): return v=='ru'
    if lang in ('ru','en'): return lang=='ru'
    try:
        import ctypes
        return (ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF)==0x19
    except Exception: return False

def message_box(text,yes_no=False):
    """Plain Windows message (the launcher has no console and no window of its own). Returns True for Yes/OK."""
    try:
        import ctypes
        flags=(0x4|0x20) if yes_no else 0x40    # MB_YESNO|MB_ICONQUESTION or MB_ICONINFORMATION
        return ctypes.windll.user32.MessageBoxW(None,str(text),'MediaEngine',flags|0x40000|0x10000) in (1,6)   # TOPMOST|SETFOREGROUND
    except Exception:
        return False

def stop_running():
    """Ask the running MediaEngine to quit (same request as its Quit button). False when it is busy building."""
    req=urllib.request.Request(f'http://{HOST}:{PORT}/api/app-control',data=b'{"mode":"stop"}',method='POST',
                               headers={'Content-Type':'application/json','Origin':f'http://{HOST}:{PORT}'})
    try:
        with _LOCAL_HTTP.open(req,timeout=10) as r: return r.status==200
    except Exception:
        return False

def edge_candidates():
    candidates = []
    local = os.environ.get('LOCALAPPDATA')
    pf86 = os.environ.get('PROGRAMFILES(X86)')
    pf = os.environ.get('PROGRAMFILES')
    if local: candidates.append(Path(local)/'Microsoft'/'Edge'/'Application'/'msedge.exe')
    if pf86: candidates.append(Path(pf86)/'Microsoft'/'Edge'/'Application'/'msedge.exe')
    if pf: candidates.append(Path(pf)/'Microsoft'/'Edge'/'Application'/'msedge.exe')
    found = shutil.which('msedge.exe') or shutil.which('msedge')
    if found: candidates.append(Path(found))
    seen=set()
    for p in candidates:
        try: key=str(p.resolve()).lower()
        except Exception: key=str(p).lower()
        if key in seen: continue
        seen.add(key)
        if p.exists(): yield p

def open_user_interface(force_browser=False):
    url=f'http://{HOST}:{PORT}/'+('auto' if SIDE_BY_SIDE else '')   # MediaEngine opens on its projects (Auto Edit)
    if not force_browser and os.name=='nt':
        for edge in edge_candidates():
            try:
                # normal priority (playback in the review player must not stutter); cwd outside the install
                # so the folder can be deleted/replaced while the window is open
                kw={'creationflags':getattr(subprocess,'DETACHED_PROCESS',0)} if os.name=='nt' else {'start_new_session':True}
                subprocess.Popen([str(edge), f'--app={url}', '--start-maximized'], cwd=str(edge.parent), close_fds=True, **kw)
                write_status(status='shell_opened', version=current_version(), shell='edge_app')
                return 'edge_app'
            except Exception:
                pass
    webbrowser.open(url)
    write_status(status='shell_opened', version=current_version(), shell='browser')
    return 'browser'

def is_app_window_title(title):
    """A MediaEngine page in an Edge app window (same rule as the tray icon, archivist/tray.py): every page title ends
    with ' · MediaEngine'; the stable install uses ' · Archivist', a browser tab adds ' - Microsoft Edge'."""
    t=str(title or '')
    return t.endswith(' · MediaEngine') and t!='· MediaEngine'      # a browser tab ends with '- Microsoft Edge'

def _app_windows():
    """The visible MediaEngine windows (Edge app windows, title rule above), with the Win32 functions used on them."""
    if os.name!='nt': return [],None
    import ctypes
    from ctypes import wintypes as wt
    u=ctypes.WinDLL('user32'); k=ctypes.WinDLL('kernel32')
    ENUM=ctypes.WINFUNCTYPE(wt.BOOL,wt.HWND,wt.LPARAM)
    u.EnumWindows.argtypes=[ENUM,wt.LPARAM]; u.IsWindowVisible.argtypes=[wt.HWND]; u.IsIconic.argtypes=[wt.HWND]
    u.GetClassNameW.argtypes=[wt.HWND,wt.LPWSTR,ctypes.c_int]; u.GetWindowTextW.argtypes=[wt.HWND,wt.LPWSTR,ctypes.c_int]
    u.GetWindowThreadProcessId.argtypes=[wt.HWND,ctypes.POINTER(wt.DWORD)]
    u.ShowWindow.argtypes=[wt.HWND,ctypes.c_int]; u.SetForegroundWindow.argtypes=[wt.HWND]
    u.PostMessageW.argtypes=[wt.HWND,wt.UINT,wt.WPARAM,wt.LPARAM]
    k.OpenProcess.restype=wt.HANDLE; k.OpenProcess.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD]
    k.QueryFullProcessImageNameW.argtypes=[wt.HANDLE,wt.DWORD,wt.LPWSTR,ctypes.POINTER(wt.DWORD)]
    k.CloseHandle.argtypes=[wt.HANDLE]
    found=[]
    def each(h,_):
        try:
            if not u.IsWindowVisible(h): return True
            c=ctypes.create_unicode_buffer(64); u.GetClassNameW(h,c,64)
            if c.value!='Chrome_WidgetWin_1': return True
            t=ctypes.create_unicode_buffer(512); u.GetWindowTextW(h,t,512)
            if not is_app_window_title(t.value): return True
            pid=wt.DWORD(0); u.GetWindowThreadProcessId(h,ctypes.byref(pid))
            ph=k.OpenProcess(0x1000,False,pid.value)
            if ph:
                try:
                    b=ctypes.create_unicode_buffer(1024); n=wt.DWORD(1024)
                    if k.QueryFullProcessImageNameW(ph,0,b,ctypes.byref(n)) and os.path.basename(b.value).lower()=='msedge.exe':
                        found.append(h)
                finally: k.CloseHandle(ph)
        except Exception: pass
        return True
    cb=ENUM(each); u.EnumWindows(cb,0)
    return found,u

def focus_app_window():
    """Bring an open MediaEngine window to the front instead of opening a second one. False when there is none or
    Windows does not let this launcher take the front (then a window is opened, as before)."""
    try:
        found,u=_app_windows()
        if not found: return False
        if not u.SetForegroundWindow(found[0]): return False
        if u.IsIconic(found[0]): u.ShowWindow(found[0],9)       # SW_RESTORE
        write_status(status='shell_focused',version=current_version())
        return True
    except Exception:
        return False

def close_app_windows():
    """Close the open MediaEngine windows (after a takeover, right before this build opens its own: one window, and
    never a moment without one while the new build was still starting)."""
    try:
        found,u=_app_windows()
        for h in found: u.PostMessageW(h,0x0010,0,0)          # WM_CLOSE
        return len(found)
    except Exception:
        return 0

def close_windows_after_new(old, seconds=10):
    """After a takeover: close the old build's windows once a new MediaEngine window is there. Closing Edge's last
    window first could make Edge drop the new one (no window at all); no new window in time: both stay."""
    end=time.time()+seconds
    while time.time()<end:
        try:
            now,u=_app_windows()
            if any(h not in old for h in now):
                for h in old: u.PostMessageW(h,0x0010,0,0)      # WM_CLOSE
                return len(old)
        except Exception:
            return 0
        time.sleep(.4)
    return 0

def last_started_build():
    """The build the Start-menu (or desktop) shortcut starts. Every build points them at itself when it starts - also
    builds older than start at sign-in - so a start at sign-in follows a rollback to such a build."""
    if os.name!='nt': return None
    try:
        import importlib.util
        spec=importlib.util.spec_from_file_location('me_platform_adapter',str(HOME/'app'/'archivist'/'platform_adapter.py'))
        pa=importlib.util.module_from_spec(spec); spec.loader.exec_module(pa)
        for csidl,name in ((0x02,'MediaEngine.lnk'),(0x10,'MediaEngine RC.lnk')):
            d=pa.shell_folder(csidl)
            if d is None or not (d/name).is_file(): continue
            arg=str(pa.read_shell_link(d/name).get('arguments') or '').strip().strip('"')
            if arg.lower().endswith('start mediaengine.vbs'):
                return Path(arg).parent
    except Exception:
        pass
    return None

def wait_for_data_folder(seconds=180):
    """At sign-in the remembered data folder can be on a drive that comes a little later (USB, network, a drive
    unlocked after sign-in). Wait for it rather than start on an empty folder; False: it did not come."""
    global DATA,STATUS_PATH
    if not SIDE_BY_SIDE or os.environ.get('MEDIAENGINE_DATA'): return True
    ptr=Path(os.environ.get('LOCALAPPDATA') or str(Path.home()/'.local'/'share'))/'MediaEngine'/'data_root.txt'
    try: remembered=Path(ptr.read_text(encoding='utf-8-sig').strip())
    except Exception: return True                # never started yet: the default place
    if not remembered.is_absolute(): return True
    end=time.time()+seconds
    while not remembered.is_dir():
        if time.time()>end: return False
        time.sleep(5)
    DATA=data_root()/'data'; STATUS_PATH=DATA/'update_status.json'
    return True

def hidden_kwargs():
    kw={}
    if os.name=='nt':
        kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'DETACHED_PROCESS',0)|getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0)
        si=subprocess.STARTUPINFO(); si.dwFlags|=getattr(subprocess,'STARTF_USESHOWWINDOW',1); si.wShowWindow=getattr(subprocess,'SW_HIDE',0); kw['startupinfo']=si
    else: kw['start_new_session']=True
    return kw

def fetch_latest(cfg):
    base=cfg['supabase_url'].rstrip('/')+'/rest/v1/archivist_releases'
    params={'select':'version,bundle_b64,bundle_sha256,artifact_url,artifact_size_bytes,notes,min_launcher_version,created_at','channel':'eq.'+cfg.get('channel','stable'),'active':'eq.true','order':'created_at.desc','limit':'10'}
    req=urllib.request.Request(base+'?'+urllib.parse.urlencode(params),headers={'apikey':cfg['publishable_key'],'Accept':'application/json','User-Agent':f'ArchivistUpdater/{LAUNCHER_VERSION}'})
    with urllib.request.urlopen(req,timeout=10) as resp: rows=json.loads(resp.read().decode('utf-8'))
    rows.sort(key=lambda r:version_key(r.get('version','0')),reverse=True)
    return rows[0] if rows else None

def fetch_version(cfg, version):
    base=cfg['supabase_url'].rstrip('/')+'/rest/v1/archivist_releases'
    params={'select':'version,bundle_b64,bundle_sha256,artifact_url,artifact_size_bytes,notes,min_launcher_version,created_at','version':'eq.'+str(version),'limit':'1'}
    req=urllib.request.Request(base+'?'+urllib.parse.urlencode(params),headers={'apikey':cfg['publishable_key'],'Accept':'application/json','User-Agent':f'ArchivistUpdater/{LAUNCHER_VERSION}'})
    with urllib.request.urlopen(req,timeout=15) as resp: rows=json.loads(resp.read().decode('utf-8'))
    return rows[0] if rows else None

def safe_extract(zf,dest):
    root=dest.resolve()
    for info in zf.infolist():
        target=(dest/info.filename).resolve()
        if root!=target and root not in target.parents: raise RuntimeError('Unsafe path in update bundle')
    zf.extractall(dest)

def install_requirements(old_req,new_req):
    if not new_req.exists() or (old_req is not None and old_req==new_req.read_bytes()): return
    py=HOME/'.venv'/'Scripts'/'python.exe'
    if not py.exists(): raise RuntimeError('Python environment is missing')
    
    kw={}
    if os.name=='nt':
        kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0)
        si=subprocess.STARTUPINFO(); si.dwFlags|=getattr(subprocess,'STARTF_USESHOWWINDOW',1); si.wShowWindow=getattr(subprocess,'SW_HIDE',0); kw['startupinfo']=si
    subprocess.run([str(py),'-m','pip','install','--disable-pip-version-check','--quiet','-r',str(new_req)],check=True,**kw)

def prune_backups(keep=6):
    root=DATA/'update_backups'
    try:
        dirs=sorted([p for p in root.iterdir() if p.is_dir()], key=lambda p:p.stat().st_mtime, reverse=True)
        for p in dirs[int(keep):]: shutil.rmtree(p,ignore_errors=True)
    except Exception: pass


MAX_ARTIFACT_BYTES = 512 * 1024 * 1024

def _artifact_origin(url):
    p=urllib.parse.urlsplit(str(url or '').strip())
    if p.scheme.lower()!='https' or not p.hostname or p.username or p.password or p.fragment:
        raise RuntimeError('Artifact URL must be an absolute HTTPS URL')
    try:
        port=p.port or 443
    except ValueError:
        raise RuntimeError('Artifact URL port is invalid')
    return (p.scheme.lower(),p.hostname.lower(),int(port))

class _SameOriginArtifactRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if _artifact_origin(req.full_url)!=_artifact_origin(newurl):
            raise RuntimeError('Artifact redirect changed origin')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def _release_bytes(rel):
    url=str(rel.get('artifact_url') or '').strip()
    if not url:
        raw=base64.b64decode(rel['bundle_b64'],validate=True)
        if len(raw)>MAX_ARTIFACT_BYTES:
            raise RuntimeError('Legacy update bundle exceeds size ceiling')
        return raw
    try:
        declared=int(rel.get('artifact_size_bytes') or 0)
    except Exception:
        raise RuntimeError('Artifact size is invalid')
    if declared<=0 or declared>MAX_ARTIFACT_BYTES:
        raise RuntimeError('Artifact size exceeds allowed bounds')
    origin=_artifact_origin(url)
    opener=urllib.request.build_opener(_SameOriginArtifactRedirect())
    req=urllib.request.Request(url,headers={'Accept':'application/octet-stream','User-Agent':f'ArchivistUpdater/{LAUNCHER_VERSION}'})
    with opener.open(req,timeout=30) as resp:
        if _artifact_origin(resp.geturl())!=origin:
            raise RuntimeError('Artifact final URL changed origin')
        raw_len=resp.headers.get('Content-Length')
        if raw_len:
            try: header_len=int(raw_len)
            except Exception: raise RuntimeError('Artifact Content-Length is invalid')
            if header_len!=declared or header_len>MAX_ARTIFACT_BYTES:
                raise RuntimeError('Artifact Content-Length mismatch')
        out=bytearray()
        while True:
            chunk=resp.read(min(65536,declared+1-len(out)))
            if not chunk: break
            out.extend(chunk)
            if len(out)>declared or len(out)>MAX_ARTIFACT_BYTES:
                raise RuntimeError('Artifact stream exceeds declared size')
        if len(out)!=declared:
            raise RuntimeError('Artifact stream size mismatch')
        return bytes(out)


def apply_release(rel,installed):
    if version_tuple(rel.get('min_launcher_version') or '1.0.0')>version_tuple(LAUNCHER_VERSION): raise RuntimeError('Update needs a newer launcher')
    raw=_release_bytes(rel); actual=hashlib.sha256(raw).hexdigest(); expected=str(rel['bundle_sha256']).lower()
    if actual!=expected: raise RuntimeError('Update SHA-256 verification failed')
    DATA.mkdir(parents=True,exist_ok=True); stage=Path(tempfile.mkdtemp(prefix='archivist_update_',dir=str(DATA))); backup=DATA/'update_backups'/f"{installed}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"; backup.mkdir(parents=True,exist_ok=True)
    req=HOME/'requirements.txt'; old_req=req.read_bytes() if req.exists() else None
    # what has actually been changed so far: a failure before the swap must leave the working app untouched
    # (restoring from a half-written backup would replace a good install with a broken one)
    backup_ok=False; swapped=False; req_changed=False
    new=HOME/'app.__new__'; old=HOME/'app.__old__'
    try:
        zp=stage/'release.zip'; zp.write_bytes(raw); unpack=stage/'unpacked'; unpack.mkdir()
        with zipfile.ZipFile(zp) as z: safe_extract(z,unpack)
        incoming=unpack/'app'; inreq=unpack/'requirements.txt'
        if not (incoming/'main.py').exists(): raise RuntimeError('Update bundle is missing app/main.py')
        cur=HOME/'app'
        if cur.exists(): shutil.copytree(cur,backup/'app')
        if req.exists(): shutil.copy2(req,backup/'requirements.txt')
        backup_ok=True
        shutil.rmtree(new,ignore_errors=True); shutil.rmtree(old,ignore_errors=True); shutil.copytree(incoming,new)
        if cur.exists(): cur.replace(old)
        swapped=True
        new.replace(cur)
        if inreq.exists(): req_changed=True; shutil.copy2(inreq,req); install_requirements(old_req,req)
        VERSION_PATH.write_text(str(rel['version']),encoding='utf-8'); shutil.rmtree(old,ignore_errors=True)
        write_status(status='updated',from_version=installed,to_version=rel['version'],notes=rel.get('notes')); prune_backups()
    except Exception:
        try:
            cur=HOME/'app'
            if swapped:
                if old.exists(): shutil.rmtree(cur,ignore_errors=True); old.replace(cur)
                elif backup_ok and (backup/'app').exists(): shutil.rmtree(cur,ignore_errors=True); shutil.copytree(backup/'app',cur)
                VERSION_PATH.write_text(installed,encoding='utf-8')
            if req_changed and backup_ok and (backup/'requirements.txt').exists(): shutil.copy2(backup/'requirements.txt',req)
            shutil.rmtree(new,ignore_errors=True)
        except Exception: pass
        raise
    finally: shutil.rmtree(stage,ignore_errors=True)

def check_update(force=False):
    global LAST_UPDATE_CHECK
    installed=current_version()
    if not force and os.environ.get('ARCHIVIST_SKIP_UPDATE')=='1': LAST_UPDATE_CHECK='skipped'; return installed
    if not CONFIG_PATH.exists():
        # No update channel configured (e.g. a side-by-side release candidate): never contact a server.
        LAST_UPDATE_CHECK='updates_off'; write_status(status='updates_off',version=installed); return installed
    try:
        cfg=json.loads(CONFIG_PATH.read_text(encoding='utf-8')); latest=fetch_latest(cfg)
        if latest and version_key(latest['version'])>version_key(installed): apply_release(latest,installed); LAST_UPDATE_CHECK='updated'; return str(latest['version'])
        LAST_UPDATE_CHECK='up_to_date'; write_status(status='up_to_date',version=installed)
    except Exception as exc: LAST_UPDATE_CHECK='update_failed'; write_status(status='update_failed',version=installed,error=str(exc))
    return current_version()

def wait_server_down(seconds=12):
    end=time.time()+seconds
    while time.time()<end:
        if not server_alive(): return
        time.sleep(.25)

def restore_latest_backup(version):
    root=DATA/'update_backups'
    try:
        candidates=sorted([p for p in root.iterdir() if p.is_dir() and p.name.startswith(str(version)+'_')], key=lambda p:p.stat().st_mtime, reverse=True)
        if not candidates: return False
        b=candidates[0]; cur=HOME/'app'; req=HOME/'requirements.txt'
        if not (b/'app').exists(): return False
        shutil.rmtree(cur,ignore_errors=True); shutil.copytree(b/'app',cur)
        if (b/'requirements.txt').exists(): shutil.copy2(b/'requirements.txt',req)
        VERSION_PATH.write_text(str(version),encoding='utf-8')
        write_status(status='rolled_back',version=str(version),reason='new version failed startup health check')
        return True
    except Exception as exc:
        write_status(status='rollback_failed',version=str(version),error=str(exc)); return False

def wait_server_up(seconds=30,proc=None):
    """Wait for /api/ping. With the app process given, keep waiting (up to START_WAIT_S) while it is alive."""
    end=time.time()+seconds; hard=time.time()+max(seconds,START_WAIT_S)
    while time.time()<(hard if proc is not None else end):
        if server_alive(timeout=.5): return True
        if proc is not None and proc.poll() is not None: return server_alive(timeout=.5)
        if proc is None and time.time()>=end: break
        time.sleep(.35)
    return False

def spawn_app(no_browser=False):
    pyw=HOME/'.venv'/'Scripts'/'pythonw.exe'; py=HOME/'.venv'/'Scripts'/'python.exe'; exe=pyw if pyw.exists() else py; main=HOME/'app'/'main.py'
    if not exe.exists() or not main.exists(): raise RuntimeError('MediaEngine installation is incomplete')
    env=os.environ.copy(); env['ARCHIVIST_HOME']=str(HOME); env['ARCHIVIST_V2_CHILD']='1'
    if no_browser: env['ARCHIVIST_SUPPRESS_BROWSER']='1'
    else: env.pop('ARCHIVIST_SUPPRESS_BROWSER',None)
    # -s -E: the bundled runtime ignores a user site-packages folder and PYTHON* variables of other Python installs
    env['PYTHONDONTWRITEBYTECODE']='1'   # -B too: the program folder stays exactly as installed
    # what the app prints (an error at start above all) goes to a log in the data folder - under pythonw it was lost
    out=subprocess.DEVNULL
    try:
        logs=DATA/'logs'; logs.mkdir(parents=True,exist_ok=True); log=logs/'app_console.log'
        if log.is_file() and log.stat().st_size>5_000_000: os.replace(log,logs/'app_console.1.log')
        out=open(log,'ab'); out.write(f"\n==== {datetime.now().isoformat(timespec='seconds')} start {HOME.name}\n".encode())
    except Exception: out=subprocess.DEVNULL
    return subprocess.Popen([str(exe),'-B','-s','-E',str(main),'--no-browser' if no_browser else '--open-browser'],cwd=str(HOME),env=env,close_fds=True,
                            stdin=subprocess.DEVNULL,stdout=out,stderr=out,**hidden_kwargs())

def start_previous(folder) -> bool:
    """Start the build this launcher stopped for the switch again (this one could not start): the owner is never left
    with nothing running."""
    try:
        vbs=Path(folder)/'Start MediaEngine.vbs'
        if os.name!='nt' or not vbs.is_file(): return False
        env={k:v for k,v in os.environ.items() if not k.upper().startswith('ARCHIVIST_') and k!='MEDIAENGINE_SWITCH_ANSWER'}
        subprocess.Popen(['wscript.exe',str(vbs)],cwd=str(folder),env=env,close_fds=True,stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,**hidden_kwargs())
        return True
    except Exception:
        return False

def main():
    switched_from=None
    raw_args=list(sys.argv[1:]); args=set(raw_args); force_browser='--browser' in args; force='--update' in args; restart='--restart' in args
    no_browser='--no-browser' in args or os.environ.get('MEDIAENGINE_NO_BROWSER')=='1'   # env: automated checks
    install_version=next((x.split('=',1)[1] for x in raw_args if x.startswith('--install-version=')),None)
    if '--at-sign-in' in args:                  # start at sign-in (Settings): in the background, no window
        no_browser=True
        if not wait_for_data_folder(): return 0  # (nothing is written before: no empty data folder appears)
        other=last_started_build()
        if other and not same_folder(other,HOME) and (other/'launcher.py').is_file() and (other/'.venv'/'Scripts'/'pythonw.exe').is_file():
            launcher_log(f'sign-in: the build started last is {other.name}: it starts instead')
            subprocess.Popen([str(other/'.venv'/'Scripts'/'pythonw.exe'),'-B','-s','-E',str(other/'launcher.py'),'--no-browser'],
                             cwd=str(other),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                             **hidden_kwargs())
            return 0
    if PORT is None:
        write_status(status='start_failed',version=current_version(),error='port.txt is present but not a valid port number')
        if not no_browser:   # a double click must not just do nothing
            message_box('MediaEngine не может запуститься: файл port.txt в папке программы повреждён. Установи эту версию заново.' if ui_ru()
                        else 'MediaEngine cannot start: the file port.txt in the program folder is damaged. Install this version again.')
        return 1
    if not (force or restart or install_version) and not single_instance():
        # another launcher of this install is already starting it (double click): just show the window
        launcher_log('another launcher of this build is starting it')
        if wait_server_up(START_WAIT_S) and not no_browser: open_user_interface(force_browser=force_browser)
        return 0
    # Manual launch while already running should only focus/open the existing web app - unless the running one is
    # ANOTHER build (e.g. the previous version after installing a new one): then offer to switch.
    # patient check (2 s): a MediaEngine that has just started (or a busy PC with a virus scanner) can take longer than
    # a blink to answer - taken for "nothing runs", this launcher started its own app on the busy port, which exited,
    # and the switch to this build never happened (seen in CI b80 / b88)
    if (server_alive() or server_alive(timeout=2)) and not (force or restart or install_version):
        other=running_install(tries=4)
        answer=os.environ.get('MEDIAENGINE_SWITCH_ANSWER','').lower()     # automated checks answer instead of a person
        launcher_log(f'already running: {other!r}')
        if not SIDE_BY_SIDE or other is None or (other and same_folder(other,HOME)) or (no_browser and not answer):
            # this build already runs: its window to the front (a second one only when there is none)
            if not no_browser and not (not force_browser and focus_app_window()): open_user_interface(force_browser=force_browser)
            return 0
        here=HOME.name; there=Path(other).name if other else 'an older build'
        how=switch_question(HOME,other)
        if answer: yes=(answer=='yes')
        elif how=='switch':
            yes=True; launcher_log(f'{there} is an older build: switching to this one without asking')
        elif how=='ask_older':
            yes=message_box(f'Уже запущена более новая сборка MediaEngine: {there}.\nВсё равно переключиться на более старую {here}? (Проекты останутся те же.)' if ui_ru() else
                            f'A newer MediaEngine build is running: {there}.\nSwitch to the older {here} anyway? (Your projects stay the same.)',yes_no=True)
        else:
            yes=message_box(f'Уже запущен другой MediaEngine: {there}.\nПереключиться на {here}? (Проекты останутся те же.)' if ui_ru() else
                            f'Another MediaEngine is running: {there}.\nSwitch to {here}? (Your projects stay the same.)',yes_no=True)
        if not yes:
            if not no_browser: open_user_interface(force_browser=force_browser)
            return 0
        launcher_log('switching from '+str(other))
        switched_from=str(other) if other else None
        if not stop_running():
            launcher_log('the running one refused to stop (busy)')
            write_status(status='switch_refused_busy',version=current_version(),running=other)
            if not answer and how=='switch':
                message_box(f'Пока открыта прежняя сборка {there}: она занята (собирается ролик). Когда закончит, запусти MediaEngine снова - откроется новая {here}.' if ui_ru() else
                            f'The previous build {there} stays open for now: it is busy (a reel is being built). When it has finished, start MediaEngine again to open the new {here}.')
            elif not answer:
                message_box('Запущенный MediaEngine занят (собирается ролик). Попробуй снова, когда он закончит.' if ui_ru() else
                            'The running MediaEngine is busy (a reel is being built). Try again when it has finished.')
            if not no_browser: open_user_interface(force_browser=force_browser)
            return 0
        wait_server_down(60)
        if server_alive():
            write_status(status='switch_failed_still_running',version=current_version(),running=other)
            if not answer: message_box('Другой MediaEngine не закрылся. Нажми «Выход» в его окне и запусти этот снова.' if ui_ru() else
                                       'The other MediaEngine did not close. Press Quit in its window, then start this one again.')
            return 1
    if force or restart or install_version: wait_server_down()
    before=current_version()
    if install_version:
        try:
            cfg=json.loads(CONFIG_PATH.read_text(encoding='utf-8')); rel=fetch_version(cfg,install_version)
            if not rel: raise RuntimeError('Requested candidate release was not found')
            if str(rel.get('version'))!=str(install_version): raise RuntimeError('Candidate version mismatch')
            apply_release(rel,before); after=str(rel['version'])
        except Exception as exc:
            write_status(status='remote_update_failed',version=before,target=install_version,error=str(exc)); return 2
    else: after=before if restart else check_update(force=force)
    proc=spawn_app(no_browser=True)
    if wait_server_up(30,proc):
        other=running_install()
        if proc.poll() is not None and other and not same_folder(other,HOME):
            # our app could not take the port: another build answers there (it started at the same moment)
            write_status(status='start_failed_other_running',version=current_version(),running=other)
            if not no_browser: open_user_interface(force_browser=force_browser)
            return 1
        write_status(status='running',version=current_version(),update_check=LAST_UPDATE_CHECK)
        if not no_browser:
            # took over from another build (from the shortcut or Setup): its windows still show the old pages - they
            # close once this one's window is there (one window, never a moment without one). A switch started inside
            # the program (Update, Check this PC: no_browser) keeps its window: that page follows the switch.
            old=[]
            if switched_from:
                try: old=_app_windows()[0]
                except Exception: old=[]
            open_user_interface(force_browser=force_browser)
            if old: close_windows_after_new(old)
        return 0
    # A bad release must not strand the user with a dead desktop shortcut.
    if after!=before and restore_latest_backup(before):
        proc=spawn_app(no_browser=True)
        if wait_server_up(30,proc):
            if not no_browser: open_user_interface(force_browser=force_browser)
            return 0
    write_status(status='start_failed',version=current_version())
    log=DATA/'logs'/'app_console.log'
    if switched_from and start_previous(switched_from):
        write_status(status='start_failed_previous_started',version=current_version(),running=switched_from)
        if not no_browser:
            name=Path(switched_from).name
            message_box(f'Эта версия MediaEngine не запустилась, поэтому снова запущена прежняя ({name}). Подробности для поддержки: {log}' if ui_ru() else
                        f'This MediaEngine version could not start, so the previous one ({name}) was started again. Details for support: {log}')
        return 1
    if not no_browser:      # never a double click that silently does nothing
        message_box(f'MediaEngine не запустился. Подробности для поддержки: {log}' if ui_ru() else
                    f'MediaEngine could not start. Details for support: {log}')
    return 1

if __name__=='__main__': raise SystemExit(main())
